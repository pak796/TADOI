import React, { useEffect, useLayoutEffect, useReducer, useRef, useState } from "react";
import type { KeyEvent } from "@opentui/core";
import { useKeyboard, useRenderer, useTerminalDimensions } from "@opentui/react";
import {
  applyThemeWithSettings,
  colorForTag,
  theme,
  themeForObject,
  layout
} from "./theme";
import {
  getNextSelectedIdAfterDelete,
  nextEditorFocusTarget,
  resolveEditorFocusAfterDraftChange,
  toEditorFocus
} from "./uiState";
import { handleKey, type KeyRouterAction } from "./keyRouter";
import { TaskList } from "../components/TaskList";
import { DetailsPane } from "../components/DetailsPane";
import { EditorPane } from "../components/EditorPane";
import { LeftRail, type LeftRailMenuItem } from "../components/LeftRail";
import { DashboardPane } from "../components/DashboardPane";
import { TagFilterPanel } from "../components/TagFilterPanel";
import { BackupCenterScreen } from "../components/BackupCenterScreen";
import { EmptyNuxModal } from "../components/EmptyNuxModal";
import {
  Custom1ThemeEditor,
  type Custom1ThemeEditorHandle
} from "../components/Custom1ThemeEditor";
import {
  BuiltInThemeTextEditor,
  type BuiltInThemeTextEditorHandle
} from "../components/BuiltInThemeTextEditor";
import { OverdueNotificationModal } from "../components/OverdueNotificationModal";
import { diffLocalDays, startOfLocalDayMs } from "../domain/dates";
import { computeTopTagsOpen } from "../domain/dashboard";
import {
  buildRecurrenceFromDraft,
  buildRecurrencePreviewFromDraft
} from "../domain/recurrence/draft";
import { getEditorViewportHeights } from "../domain/editorPaneLayout";
import {
  formatDateToLocalIso,
  parseLocalIsoToDate
} from "../domain/recurrence/rruleAdapter";
import { isRepeatOccurrenceAfterSeriesStart } from "../domain/recurrence/repeatOccurrence";
import {
  deleteRecurringOccurrence,
  deleteRecurringOccurrenceAndFuture
} from "../domain/recurrence/delete";
import {
  findNextMatchingIndex,
  isTaskDueToday,
  isTaskOverdue
} from "../domain/navigation";
import { clampScrollOffset, ensureSelectedVisible } from "../domain/scroll";
import { computeOpenPriorityStats, computeTopTagStats } from "../domain/tagStats";
import {
  addTaskLink,
  deleteTaskLink,
  extractUrlScheme,
  updateTaskLink
} from "../domain/taskLinks";
import { decideTaskLinkOpen } from "./linkOpenFlow";
import {
  applyAutocomplete,
  getAutocompleteStep,
  getSuggestedTime,
  type SuggestedTime
} from "../domain/timeAutocomplete";
import {
  applyArchiveAging,
  combineDueDateTime,
  createDraftFromTask,
  createEmptyDraft,
  formatDate,
  getDueInLabel,
  initialState,
  parseDueTime,
  reducer
} from "../state/store";
import {
  getDataFilePath,
  CURRENT_SCHEMA_VERSION,
  loadStateStrict,
  saveStateDebounced,
  type LoadedData,
  type SaveStateResult
} from "../state/persistence";
import {
  formatTagFilterBooleanSummary,
  isEmptyTagFilter,
  normalizeTagFilter,
  normalizeTagToken,
  resolveEffectiveTagFilter,
  type TagFilterBucket
} from "../domain/tagFilter";
import {
  formatTagForDisplay,
  getTagCompletion,
  normalizeTagPrefix,
  rankTags,
  updateTagIndex
} from "../domain/tagIndex";
import {
  formatPriorityForDisplay,
  isPriorityToken,
  normalizePriorityFilterValue,
  normalizePriorityFromTokens,
  resolveTaskPriorityTag
} from "../domain/priorityTags";
import {
  getSortModeLabel,
  SORT_MODE_ORDER
} from "../domain/query";
import { reconcileSelectionById } from "../domain/selection";
import { buildVisibleTaskRows, type VisibleTaskRow } from "../domain/taskRows";
import {
  AppState,
  EditorDraft,
  FocusTarget,
  Mode,
  SavedView,
  TagFilter,
  Task,
  TaskLink
} from "../domain/models";
import {
  formatThemeDisplayName,
  ROTATING_THEME_ORDER,
  THEMES,
  type RotatingThemeId,
  type ThemeId,
  type ThemeTokens
} from "../theme/themes";
import {
  applySavedView,
  DEFAULT_VIEW_FILTERS,
  isSavedViewActive,
  MAX_SAVED_VIEWS,
  saveViewByName,
  deleteViewAtIndex
} from "../domain/savedViews";
import {
  cycleLogoMode,
  getDefaultSettings,
  loadSettings,
  saveSettingsDebounced,
  type BuiltInThemeTextOverrideConfig,
  type BuiltInThemeTextOverrides,
  type CustomThemeConfig,
  type CustomThemes,
  type FlashMode,
  type LogoMode,
  type SecuritySettings,
  type NotificationSettings,
  type ThemeObjectId,
  type ThemeTextTokenOverrides
} from "../settings/settings";
import { settingsReducer } from "../state/settingsStore";
import { isEditorMode } from "../ui/modeFocus";
import {
  clearEmptyNux,
  dismissEmptyNux,
  initialUIState,
  openEmptyNux,
  setEmptyNuxCelebratePending,
  uiReducer,
  unwind,
  type UIState,
  type UIDeleteModal,
  type EmptyNuxStep,
  type UITaskLinkFormField,
  type UITaskLinkFormModal,
  type UITaskLinkModalKind
} from "../ui/state";
import {
  backupCenterReducer,
  hasMatchingCalendarImportDryRun,
  hasMatchingDryRun,
  isCalendarImportConfirmValid,
  initialBackupCenterState,
  isReplaceConfirmationValid,
  shouldRequireCalendarImportConfirm,
  type BackupCenterScreen as BackupCenterFlowScreen
} from "../state/backupCenterFlow";
import {
  buildDefaultCalendarImportReportPath,
  runCalendarExportFlow,
  runCalendarImportCommitFlow,
  runCalendarImportDryRunFlow
} from "../state/backupCenterCalendarController";
import {
  BackupImportPartialError,
  buildTimestampedBackupPath,
  exportBackup,
  getResolvedDataPath,
  importBackup
} from "../state/backupService";
import { NotificationManager } from "../notifications/notificationManager";
import { InAppModalNotifier } from "../notifications/notifiers/inAppModalNotifier";
import { OSNotifier } from "../notifications/notifiers/osNotifier";
import { TerminalBellNotifier } from "../notifications/notifiers/terminalBellNotifier";
import {
  applyOverdueMarkDone,
  applyOverdueSnooze,
  resolveGoToTaskTarget
} from "../notifications/overdueTaskActions";
import type { TaskOverdueEvent } from "../notifications/types";
import { APP_VERSION } from "./version";
import {
  getTerminalSizeWarning,
  isTerminalSizeSupported,
  MIN_TERMINAL_HEIGHT,
  MIN_TERMINAL_WIDTH
} from "./layoutGuard";
import {
  APP_NAME,
  APP_TAGLINE,
  ENV_VARS,
  PRODUCT_NAME_TM,
  TRADEMARK_NOTICE_LINES,
  formatLogoModeLabel
} from "../brand/brand";
import { copyToClipboard } from "./copyToClipboard";
import { openTarget } from "./openTarget";
import { redactPathForDisplay } from "./pathRedaction";

const TICKER_INTERVAL_MS = 6000;
const BOTTOM_INFO_VIEW_ORDER = ["summary", "tags", "priorities"] as const;
const SLOW_PULSE_INTERVAL_MS = 2000;
const FAST_PULSE_INTERVAL_MS = 700;
const NOTIFICATION_EVALUATION_INTERVAL_MS = 10000;
const ENGAGEMENT_TOAST_TICK_INTERVAL_MS = 350;
const FIRST_RECURRING_TASK_TOAST_MS = 10_000;
const FIRST_RECURRING_REPEAT_DONE_TOAST_MS = 10_000;
const ROTATING_THEME_INTERVAL_MS = 15000;
const G_PREFIX_TIMEOUT_MS = 280;
const NAV_BANNER_TIMEOUT_MS = 1800;
const VIEW_NAME_MAX_LENGTH = 40;
const DASHBOARD_TOP_TAG_MIN = 5;
const DASHBOARD_TOP_TAG_MAX = 8;
const TAG_FILTER_BUCKET_ORDER: TagFilterBucket[] = ["all", "any", "none"];
const PERF_DEBUG_ENABLED = process.env[ENV_VARS.PERF_DEBUG] === "1";
const HELP_PANEL_MIN_WIDTH = 96;
const HELP_PANEL_MAX_WIDTH = 124;
const HELP_PANEL_MIN_HEIGHT = 14;
const HELP_PANEL_HORIZONTAL_MARGIN = 4;
const HELP_PANEL_VERTICAL_MARGIN = 2;
const HELP_PANEL_BORDER_ROWS = 2;
const HELP_PANEL_BORDER_COLS = 2;
const HELP_HEADER_ROWS = 2;
const HELP_DIVIDER_ROWS = 1;
const HELP_FOOTER_ROWS = 2;
const HELP_PANEL_CHROME_ROWS = HELP_HEADER_ROWS + HELP_DIVIDER_ROWS + HELP_FOOTER_ROWS;
const HELP_SECTION_SCROLL_PADDING = 1;
const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings =
  getDefaultSettings().notifications;
const DEFAULT_SECURITY_SETTINGS: SecuritySettings = getDefaultSettings().security;
const DEFAULT_LOGO_MODE: LogoMode = getDefaultSettings().logoMode;
const DEFAULT_CUSTOM_THEMES: CustomThemes | undefined = getDefaultSettings().customThemes;
const TASK_LINK_FORM_FIELD_ORDER: UITaskLinkFormField[] = [
  "label",
  "target",
  "type",
  "save",
  "cancel"
];
const TASK_LINK_FORM_KIND_ORDER: UITaskLinkModalKind[] = ["auto", "url", "path"];
const MODAL_STANDARD_WIDTH = 64;

type HelpMenuItem = {
  title: string;
  description?: string | string[];
};

type HelpMenuSection = {
  title: string;
  items: HelpMenuItem[];
};

type HelpRow =
  | { kind: "section_header"; sectionIndex: number }
  | { kind: "item_title"; sectionIndex: number; itemIndex: number }
  | {
      kind: "item_description";
      sectionIndex: number;
      itemIndex: number;
      descriptionLineIndex: number;
    };

type HelpSectionLayout = {
  id: string;
  sectionIndex: number;
  title: string;
  startRow: number;
  headerRow: number;
  endRow: number;
};

type HelpScrollbarThumb = {
  startRow: number;
  endRow: number;
};

type HelpPage =
  | "help"
  | "settings"
  | "theme"
  | "custom1"
  | "custom1Edit"
  | "textTuning"
  | "textTuningTheme"
  | "textTuningEdit";

type HelpNavSelectionByPage = {
  settings: number;
  theme: number;
  custom1: number;
  textTuning: number;
  textTuningTheme: number;
};

type HelpNavItem = {
  title: string;
  description: string;
};

const HELP_SETTINGS_NAV_ITEMS: HelpNavItem[] = [
  {
    title: "Theme",
    description: "Theme mode and custom palette settings."
  },
  {
    title: "Logo",
    description: "Left/Right previews mode. Enter commits. Esc backs out."
  },
  {
    title: "Flash Mode",
    description: "Switch between static and pulse urgency cues."
  },
  {
    title: "Notifications",
    description: "Enable or disable overdue notifications."
  },
  {
    title: "Overdue Popup",
    description: "Enable or disable in-app overdue popup."
  },
  {
    title: "Terminal Bell",
    description: "Enable or disable terminal bell on overdue."
  }
];

const HELP_THEME_NAV_ITEMS: HelpNavItem[] = [
  {
    title: "Current Theme",
    description: "Press Enter/Right to cycle theme mode."
  },
  {
    title: "Custom1",
    description: "Global palette plus per-object overrides."
  },
  {
    title: "Text Tuning",
    description: "Tune text colors for built-in themes one-by-one."
  }
];

const HELP_CUSTOM1_NAV_ITEMS: HelpNavItem[] = [
  {
    title: "Edit Colors",
    description: "Open editor (live preview, save/cancel/reset)."
  }
];

function formatThemeIdLabel(themeId: RotatingThemeId): string {
  return formatThemeDisplayName(themeId);
}

const HELP_TEXT_TUNING_THEMES: RotatingThemeId[] = [...ROTATING_THEME_ORDER];
const HELP_TEXT_TUNING_NAV_ITEMS: HelpNavItem[] = HELP_TEXT_TUNING_THEMES.map((themeId) => ({
  title: formatThemeIdLabel(themeId),
  description: "Per-theme + per-object text color overrides."
}));
const HELP_TEXT_TUNING_THEME_NAV_ITEMS: HelpNavItem[] = [
  {
    title: "Edit Text Colors",
    description: "Open editor (live preview, save/cancel/reset)."
  }
];

/*
 * Help menu structure:
 * - Edit HELP_MENU_SECTIONS to add/remove categories and items.
 * - Help keyboard routing is in src/app/keyRouter.ts (Mode.HELP branch).
 */
const HELP_MENU_SECTIONS: HelpMenuSection[] = [
  {
    title: "Getting Started",
    items: [
      {
        title: "Open Help with ?",
        description: "Press ? from list/dashboard to open or close this menu."
      },
      {
        title: "Move around with arrows",
        description: "Use Up/Down to focus sections and Enter/Space to toggle."
      },
      {
        title: "Close with Esc",
        description: "Esc returns to the previous mode/focus."
      }
    ]
  },
  {
    title: "Navigation & Keybindings",
    items: [
      {
        title: "List navigation: j/k, arrows, gg, G",
        description: "Jump and browse tasks quickly."
      },
      {
        title: "Page movement: Ctrl+U / Ctrl+D",
        description: "Page up/down through long task lists."
      },
      {
        title: "Attention jumps: [ ] and { }",
        description: "Cycle overdue and due-today tasks."
      },
      {
        title: "Search: / open, Enter/Esc close",
        description: "Type to filter by task title and tags while Search is open."
      }
    ]
  },
  {
    title: "Tasks (create/edit/complete)",
    items: [
      { title: "a add, l add link, e edit, E edit series, c copy" },
      { title: "Space toggle done/open, d delete" },
      { title: "Tab links focus: Enter/o open, c copy, l/e/d manage links" },
      {
        title: "Recurring controls: x skip, z snooze",
        description: "Skip or push the selected recurring occurrence by one day."
      }
    ]
  },
  {
    title: "Tags & Filters",
    items: [
      {
        title: "f status, s sort, g due, r priority, t single tag",
        description: "Use r for priority cycle and t for quick single-tag cycle."
      },
      {
        title: "PRIORITY (r)",
        description: "Cycle priority filter based on open-task priority tags."
      },
      {
        title: "TAG PANEL (p)",
        description: "Open boolean tag filter panel (ALL/ANY/NONE)."
      },
      {
        title: "Bottom quick filters are clickable",
        description: "Click buckets/tags to apply; click again to clear."
      },
      {
        title: "Saved views: v overlay, Ctrl+S save, 1..9 apply",
        description: "Pressing an active slot hotkey again resets to default view."
      }
    ]
  },
  {
    title: "Data (Import/Export/Backup)",
    items: [
      {
        title: "Press 1 in Help to open Backup Center",
        description: "Guided DATA and CALENDAR flows with dry-run safety gates."
      },
      {
        title: "CLI export/import commands available",
        description: "Use backup exports for portability and recovery."
      },
      {
        title: "Calendar (ICS) in Backup Center",
        description: [
          "Open Backup Center -> Calendar (ICS)... -> Export Calendar (.ics) or Import Calendar (.ics).",
          "Export: range/view/privacy + timestamped .ics path with deterministic output.",
          "Import: merge/update/create + horizon cap + mandatory dry-run before commit.",
          "Round-trip identity: X-TADOI-TASK-ID first, then TADOI UID conventions, then external UID.",
          "Boundary: one-way actions per run (not live calendar sync)."
        ]
      },
      {
        title: "Cloud sync integrations (placeholder)",
        description: "Reserved for future workspace sync options."
      }
    ]
  },
  {
    title: "Settings & Themes",
    items: [
      {
        title: "Settings",
        description: [
          "Open Settings submenu",
          "Press Enter/Right to change settings."
        ]
      }
    ]
  },
  {
    title: "Troubleshooting / Support",
    items: [
      {
        title: "Resize terminal if layout feels cramped",
        description: `Minimum supported terminal is ${MIN_TERMINAL_WIDTH}x${MIN_TERMINAL_HEIGHT}.`
      },
      {
        title: "Check app version and data path",
        description: "Useful when reporting issues or validating environment."
      },
      {
        title: "Legal / Trademarks",
        description: [...TRADEMARK_NOTICE_LINES]
      },
      {
        title: "License & usage",
        description: "See LICENSE for PolyForm Noncommercial terms."
      }
    ]
  }
];
const HELP_SETTINGS_NAV_SECTION_INDEX = HELP_MENU_SECTIONS.findIndex(
  (section) => section.title === "Settings & Themes"
);
const HELP_SETTINGS_LOGO_NAV_INDEX = HELP_SETTINGS_NAV_ITEMS.findIndex(
  (item) => item.title === "Logo"
);

function createDefaultHelpExpandedState(): boolean[] {
  return HELP_MENU_SECTIONS.map((_, index) => index === 0);
}

function clampToBounds(value: number, min: number, max: number): number {
  if (max <= min) return max;
  return Math.max(min, Math.min(value, max));
}

function truncateToWidth(value: string, maxWidth: number): string {
  if (maxWidth <= 0) return "";
  if (value.length <= maxWidth) return value;
  if (maxWidth <= 3) return value.slice(0, maxWidth);
  return `${value.slice(0, maxWidth - 3)}...`;
}

function fitLineToWidth(value: string, width: number): string {
  const truncated = truncateToWidth(value, width);
  if (truncated.length >= width) return truncated;
  return truncated.padEnd(width, " ");
}

function pickHelpCloseButtonLabel(maxWidth: number): string {
  if (maxWidth >= "[Esc] Close".length + 2) return "[Esc] Close";
  if (maxWidth >= "Close".length + 2) return "Close";
  if (maxWidth >= "X".length + 2) return "X";
  return "";
}

function normalizeHelpReturnContext(
  mode: Mode,
  focus: FocusTarget
): { mode: Mode; focus: FocusTarget } {
  const normalizedMode =
    mode === Mode.HELP || mode === Mode.BACKUP_CENTER ? Mode.LIST : mode;

  if (normalizedMode === Mode.LIST) {
    return { mode: normalizedMode, focus: FocusTarget.TASK_LIST };
  }
  if (normalizedMode === Mode.DASHBOARD) {
    return { mode: normalizedMode, focus: FocusTarget.DASHBOARD };
  }
  if (normalizedMode === Mode.BACKUP_CENTER) {
    return { mode: normalizedMode, focus: FocusTarget.BACKUP_CENTER };
  }
  if (normalizedMode === Mode.SEARCH) {
    return { mode: normalizedMode, focus: FocusTarget.SEARCH_INPUT };
  }
  if (normalizedMode === Mode.MODAL_CONFIRM) {
    return { mode: normalizedMode, focus: FocusTarget.MODAL };
  }
  if (
    (normalizedMode === Mode.ADD || normalizedMode === Mode.EDIT) &&
    toEditorFocus(focus) === null
  ) {
    return { mode: normalizedMode, focus: FocusTarget.EDITOR_TITLE };
  }

  return { mode: normalizedMode, focus };
}

function getHelpItemDescriptionLines(item: HelpMenuItem): string[] {
  if (!item.description) return [];
  if (Array.isArray(item.description)) {
    return item.description.filter((line) => line.length > 0);
  }
  return item.description.length > 0 ? [item.description] : [];
}

function buildHelpRows(expandedBySection: boolean[]): {
  rows: HelpRow[];
  sections: HelpSectionLayout[];
} {
  const rows: HelpRow[] = [];
  const sections: HelpSectionLayout[] = [];

  HELP_MENU_SECTIONS.forEach((section, sectionIndex) => {
    const startRow = rows.length;
    const headerRow = rows.length;
    const sectionId = `help-${sectionIndex}-${section.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")}`;
    rows.push({ kind: "section_header", sectionIndex });

    if (expandedBySection[sectionIndex]) {
      section.items.forEach((item, itemIndex) => {
        rows.push({ kind: "item_title", sectionIndex, itemIndex });
        const descriptionLines = getHelpItemDescriptionLines(item);
        descriptionLines.forEach((_, descriptionLineIndex) => {
          rows.push({
            kind: "item_description",
            sectionIndex,
            itemIndex,
            descriptionLineIndex
          });
        });
      });
    }

    sections.push({
      id: sectionId,
      sectionIndex,
      title: section.title,
      startRow,
      headerRow,
      endRow: Math.max(startRow, rows.length - 1)
    });
  });

  return { rows, sections };
}

function findHelpSectionIndexForViewportTop(
  sections: HelpSectionLayout[],
  viewportTopRow: number
): number {
  if (sections.length === 0) return 0;
  for (const section of sections) {
    if (section.headerRow >= viewportTopRow) {
      return section.sectionIndex;
    }
  }
  return sections[sections.length - 1]?.sectionIndex ?? 0;
}

function ensureHelpSectionVisible(params: {
  section: HelpSectionLayout | undefined;
  scrollOffset: number;
  visibleRows: number;
  itemCount: number;
  paddingRows: number;
}): number {
  const { section, scrollOffset, visibleRows, itemCount, paddingRows } = params;
  if (!section || itemCount <= 0) return 0;
  const safeVisibleRows = Math.max(1, visibleRows);
  const clampedOffset = clampScrollOffset(scrollOffset, safeVisibleRows, itemCount);
  const maxVisibleRow = clampedOffset + safeVisibleRows - 1;
  const safePadding = Math.max(
    0,
    Math.min(paddingRows, Math.floor((safeVisibleRows - 1) / 2))
  );
  const paddedTop = clampedOffset + safePadding;
  const paddedBottom = maxVisibleRow - safePadding;
  const selectedHeaderRow = section.headerRow;

  let nextOffset = clampedOffset;
  // Scroll-follow selection tracks the selected section header only.
  // Expanding/collapsing content should not force viewport jumps by itself.
  if (selectedHeaderRow < paddedTop) {
    nextOffset = selectedHeaderRow - safePadding;
  } else if (selectedHeaderRow > paddedBottom) {
    nextOffset = selectedHeaderRow - (safeVisibleRows - safePadding - 1);
  }

  return clampScrollOffset(nextOffset, safeVisibleRows, itemCount);
}

function computeHelpScrollbarThumb(params: {
  scrollOffset: number;
  visibleRows: number;
  itemCount: number;
}): HelpScrollbarThumb | null {
  const { scrollOffset, visibleRows, itemCount } = params;
  if (itemCount <= visibleRows) return null;
  const safeVisibleRows = Math.max(1, visibleRows);
  const maxOffset = Math.max(1, itemCount - safeVisibleRows);
  const thumbSize = Math.max(
    1,
    Math.min(safeVisibleRows, Math.round((safeVisibleRows / itemCount) * safeVisibleRows))
  );
  const maxThumbTop = Math.max(0, safeVisibleRows - thumbSize);
  const thumbTop = Math.round((clampScrollOffset(scrollOffset, safeVisibleRows, itemCount) / maxOffset) * maxThumbTop);
  return {
    startRow: thumbTop,
    endRow: thumbTop + thumbSize - 1
  };
}

function cloneThemeTokens(tokens: ThemeTokens): ThemeTokens {
  return { ...tokens };
}

function cloneThemeObjectOverrides(
  objects: Partial<Record<ThemeObjectId, Partial<ThemeTokens>>> | undefined
): Partial<Record<ThemeObjectId, Partial<ThemeTokens>>> {
  if (!objects) return {};
  const next: Partial<Record<ThemeObjectId, Partial<ThemeTokens>>> = {};
  for (const [objectId, overrides] of Object.entries(objects) as Array<
    [ThemeObjectId, Partial<ThemeTokens>]
  >) {
    next[objectId] = { ...overrides };
  }
  return next;
}

function resolveCustom1Config(customThemes: CustomThemes | undefined): CustomThemeConfig {
  const fallback = getDefaultSettings().customThemes?.custom1?.global;
  if (!fallback) {
    throw new Error("Default custom1 theme is unavailable.");
  }
  const global = customThemes?.custom1?.global ?? fallback;
  return {
    global: cloneThemeTokens(global),
    objects: cloneThemeObjectOverrides(customThemes?.custom1?.objects)
  };
}

function cloneThemeTextTokenOverrides(
  overrides: ThemeTextTokenOverrides | undefined
): ThemeTextTokenOverrides {
  if (!overrides) return {};
  return { ...overrides };
}

function cloneThemeTextObjectOverrides(
  objects: Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>> | undefined
): Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>> {
  if (!objects) return {};
  const next: Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>> = {};
  for (const [objectId, overrides] of Object.entries(objects) as Array<
    [ThemeObjectId, ThemeTextTokenOverrides]
  >) {
    next[objectId] = { ...overrides };
  }
  return next;
}

function sanitizeThemeTextTokenOverrides(
  overrides: ThemeTextTokenOverrides
): ThemeTextTokenOverrides | undefined {
  const next: ThemeTextTokenOverrides = {};
  if (overrides.text) next.text = overrides.text;
  if (overrides.mutedText) next.mutedText = overrides.mutedText;
  if (overrides.selectionText) next.selectionText = overrides.selectionText;
  return Object.keys(next).length > 0 ? next : undefined;
}

function sanitizeThemeTextObjectOverrides(
  objects: Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>>
): Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>> | undefined {
  const next: Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>> = {};
  for (const [objectId, overrides] of Object.entries(objects) as Array<
    [ThemeObjectId, ThemeTextTokenOverrides]
  >) {
    const sanitized = sanitizeThemeTextTokenOverrides(overrides);
    if (sanitized) {
      next[objectId] = sanitized;
    }
  }
  return Object.keys(next).length > 0 ? next : undefined;
}

function resolveBuiltInThemeTextConfig(
  customThemes: CustomThemes | undefined,
  themeId: RotatingThemeId
): BuiltInThemeTextOverrideConfig {
  const source = customThemes?.textByTheme?.[themeId];
  const global = cloneThemeTextTokenOverrides(source?.global);
  const objects = cloneThemeTextObjectOverrides(source?.objects);
  return {
    global,
    objects
  };
}

function resolveDashboardTopTagLimit(panelHeight: number): number {
  const availableRows = Math.max(1, panelHeight - 8);
  if (availableRows < DASHBOARD_TOP_TAG_MIN) {
    return availableRows;
  }
  return Math.min(DASHBOARD_TOP_TAG_MAX, availableRows);
}

function getTagQuery(tagsText: string): string | null {
  if (/[\s,]$/.test(tagsText)) return null;
  const tokens = tagsText.split(/[\s,]+/).filter(Boolean);
  if (tokens.length === 0) return null;
  const lastToken = tokens[tokens.length - 1];
  const normalized = normalizeTagPrefix(lastToken);
  return normalized.length ? normalized : null;
}

function parseTagsInput(input: string): string[] {
  const tokens = input.split(/[\s,]+/).filter(Boolean);
  return normalizePriorityFromTokens(tokens);
}

function getDueSuggestion(dueText: string, now: number): string | null {
  const trimmed = dueText.trim();
  const date = new Date(now);
  const year = String(date.getFullYear());
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  if (!trimmed) {
    return year;
  }

  if (/^\d{1,3}$/.test(trimmed)) {
    return year;
  }

  if (/^\d{4}$/.test(trimmed)) {
    return `${trimmed}-${month}`;
  }

  if (/^\d{4}-$/.test(trimmed)) {
    return `${trimmed}${month}`;
  }

  if (/^\d{4}-\d{1}$/.test(trimmed)) {
    const prefix = trimmed.slice(0, -1);
    const partial = trimmed.slice(-1);
    return `${prefix}${partial}${month.slice(1)}`;
  }

  if (/^\d{4}-\d{2}$/.test(trimmed)) {
    return `${trimmed}-${day}`;
  }

  if (/^\d{4}-\d{2}-$/.test(trimmed)) {
    return `${trimmed}${day}`;
  }

  if (/^\d{4}-\d{2}-\d{1}$/.test(trimmed)) {
    const prefix = trimmed.slice(0, -1);
    const partial = trimmed.slice(-1);
    return `${prefix}${partial}${day.slice(1)}`;
  }

  return null;
}

function normalizeErrorDetail(error: unknown): string {
  const detail = error instanceof Error ? error.message : String(error);
  return detail.replace(/\s+/g, " ").trim();
}

function replaceLastTagToken(tagsText: string, tag: string, appendSpace = false): string {
  const tokens = tagsText.split(/[\s,]+/).filter(Boolean);
  if (tokens.length === 0) {
    return `${formatTagForDisplay(tag)}${appendSpace ? " " : ""}`;
  }
  tokens[tokens.length - 1] = formatTagForDisplay(tag);
  return `${tokens.join(" ")}${appendSpace ? " " : ""}`;
}

type TagTickerSegment = {
  tag: string;
  total: number;
  dueThisWeek: number;
  displayTag: string;
};

type BottomInfoView = (typeof BOTTOM_INFO_VIEW_ORDER)[number];

type PriorityTickerSegment = {
  priorityTag: string;
  displayPriority: string;
  total: number;
};

const TAG_PILL_PADDING = 2;

function truncateTagDisplay(value: string, maxLen: number): string {
  if (value.length <= maxLen) return value;
  if (maxLen <= 1) return "#";
  if (maxLen === 2) return "#~";
  return `${value.slice(0, maxLen - 1)}~`;
}

function buildTagTickerSegments(
  stats: ReturnType<typeof computeTopTagStats>,
  maxWidth: number
): TagTickerSegment[] {
  const separator = "  ";
  const segments: TagTickerSegment[] = [];
  let used = 0;

  for (const stat of stats) {
    const displayTag = formatTagForDisplay(stat.tag);
    const countText = String(stat.total);
    const segmentText = `${countText} ${displayTag}`;
    let segmentLen = segmentText.length + TAG_PILL_PADDING;
    const extra = segments.length ? separator.length : 0;

    if (used + extra + segmentLen <= maxWidth) {
      segments.push({ ...stat, displayTag });
      used += extra + segmentLen;
      continue;
    }

    const available = maxWidth - used - extra;
    if (available <= 0) break;
    const nonTagLen = countText.length + TAG_PILL_PADDING;
    const maxTagLen = available - nonTagLen;
    if (maxTagLen <= 1) break;

    const truncatedTag = truncateTagDisplay(displayTag, maxTagLen);
    const truncatedText = `${countText} ${truncatedTag}`;
    segmentLen = truncatedText.length + TAG_PILL_PADDING;
    if (used + extra + segmentLen <= maxWidth) {
      segments.push({ ...stat, displayTag: truncatedTag });
    }
    break;
  }

  return segments;
}

function buildPriorityTickerSegments(
  stats: ReturnType<typeof computeOpenPriorityStats>,
  maxWidth: number
): PriorityTickerSegment[] {
  const separator = "  ";
  const segments: PriorityTickerSegment[] = [];
  let used = 0;

  for (const stat of stats) {
    const segmentText = `${stat.total} ${stat.displayPriority}`;
    const segmentLen = segmentText.length + TAG_PILL_PADDING;
    const extra = segments.length ? separator.length : 0;

    if (used + extra + segmentLen > maxWidth) {
      break;
    }

    segments.push({ ...stat });
    used += extra + segmentLen;
  }

  return segments;
}

function summarizeViewFilters(filters: SavedView["filters"]): string {
  const search = filters.searchText?.trim();
  const searchLabel = search ? ` search=${search}` : "";
  const priority = formatPriorityForDisplay(filters.priority);
  const priorityLabel = priority ? ` priority=${priority}` : "";
  const booleanTagSummary = formatTagFilterBooleanSummary(filters.tagFilter);
  const tagLabel = booleanTagSummary
    ? ` tags=${booleanTagSummary}`
    : filters.tag
      ? ` tag=#${filters.tag}`
      : "";
  return `status=${filters.status} due=${filters.due}${priorityLabel}${tagLabel}${searchLabel}`;
}

function comparePriorityDigits(left: string, right: string): number {
  const normalizedLeft = left.replace(/^0+(?=\d)/, "");
  const normalizedRight = right.replace(/^0+(?=\d)/, "");
  if (normalizedLeft.length !== normalizedRight.length) {
    return normalizedLeft.length - normalizedRight.length;
  }
  const magnitudeCompare = normalizedLeft.localeCompare(normalizedRight);
  if (magnitudeCompare !== 0) {
    return magnitudeCompare;
  }
  if (left.length !== right.length) {
    return left.length - right.length;
  }
  return left.localeCompare(right);
}

function comparePriorityTags(left: string, right: string): number {
  const leftDigits = isPriorityToken(left)?.digits;
  const rightDigits = isPriorityToken(right)?.digits;
  if (!leftDigits || !rightDigits) {
    return left.localeCompare(right);
  }
  const digitCompare = comparePriorityDigits(leftDigits, rightDigits);
  if (digitCompare !== 0) {
    return digitCompare;
  }
  return left.localeCompare(right);
}

function getSortedOpenTaskPriorities(tasks: Task[]): string[] {
  const priorities = new Set<string>();
  for (const task of tasks) {
    if (task.status !== "open") continue;
    const priority = resolveTaskPriorityTag(task.tags);
    if (!priority) continue;
    priorities.add(priority);
  }
  return Array.from(priorities).sort(comparePriorityTags);
}

function cycleTaskLinkFormField(
  current: UITaskLinkFormField,
  direction: 1 | -1
): UITaskLinkFormField {
  const index = TASK_LINK_FORM_FIELD_ORDER.indexOf(current);
  const safeIndex = index === -1 ? 0 : index;
  const nextIndex =
    (safeIndex + direction + TASK_LINK_FORM_FIELD_ORDER.length) %
    TASK_LINK_FORM_FIELD_ORDER.length;
  return TASK_LINK_FORM_FIELD_ORDER[nextIndex];
}

function cycleTaskLinkFormKind(
  current: UITaskLinkModalKind,
  direction: 1 | -1
): UITaskLinkModalKind {
  const index = TASK_LINK_FORM_KIND_ORDER.indexOf(current);
  const safeIndex = index === -1 ? 0 : index;
  const nextIndex =
    (safeIndex + direction + TASK_LINK_FORM_KIND_ORDER.length) %
    TASK_LINK_FORM_KIND_ORDER.length;
  return TASK_LINK_FORM_KIND_ORDER[nextIndex];
}

function formatLinkSnippet(label: string | undefined, target: string): string {
  const value = label?.trim().length ? label.trim() : target;
  if (value.length <= 48) return value;
  return `${value.slice(0, 47)}…`;
}

function isBlockingOverlayOpen(uiState: UIState): boolean {
  return (
    uiState.mode === Mode.MODAL_CONFIRM ||
    uiState.mode === Mode.HELP ||
    uiState.mode === Mode.BACKUP_CENTER ||
    uiState.mode === Mode.TAG_FILTER
  );
}

type AppProps = {
  initialData?: LoadedData;
  skipInitialSave?: boolean;
  startupBanner?: string;
  initialThemeId?: ThemeId;
  initialLogoMode?: LogoMode;
  initialFlashMode?: FlashMode;
  initialNotificationSettings?: NotificationSettings;
  initialSecuritySettings?: SecuritySettings;
  initialCustomThemes?: CustomThemes;
  settingsPath?: string;
  showLogo?: boolean;
};

function initState(data?: LoadedData): AppState {
  return {
    ...initialState,
    tasks: data?.tasks ?? [],
    tagIndex: data?.tagIndex ?? {},
    savedViews: data?.savedViews ?? [],
    engagement: data?.engagement ?? initialState.engagement,
    engagementToastQueue: [],
    engagementToastActive: null
  };
}

export function App({
  initialData,
  skipInitialSave = false,
  startupBanner,
  initialThemeId = "default",
  initialLogoMode = DEFAULT_LOGO_MODE,
  initialFlashMode = "slow",
  initialNotificationSettings = DEFAULT_NOTIFICATION_SETTINGS,
  initialSecuritySettings = DEFAULT_SECURITY_SETTINGS,
  initialCustomThemes = DEFAULT_CUSTOM_THEMES,
  settingsPath,
  showLogo = true
}: AppProps) {
  const renderer = useRenderer();
  const [state, dispatch] = useReducer(reducer, initialData, initState);
  const [settingsState, settingsDispatch] = useReducer(settingsReducer, {
    themeId: initialThemeId,
    logoMode: initialLogoMode,
    flashMode: initialFlashMode,
    notifications: initialNotificationSettings,
    security: initialSecuritySettings,
    customThemes: initialCustomThemes
  });
  const [uiState, uiDispatch] = useReducer(uiReducer, initialUIState);
  const [backupState, backupDispatch] = useReducer(
    backupCenterReducer,
    initialBackupCenterState
  );
  const [pulseOn, setPulseOn] = useState(false);
  const [fastPulseOn, setFastPulseOn] = useState(false);
  const [bottomInfoView, setBottomInfoView] = useState<BottomInfoView>("summary");
  const [rotatingThemeIndex, setRotatingThemeIndex] = useState(0);
  const [timeSuggestion, setTimeSuggestion] = useState<SuggestedTime | null>(null);
  const [saveFailureBanner, setSaveFailureBanner] = useState<string | null>(null);
  const [navigationBanner, setNavigationBanner] = useState<string | null>(null);
  const [pendingGPrefix, setPendingGPrefix] = useState(false);
  const [viewsOverlayOpen, setViewsOverlayOpen] = useState(false);
  const [selectedViewIndex, setSelectedViewIndex] = useState(0);
  const [saveViewPromptOpen, setSaveViewPromptOpen] = useState(false);
  const [saveViewName, setSaveViewName] = useState("");
  const [dashboardTagSelection, setDashboardTagSelection] = useState(0);
  const [selectedLinkId, setSelectedLinkId] = useState<string | undefined>(undefined);
  const [tagFilterDraft, setTagFilterDraft] = useState<TagFilter | undefined>(undefined);
  const [tagFilterInput, setTagFilterInput] = useState("");
  const [activeTagFilterBucket, setActiveTagFilterBucket] =
    useState<TagFilterBucket>("all");
  const [helpExpandedBySection, setHelpExpandedBySection] = useState<boolean[]>(
    createDefaultHelpExpandedState
  );
  const [helpFocusedSectionIndex, setHelpFocusedSectionIndex] = useState(0);
  const [helpScrollOffset, setHelpScrollOffset] = useState(0);
  const [helpNavStack, setHelpNavStack] = useState<HelpPage[]>(["help"]);
  const [helpNavSelection, setHelpNavSelection] = useState<HelpNavSelectionByPage>({
    settings: 0,
    theme: 0,
    custom1: 0,
    textTuning: 0,
    textTuningTheme: 0
  });
  const [helpPreviewThemeMode, setHelpPreviewThemeMode] = useState<ThemeId | null>(null);
  const [helpDraftLogoMode, setHelpDraftLogoMode] = useState<LogoMode | null>(null);
  const [helpTextTuningThemeId, setHelpTextTuningThemeId] = useState<RotatingThemeId>(
    HELP_TEXT_TUNING_THEMES[0] ?? "default"
  );
  const [custom1DraftGlobal, setCustom1DraftGlobal] = useState<ThemeTokens>(() =>
    resolveCustom1Config(initialCustomThemes).global
  );
  const [custom1DraftObjects, setCustom1DraftObjects] = useState<
    Partial<Record<ThemeObjectId, Partial<ThemeTokens>>>
  >(() => resolveCustom1Config(initialCustomThemes).objects ?? {});
  const [builtInTextDraftGlobal, setBuiltInTextDraftGlobal] = useState<ThemeTextTokenOverrides>(
    {}
  );
  const [builtInTextDraftObjects, setBuiltInTextDraftObjects] = useState<
    Partial<Record<ThemeObjectId, ThemeTextTokenOverrides>>
  >({});
  const skipInitialSaveRef = useRef(skipInitialSave);
  const skipSettingsSaveRef = useRef(true);
  const lastSuccessfulSaveAtRef = useRef<number | undefined>(undefined);
  const gPrefixTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navBannerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const previousTaskCountRef = useRef(state.tasks.length);
  const pendingCelebrateTaskIdRef = useRef<string | undefined>(undefined);
  const helpScrollTopRef = useRef(0);
  const helpFocusedSectionRef = useRef(0);
  const helpReturnContextRef = useRef({
    mode: Mode.LIST,
    focus: FocusTarget.TASK_LIST
  });
  const helpPreviewRestoreThemeRef = useRef<ThemeId | null>(null);
  const custom1EditorRef = useRef<Custom1ThemeEditorHandle | null>(null);
  const builtInTextEditorRef = useRef<BuiltInThemeTextEditorHandle | null>(null);
  const { height: terminalHeight, width: terminalWidth } = useTerminalDimensions();
  const terminalIsSupported = isTerminalSizeSupported(terminalWidth, terminalHeight);
  const terminalSizeWarning = getTerminalSizeWarning(terminalWidth, terminalHeight);
  const settingsRef = useRef(settingsState);
  const tasksRef = useRef(state.tasks);
  const notificationManagerRef = useRef<NotificationManager | null>(null);
  const modalBellNotifierRef = useRef<TerminalBellNotifier | null>(null);
  const evaluateNotificationsRef = useRef<(nowMs: number) => void>(() => {});

  settingsRef.current = settingsState;
  tasksRef.current = state.tasks;
  helpFocusedSectionRef.current = helpFocusedSectionIndex;

  if (!notificationManagerRef.current) {
    const inAppModalNotifier = new InAppModalNotifier({
      enqueueEvent: (event: TaskOverdueEvent) => {
        uiDispatch({ type: "enqueueNotificationModal", event });
      },
      isEnabled: () => {
        const notifications = settingsRef.current.notifications;
        return notifications.enabled && notifications.inAppOverdueBanner;
      }
    });
    modalBellNotifierRef.current = new TerminalBellNotifier({
      isEnabled: () => {
        const notifications = settingsRef.current.notifications;
        return notifications.enabled && notifications.terminalBellOnOverdue;
      },
      getCooldownMs: () => settingsRef.current.notifications.bellCooldownMs
    });
    const osNotifier = new OSNotifier();
    notificationManagerRef.current = new NotificationManager([
      inAppModalNotifier,
      osNotifier
    ]);
  }

  evaluateNotificationsRef.current = (nowMs: number) => {
    notificationManagerRef.current?.evaluate(tasksRef.current, nowMs);
  };

  // Force a frame request on mode/size transitions so borders are repainted
  // after layout shape changes (list/details <-> dashboard).
  useEffect(() => {
    renderer.requestRender();
  }, [renderer, uiState.mode, terminalWidth, terminalHeight]);

  const now = Date.now();
  const dayKey = startOfLocalDayMs(now);
  const visibleTaskRows = buildVisibleTaskRows(
    state.tasks,
    state.filters,
    state.sortMode,
    now
  );
  const selectedTask =
    visibleTaskRows.find((task) => task.id === state.selectedId) ?? visibleTaskRows[0];
  const activeHelpPage = helpNavStack[helpNavStack.length - 1] ?? "help";
  const persistedCustom1 = React.useMemo(
    () => resolveCustom1Config(settingsState.customThemes),
    [settingsState.customThemes]
  );
  const persistedBuiltInTextConfig = React.useMemo(
    () => resolveBuiltInThemeTextConfig(settingsState.customThemes, helpTextTuningThemeId),
    [helpTextTuningThemeId, settingsState.customThemes]
  );
  const builtInTextBaseTokens = React.useMemo(
    () => ({
      text: THEMES[helpTextTuningThemeId].text,
      mutedText: THEMES[helpTextTuningThemeId].mutedText,
      selectionText: THEMES[helpTextTuningThemeId].selectionText
    }),
    [helpTextTuningThemeId]
  );
  const custom1Draft: CustomThemeConfig = React.useMemo(
    () => ({
      global: custom1DraftGlobal,
      objects: Object.keys(custom1DraftObjects).length > 0 ? custom1DraftObjects : undefined
    }),
    [custom1DraftGlobal, custom1DraftObjects]
  );
  const builtInTextDraft: BuiltInThemeTextOverrides = React.useMemo(() => {
    const global = sanitizeThemeTextTokenOverrides(builtInTextDraftGlobal);
    const objects = sanitizeThemeTextObjectOverrides(builtInTextDraftObjects);
    if (!global && !objects) {
      return {};
    }
    const config: BuiltInThemeTextOverrideConfig = {};
    if (global) {
      config.global = global;
    }
    if (objects) {
      config.objects = objects;
    }
    return {
      [helpTextTuningThemeId]: config
    };
  }, [builtInTextDraftGlobal, builtInTextDraftObjects, helpTextTuningThemeId]);
  const clampedHelpFocusedSectionIndex = Math.max(
    0,
    Math.min(helpFocusedSectionIndex, HELP_MENU_SECTIONS.length - 1)
  );
  const { rows: helpRows, sections: helpSections } = React.useMemo(
    () => buildHelpRows(helpExpandedBySection),
    [helpExpandedBySection]
  );
  const helpNavItems =
    activeHelpPage === "settings"
      ? HELP_SETTINGS_NAV_ITEMS
      : activeHelpPage === "theme"
        ? HELP_THEME_NAV_ITEMS
      : activeHelpPage === "custom1"
        ? HELP_CUSTOM1_NAV_ITEMS
      : activeHelpPage === "textTuning"
        ? HELP_TEXT_TUNING_NAV_ITEMS
        : activeHelpPage === "textTuningTheme"
          ? HELP_TEXT_TUNING_THEME_NAV_ITEMS
          : [];
  const helpNavSelectionIndex =
    activeHelpPage === "settings"
      ? helpNavSelection.settings
      : activeHelpPage === "theme"
        ? helpNavSelection.theme
      : activeHelpPage === "custom1"
        ? helpNavSelection.custom1
        : activeHelpPage === "textTuning"
          ? helpNavSelection.textTuning
          : activeHelpPage === "textTuningTheme"
            ? helpNavSelection.textTuningTheme
          : 0;
  const clampedHelpNavSelectionIndex =
    helpNavItems.length === 0
      ? 0
      : Math.max(0, Math.min(helpNavSelectionIndex, helpNavItems.length - 1));
  const helpBodyLineCount =
    activeHelpPage === "help"
      ? helpRows.length
      : activeHelpPage === "custom1Edit" || activeHelpPage === "textTuningEdit"
        ? 22
        : Math.max(4, helpNavItems.length * 2 + 2);
  const helpPanelMaxWidth = Math.max(20, terminalWidth - HELP_PANEL_HORIZONTAL_MARGIN * 2);
  const helpPanelWidthMin = Math.min(HELP_PANEL_MIN_WIDTH, helpPanelMaxWidth);
  const helpPanelWidthMax = Math.min(HELP_PANEL_MAX_WIDTH, helpPanelMaxWidth);
  const helpPanelWidth = clampToBounds(
    Math.floor(terminalWidth * 0.9),
    helpPanelWidthMin,
    helpPanelWidthMax
  );
  const helpPanelMaxHeight = Math.max(8, terminalHeight - HELP_PANEL_VERTICAL_MARGIN * 2);
  const helpPanelDesiredHeight =
    helpBodyLineCount + HELP_PANEL_CHROME_ROWS + HELP_PANEL_BORDER_ROWS;
  const helpPanelHeight = clampToBounds(
    helpPanelDesiredHeight,
    Math.min(HELP_PANEL_MIN_HEIGHT, helpPanelMaxHeight),
    helpPanelMaxHeight
  );
  const helpPanelInnerWidth = Math.max(1, helpPanelWidth - HELP_PANEL_BORDER_COLS);
  const helpPanelInnerHeight = Math.max(1, helpPanelHeight - HELP_PANEL_BORDER_ROWS);
  const helpContentVisibleRows = Math.max(1, helpPanelInnerHeight - HELP_PANEL_CHROME_ROWS);
  const helpHasOverflow = helpBodyLineCount > helpContentVisibleRows;
  const helpFooterWidth = Math.max(1, helpPanelInnerWidth - 2);
  const helpCloseButtonLabel = pickHelpCloseButtonLabel(Math.max(0, helpFooterWidth - 1));
  const helpCloseButtonWidth = helpCloseButtonLabel ? helpCloseButtonLabel.length + 2 : 0;
  const helpFooterHintLineWidth = Math.max(
    1,
    helpFooterWidth - helpCloseButtonWidth - (helpCloseButtonWidth > 0 ? 1 : 0)
  );
  // Reserve one column when Help content overflows so wrapped lines do not add
  // phantom rows and desync focus scroll math.
  const helpContentLineWidth = Math.max(1, helpFooterWidth - (helpHasOverflow ? 1 : 0));
  const helpPageStep = Math.max(1, helpContentVisibleRows - 1);
  const clampedHelpScrollOffset = clampScrollOffset(
    helpScrollOffset,
    helpContentVisibleRows,
    helpRows.length
  );
  const helpVisibleRows =
    activeHelpPage === "help"
      ? helpRows.slice(
          clampedHelpScrollOffset,
          clampedHelpScrollOffset + helpContentVisibleRows
        )
      : helpRows;
  const helpScrollbarThumb =
    activeHelpPage === "help"
      ? computeHelpScrollbarThumb({
          scrollOffset: clampedHelpScrollOffset,
          visibleRows: helpContentVisibleRows,
          itemCount: helpRows.length
        })
      : null;
  const helpFooterHintsRaw =
    activeHelpPage === "help"
      ? helpHasOverflow
        ? "1 Backup Center | Enter/Right on Settings opens Settings pages | Up/Down focus | Enter/Space expand | Left collapse | Esc close | Scroll"
        : "1 Backup Center | Enter/Right on Settings opens Settings pages | Up/Down focus | Enter/Space expand | Left collapse | Esc close"
      : activeHelpPage === "custom1Edit" || activeHelpPage === "textTuningEdit"
        ? "S save | C/Esc cancel | R reset token | Tab next focus | Arrows adjust/jump | Enter commit"
        : activeHelpPage === "settings" &&
            clampedHelpNavSelectionIndex === HELP_SETTINGS_LOGO_NAV_INDEX
          ? "Left/Right preview logo | Enter commit | Esc/Backspace back"
        : "Up/Down move | Enter/Right select | Left/Backspace/Esc back";
  const helpFooterHintsLine = fitLineToWidth(
    helpFooterHintsRaw,
    helpFooterHintLineWidth
  );
  const helpFooterDataPathLine = fitLineToWidth(
    `Data path: ${redactPathForDisplay(getDataFilePath())}`,
    helpFooterWidth
  );
  const helpHeaderTitle =
    activeHelpPage === "help"
      ? "Help"
      : activeHelpPage === "settings"
        ? "Help / Settings"
        : activeHelpPage === "theme"
          ? "Help / Settings / Theme"
          : activeHelpPage === "custom1"
            ? "Help / Settings / Theme / Custom1"
            : activeHelpPage === "custom1Edit"
              ? "Help / Settings / Theme / Custom1 / Edit Colors"
              : activeHelpPage === "textTuning"
                ? "Help / Settings / Theme / Text Tuning"
                : activeHelpPage === "textTuningTheme"
                  ? `Help / Settings / Theme / Text Tuning / ${formatThemeIdLabel(helpTextTuningThemeId)}`
                  : `Help / Settings / Theme / Text Tuning / ${formatThemeIdLabel(helpTextTuningThemeId)} / Edit Text Colors`;
  const helpTheme = themeForObject("help");
  const modalTheme = themeForObject("modal");
  const inputTheme = themeForObject("inputs");
  const notificationsTheme = themeForObject("notifications");
  const taskListTheme = themeForObject("taskList");
  const dashboardTheme = themeForObject("dashboard");

  function findTaskById(taskId: string | undefined): Task | undefined {
    if (!taskId) return undefined;
    return state.tasks.find((task) => task.id === taskId);
  }

  function findTaskForOverdueEvent(event: TaskOverdueEvent): Task | undefined {
    return findTaskById(event.taskId);
  }

  function findSeriesTaskBySeriesId(seriesId: string | undefined): Task | undefined {
    if (!seriesId) return undefined;
    return state.tasks.find((task) => task.recurrence?.series_id === seriesId);
  }

  function findMaterializedInstance(
    seriesId: string | undefined,
    occurrenceIso: string | undefined
  ): Task | undefined {
    if (!seriesId || !occurrenceIso) return undefined;
    return state.tasks.find(
      (task) =>
        task.instance_of?.series_id === seriesId &&
        task.instance_of?.occurrence === occurrenceIso
    );
  }

  function resolvePersistedTaskForRow(row: VisibleTaskRow | undefined): Task | undefined {
    if (!row) return undefined;
    if (row.rowKind === "series_occurrence_virtual") {
      return findTaskById(row.sourceTaskId);
    }
    return findTaskById(row.id);
  }

  const selectedPersistedTask = resolvePersistedTaskForRow(selectedTask);
  const selectedTaskLinks = selectedPersistedTask?.links ?? [];
  const selectedTaskLinkIdsKey = selectedTaskLinks.map((link) => link.id).join("|");
  const selectedTaskLink = selectedTaskLinks.find((link) => link.id === selectedLinkId);

  const listHeaderHeight = 2;
  const topBarHeight = 4;
  const bottomBarHeight = 3;
  const activeBanners = [startupBanner, saveFailureBanner, navigationBanner].filter(
    (value): value is string => Boolean(value)
  );
  const bannerHeight = activeBanners.length;
  const listPanelBorder = 2;
  const listPanelPadding = 2;
  const searchHeight = uiState.mode === Mode.SEARCH ? 3 : 0;
  const taskRowHeight = 3; // Keep in sync with TaskRow layout height.
  const listContentHeight =
    terminalHeight -
    topBarHeight -
    bottomBarHeight -
    bannerHeight -
    listHeaderHeight -
    listPanelBorder -
    listPanelPadding -
    searchHeight;
  const visibleLines = Math.max(1, listContentHeight);
  const visibleRows = Math.max(1, Math.floor(visibleLines / taskRowHeight));
  const editorPaneHeightLines = Math.max(
    1,
    terminalHeight -
      topBarHeight -
      bottomBarHeight -
      bannerHeight -
      listHeaderHeight -
      listPanelBorder -
      listPanelPadding
  );
  const { contentHeight: editorContentVisibleLines } =
    getEditorViewportHeights(editorPaneHeightLines);
  const editorPageStep = Math.max(1, editorContentVisibleLines - 1);
  const dashboardPaneWidth = Math.max(20, terminalWidth - layout.railWidth - 4);
  const dashboardPaneHeight = Math.max(
    8,
    terminalHeight - topBarHeight - bottomBarHeight - bannerHeight - 4
  );
  const startOfToday = dayKey;
  const selectedDayDiff =
    selectedTask && selectedTask.status === "open" && selectedTask.dueAt !== undefined
      ? diffLocalDays(selectedTask.dueAt, startOfToday)
      : null;
  const selectedHasTime = selectedTask?.hasExplicitTime === true;
  const selectedTimeOverdue =
    selectedTask &&
    selectedTask.status === "open" &&
    selectedHasTime &&
    selectedDayDiff === 0 &&
    selectedTask.dueAt !== undefined &&
    now > selectedTask.dueAt;
  const selectedDueToday = selectedDayDiff === 0 && !selectedTimeOverdue;
  const selectedDueSoon =
    selectedDayDiff !== null && selectedDayDiff >= 1 && selectedDayDiff <= 7;
  const selectedDueLater = selectedDayDiff !== null && selectedDayDiff >= 8;
  const selectedOverdue =
    selectedDayDiff !== null && (selectedDayDiff < 0 || selectedTimeOverdue);
  const isStaticFlashMode = settingsState.flashMode === "static";
  const visibleBaseMode =
    uiState.mode === Mode.TAG_FILTER ? uiState.previousMode : uiState.mode;
  const isDashboardMode = visibleBaseMode === Mode.DASHBOARD;
  const isBackupMode = visibleBaseMode === Mode.BACKUP_CENTER;
  const selectedHeaderBackground = isBackupMode
    ? theme.accentBlue
    : selectedOverdue
      ? isStaticFlashMode
        ? theme.warn
        : fastPulseOn
          ? theme.warn
          : theme.dueSoon
      : selectedDueToday
        ? theme.dueSoon
        : selectedDueSoon
          ? theme.dueSoon
          : selectedDueLater
            ? theme.dueLater
            : selectedTask?.status === "done"
              ? theme.ok
              : theme.accentOrange;

  const summaryOverdueRows = React.useMemo(
    () => buildVisibleTaskRows(state.tasks, { status: "open", due: "overdue" }, state.sortMode, now),
    [state.tasks, state.sortMode, now]
  );
  const summaryTodayRows = React.useMemo(
    () => buildVisibleTaskRows(state.tasks, { status: "open", due: "today" }, state.sortMode, now),
    [state.tasks, state.sortMode, now]
  );
  const summaryNext7Rows = React.useMemo(
    () => buildVisibleTaskRows(state.tasks, { status: "open", due: "next7" }, state.sortMode, now),
    [state.tasks, state.sortMode, now]
  );
  const summaryDoneRows = React.useMemo(
    () => buildVisibleTaskRows(state.tasks, { status: "done", due: "any" }, state.sortMode, now),
    [state.tasks, state.sortMode, now]
  );
  const summary = summaryDoneRows.reduce(
    (acc, task) => {
      const closedAt = task.closedAt ?? task.updatedAt;
      const closedDiff = diffLocalDays(closedAt, startOfToday);
      if (closedDiff <= 0 && closedDiff >= -6) {
        acc.completed7 += 1;
      }
      return acc;
    },
    {
      overdue: summaryOverdueRows.length,
      today: summaryTodayRows.length,
      next7: summaryNext7Rows.length,
      completed7: 0
    }
  );

  const summaryTagRows = React.useMemo(
    () => buildVisibleTaskRows(state.tasks, { status: "all", due: "any" }, state.sortMode, now),
    [state.tasks, state.sortMode, now]
  );

  const tagStats = React.useMemo(
    () => computeTopTagStats(summaryTagRows, dayKey, 5),
    [summaryTagRows, dayKey]
  );
  const openPriorityStats = React.useMemo(
    () => computeOpenPriorityStats(state.tasks),
    [state.tasks]
  );

  const bottomBarWidth = Math.max(0, terminalWidth - layout.railWidth);
  const bottomBarContentWidth = Math.max(0, bottomBarWidth - 2);
  const tagTickerSegments = React.useMemo(
    () => buildTagTickerSegments(tagStats, bottomBarContentWidth),
    [tagStats, bottomBarContentWidth]
  );
  const priorityTickerSegments = React.useMemo(
    () => buildPriorityTickerSegments(openPriorityStats, bottomBarContentWidth),
    [openPriorityStats, bottomBarContentWidth]
  );
  const priorityTickerNeedsWiderLayout =
    openPriorityStats.length > 0 && priorityTickerSegments.length === 0;
  const dashboardTopTagLimit = React.useMemo(
    () => resolveDashboardTopTagLimit(dashboardPaneHeight),
    [dashboardPaneHeight]
  );
  const dashboardTopTags = React.useMemo(
    () => computeTopTagsOpen(visibleTaskRows, dashboardTopTagLimit),
    [visibleTaskRows, dashboardTopTagLimit]
  );
  const clampedDashboardTagSelection =
    dashboardTopTags.length === 0
      ? 0
      : Math.max(0, Math.min(dashboardTagSelection, dashboardTopTags.length - 1));
  const overdueQuickFilterActive =
    state.filters.status === "open" && state.filters.due === "overdue";
  const todayQuickFilterActive =
    state.filters.status === "open" && state.filters.due === "today";
  const next7QuickFilterActive =
    state.filters.status === "open" && state.filters.due === "next7";
  const doneQuickFilterActive =
    state.filters.status === "done" && state.filters.due === "any";

  const tagQuery = state.editor ? getTagQuery(state.editor.tagsText) : null;
  const tagSuggestions = tagQuery ? rankTags(state.tagIndex, tagQuery) : [];
  const tagInlineSuggestion = tagQuery
    ? getTagCompletion(tagQuery, tagSuggestions)
    : null;
  const tagFilterQuery = uiState.mode === Mode.TAG_FILTER
    ? normalizeTagPrefix(tagFilterInput)
    : "";
  const tagFilterSuggestions = tagFilterQuery
    ? rankTags(state.tagIndex, tagFilterQuery)
    : [];
  const tagFilterInlineSuggestion = tagFilterQuery
    ? getTagCompletion(tagFilterQuery, tagFilterSuggestions)
    : null;
  const selectedThemeMode = helpPreviewThemeMode ?? settingsState.themeId;
  const activeThemeId =
    selectedThemeMode === "rotating"
      ? ROTATING_THEME_ORDER[rotatingThemeIndex % ROTATING_THEME_ORDER.length]
      : selectedThemeMode;
  const helpThemeStatusLineRaw = helpPreviewThemeMode
    ? `Theme mode: ${formatThemeDisplayName(settingsState.themeId)} (preview: ${formatThemeDisplayName(helpPreviewThemeMode)})`
    : settingsState.themeId === "rotating"
      ? `Theme mode: Rotating (active: ${formatThemeDisplayName(activeThemeId)})`
      : `Theme mode: ${formatThemeDisplayName(settingsState.themeId)}`;
  const effectiveLogoModeForHelp = helpDraftLogoMode ?? settingsState.logoMode;
  const helpLogoStatusLineRaw =
    helpDraftLogoMode && helpDraftLogoMode !== settingsState.logoMode
      ? `Logo: ${formatLogoModeLabel(settingsState.logoMode)} (preview: ${formatLogoModeLabel(helpDraftLogoMode)})`
      : `Logo: ${formatLogoModeLabel(settingsState.logoMode)}`;
  const helpThemeStatusLine = fitLineToWidth(
    `    ${helpThemeStatusLineRaw}`,
    helpContentLineWidth
  );
  const helpLogoStatusLine = fitLineToWidth(
    `    ${helpLogoStatusLineRaw}`,
    helpContentLineWidth
  );
  const helpFlashStatusLine = fitLineToWidth(
    `    Flash mode: ${settingsState.flashMode}`,
    helpContentLineWidth
  );
  const helpNotificationsEnabledStatusLine = fitLineToWidth(
    `    Notifications: ${settingsState.notifications.enabled ? "on" : "off"}`,
    helpContentLineWidth
  );
  const helpInAppBannerStatusLine = fitLineToWidth(
    `    Overdue popup: ${settingsState.notifications.inAppOverdueBanner ? "on" : "off"}`,
    helpContentLineWidth
  );
  const helpTerminalBellStatusLine = fitLineToWidth(
    `    Terminal bell: ${settingsState.notifications.terminalBellOnOverdue ? "on" : "off"}`,
    helpContentLineWidth
  );
  const dueSuggestion =
    uiState.focus === FocusTarget.EDITOR_DUE_DATE && state.editor
      ? getDueSuggestion(state.editor.dueText, now)
      : null;
  const dueSuggestionHint = dueSuggestion ? `→ ${dueSuggestion} (press →)` : null;

  const timeAutocompleteStep =
    uiState.mode === Mode.ADD &&
    uiState.focus === FocusTarget.EDITOR_DUE_TIME &&
    state.editor &&
    timeSuggestion
      ? getAutocompleteStep(state.editor.timeText, timeSuggestion)
      : "none";
  const timeSuggestionHint =
    timeAutocompleteStep === "hour" && timeSuggestion
      ? `→ ${timeSuggestion.hh}`
      : timeAutocompleteStep === "minute" && timeSuggestion
        ? `→ ${timeSuggestion.hh}:${timeSuggestion.mm}`
        : null;
  const editorDueTime = state.editor
    ? combineDueDateTime(state.editor.dueText, state.editor.timeText)
    : { dueAt: undefined, hasExplicitTime: false };
  const recurrencePreview = state.editor
    ? buildRecurrencePreviewFromDraft(
        state.editor,
        editorDueTime.dueAt,
        editorDueTime.hasExplicitTime,
        now,
        3
      )
    : [];
  const activeOverdueModal =
    uiState.mode === Mode.MODAL_CONFIRM && uiState.modal?.type === "overdue"
      ? uiState.modal
      : null;
  const activeOverdueTask = activeOverdueModal
    ? findTaskForOverdueEvent(activeOverdueModal.event)
    : undefined;
  const isNuxIdle =
    uiState.modal === null &&
    uiState.notificationModalQueue.length === 0 &&
    uiState.mode === Mode.LIST;
  const activeEmptyNuxStep: EmptyNuxStep = uiState.emptyNux?.step ?? "welcome";
  const blockingOverlayOpen = isBlockingOverlayOpen(uiState);
  const activeEngagementToast =
    !blockingOverlayOpen && state.engagementToastActive ? state.engagementToastActive : null;
  const engagementToastLine = activeEngagementToast
    ? fitLineToWidth(
        activeEngagementToast.message,
        Math.max(1, bottomBarWidth - 4)
      )
    : "";
  const renderStartMs = Date.now();

  function formatSaveTimestamp(epochMs: number): string {
    const date = new Date(epochMs);
    const yyyy = String(date.getFullYear());
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const hh = String(date.getHours()).padStart(2, "0");
    const mi = String(date.getMinutes()).padStart(2, "0");
    const ss = String(date.getSeconds()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${mi}:${ss}`;
  }

  function handleSaveResult(result: SaveStateResult): void {
    if (result.ok) {
      lastSuccessfulSaveAtRef.current = result.savedAt;
      setSaveFailureBanner(null);
      return;
    }

    const lastSavedAt = result.lastSuccessfulSaveAt ?? lastSuccessfulSaveAtRef.current;
    const summary = result.error.message || "Unknown persistence error";
    const lastSaveText = lastSavedAt
      ? ` | Last successful save: ${formatSaveTimestamp(lastSavedAt)}`
      : "";
    setSaveFailureBanner(
      `Save failed: ${summary} | Path: ${result.filePath}${lastSaveText}`
    );
  }

  useEffect(() => {
    const id = setInterval(() => {
      const { data, changed } = applyArchiveAging(
        {
          schemaVersion: CURRENT_SCHEMA_VERSION,
          tasks: state.tasks,
          tagIndex: state.tagIndex,
          savedViews: state.savedViews,
          engagement: state.engagement
        },
        Date.now()
      );
      if (changed) {
        dispatch({ type: "setTasks", tasks: data.tasks });
      }
    }, 60 * 60 * 1000);
    return () => clearInterval(id);
  }, [state.tasks, state.tagIndex, state.engagement, state.savedViews]);

  useEffect(() => {
    if (isStaticFlashMode) {
      setPulseOn(false);
      return;
    }
    const id = setInterval(() => {
      setPulseOn((prev) => !prev);
    }, SLOW_PULSE_INTERVAL_MS);
    return () => clearInterval(id);
  }, [isStaticFlashMode]);

  useEffect(() => {
    if (isStaticFlashMode) {
      setFastPulseOn(false);
      return;
    }
    const id = setInterval(() => {
      setFastPulseOn((prev) => !prev);
    }, FAST_PULSE_INTERVAL_MS);
    return () => clearInterval(id);
  }, [isStaticFlashMode]);

  useEffect(() => {
    const id = setInterval(() => {
      setBottomInfoView((prev) => {
        const index = BOTTOM_INFO_VIEW_ORDER.indexOf(prev);
        const safeIndex = index === -1 ? 0 : index;
        const nextIndex = (safeIndex + 1) % BOTTOM_INFO_VIEW_ORDER.length;
        return BOTTOM_INFO_VIEW_ORDER[nextIndex] ?? "summary";
      });
    }, TICKER_INTERVAL_MS);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      evaluateNotificationsRef.current(Date.now());
    }, NOTIFICATION_EVALUATION_INTERVAL_MS);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      dispatch({
        type: "tickEngagementToast",
        now: Date.now(),
        overlayBlocked: blockingOverlayOpen
      });
    }, ENGAGEMENT_TOAST_TICK_INTERVAL_MS);
    return () => clearInterval(id);
  }, [blockingOverlayOpen]);

  useEffect(() => {
    evaluateNotificationsRef.current(Date.now());
  }, [state.tasks]);

  useEffect(() => {
    if (state.tasks.length !== 0) return;
    if (uiState.emptyNuxDismissed) {
      return;
    }
    if (!isNuxIdle) return;
    openEmptyNuxModal({ step: "welcome" });
  }, [
    state.tasks.length,
    uiState.emptyNuxDismissed,
    isNuxIdle
  ]);

  useEffect(() => {
    if (uiState.emptyNux?.step !== "adding") return;
    if (state.tasks.length !== 0) return;
    if (uiState.emptyNuxDismissed) return;
    if (!isNuxIdle) return;
    openEmptyNuxModal({
      step: "welcome",
      startedFromNux: true,
      createdTaskId: uiState.emptyNux.createdTaskId
    });
  }, [
    state.tasks.length,
    uiState.emptyNux?.step,
    uiState.emptyNux?.createdTaskId,
    uiState.emptyNuxDismissed,
    isNuxIdle
  ]);

  useEffect(() => {
    const previousTaskCount = previousTaskCountRef.current;
    const nextTaskCount = state.tasks.length;
    const transitionedFromEmptyToNonEmpty = previousTaskCount === 0 && nextTaskCount > 0;

    if (
      transitionedFromEmptyToNonEmpty &&
      uiState.emptyNux?.step === "adding" &&
      uiState.emptyNux.startedFromNux === true
    ) {
      const createdTaskId = state.selectedId;
      if (isNuxIdle) {
        openEmptyNuxModal({
          step: "celebrate",
          startedFromNux: true,
          createdTaskId
        });
      } else {
        pendingCelebrateTaskIdRef.current = createdTaskId;
        uiDispatch(setEmptyNuxCelebratePending(true));
      }
    }

    previousTaskCountRef.current = nextTaskCount;
  }, [
    state.tasks.length,
    state.selectedId,
    uiState.emptyNux?.step,
    uiState.emptyNux?.startedFromNux,
    isNuxIdle
  ]);

  useEffect(() => {
    if (!uiState.emptyNuxCelebratePending) return;
    if (!isNuxIdle) return;

    uiDispatch(setEmptyNuxCelebratePending(false));
    openEmptyNuxModal({
      step: "celebrate",
      startedFromNux: true,
      createdTaskId: pendingCelebrateTaskIdRef.current
    });
    pendingCelebrateTaskIdRef.current = undefined;
  }, [uiState.emptyNuxCelebratePending, isNuxIdle]);

  useEffect(() => {
    if (state.tasks.length === 0) return;
    if (uiState.modal?.type !== "emptyNux") return;
    if (uiState.emptyNux?.startedFromNux === true) return;
    uiDispatch(clearEmptyNux());
  }, [state.tasks.length, uiState.modal, uiState.emptyNux?.startedFromNux]);

  useEffect(() => {
    if (
      !settingsState.notifications.enabled ||
      !settingsState.notifications.inAppOverdueBanner
    ) {
      return;
    }
    if (uiState.modal) return;
    if (uiState.notificationModalQueue.length === 0) return;

    const nextEvent = uiState.notificationModalQueue[0];
    const previousMode = uiState.mode === Mode.MODAL_CONFIRM ? Mode.LIST : uiState.mode;
    const previousFocus =
      uiState.mode === Mode.MODAL_CONFIRM ? FocusTarget.TASK_LIST : uiState.focus;

    uiDispatch({ type: "dequeueNotificationModal" });
    uiDispatch({
      type: "setModal",
      modal: {
        type: "overdue",
        event: nextEvent,
        previousMode,
        previousFocus
      }
    });
    uiDispatch({ type: "setMode", mode: Mode.MODAL_CONFIRM });
    uiDispatch({ type: "setFocus", focus: FocusTarget.MODAL });
    modalBellNotifierRef.current?.notify(nextEvent);
  }, [
    settingsState.notifications.enabled,
    settingsState.notifications.inAppOverdueBanner,
    uiState.modal,
    uiState.mode,
    uiState.focus,
    uiState.notificationModalQueue
  ]);

  useEffect(() => {
    if (
      settingsState.notifications.enabled &&
      settingsState.notifications.inAppOverdueBanner
    ) {
      return;
    }
    if (uiState.notificationModalQueue.length > 0) {
      uiDispatch({ type: "clearNotificationModalQueue" });
    }
    if (uiState.modal?.type === "overdue") {
      applyEscUnwind();
    }
  }, [
    settingsState.notifications.enabled,
    settingsState.notifications.inAppOverdueBanner,
    uiState.modal,
    uiState.notificationModalQueue.length
  ]);

  useEffect(() => {
    return () => {
      if (gPrefixTimerRef.current) {
        clearTimeout(gPrefixTimerRef.current);
      }
      if (navBannerTimerRef.current) {
        clearTimeout(navBannerTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (uiState.mode !== Mode.LIST || uiState.focus !== FocusTarget.TASK_LIST) {
      clearPendingGPrefix();
      setViewsOverlayOpen(false);
      setSaveViewPromptOpen(false);
    }
  }, [uiState.mode, uiState.focus]);

  useEffect(() => {
    if (uiState.mode === Mode.TAG_FILTER) return;
    setTagFilterInput("");
    setTagFilterDraft(undefined);
    setActiveTagFilterBucket("all");
  }, [uiState.mode]);

  useEffect(() => {
    if (state.savedViews.length === 0) {
      setSelectedViewIndex(0);
      return;
    }
    if (selectedViewIndex >= state.savedViews.length) {
      setSelectedViewIndex(state.savedViews.length - 1);
    }
  }, [selectedViewIndex, state.savedViews.length]);

  useEffect(() => {
    if (settingsState.themeId === "rotating") return;
    const index = ROTATING_THEME_ORDER.indexOf(settingsState.themeId);
    if (index >= 0) {
      setRotatingThemeIndex(index);
    }
  }, [settingsState.themeId]);

  useEffect(() => {
    if (settingsState.themeId !== "rotating") return;
    const id = setInterval(() => {
      setRotatingThemeIndex((prev) => (prev + 1) % ROTATING_THEME_ORDER.length);
    }, ROTATING_THEME_INTERVAL_MS);
    return () => clearInterval(id);
  }, [settingsState.themeId]);

  useEffect(() => {
    if (
      activeHelpPage !== "settings" ||
      clampedHelpNavSelectionIndex !== HELP_SETTINGS_LOGO_NAV_INDEX
    ) {
      setHelpDraftLogoMode(null);
    }
  }, [activeHelpPage, clampedHelpNavSelectionIndex]);

  useEffect(() => {
    applyThemeWithSettings(activeThemeId, settingsState, {
      draft:
        uiState.mode === Mode.HELP && activeHelpPage === "custom1Edit"
          ? custom1Draft
          : undefined,
      builtInTextDraft:
        uiState.mode === Mode.HELP && activeHelpPage === "textTuningEdit"
          ? builtInTextDraft
          : undefined
    });
  }, [
    activeHelpPage,
    activeThemeId,
    builtInTextDraft,
    custom1Draft,
    settingsState,
    uiState.mode
  ]);

  useEffect(() => {
    if (skipSettingsSaveRef.current) {
      skipSettingsSaveRef.current = false;
      return;
    }
    saveSettingsDebounced(
      {
        themeId: settingsState.themeId,
        logoMode: settingsState.logoMode,
        flashMode: settingsState.flashMode,
        notifications: settingsState.notifications,
        security: settingsState.security,
        customThemes: settingsState.customThemes
      },
      150,
      settingsPath ? { filePath: settingsPath } : {}
    );
  }, [
    settingsPath,
    settingsState.customThemes,
    settingsState.flashMode,
    settingsState.logoMode,
    settingsState.notifications,
    settingsState.security,
    settingsState.themeId
  ]);

  useEffect(() => {
    if (skipInitialSaveRef.current) {
      skipInitialSaveRef.current = false;
      return;
    }
    saveStateDebounced(
      {
        schemaVersion: CURRENT_SCHEMA_VERSION,
        tasks: state.tasks,
        tagIndex: state.tagIndex,
        savedViews: state.savedViews,
        engagement: state.engagement
      },
      350,
      undefined,
      undefined,
      handleSaveResult
    );
  }, [state.tasks, state.tagIndex, state.savedViews, state.engagement]);

  useEffect(() => {
    if (!PERF_DEBUG_ENABLED) return;
    const durationMs = Date.now() - renderStartMs;
    console.log(
      `[${APP_NAME}][perf] render=${durationMs}ms terminal=${terminalWidth}x${terminalHeight} visibleRows=${visibleRows} visibleTaskRows=${visibleTaskRows.length}`
    );
  });

  useEffect(() => {
    const reconciled = reconcileSelectionById(
      visibleTaskRows,
      state.selectedId,
      uiState.selectedIndex
    );

    if (reconciled.selectedId !== state.selectedId) {
      dispatch({ type: "setSelected", id: reconciled.selectedId });
    }
    if (reconciled.selectedIndex !== uiState.selectedIndex) {
      uiDispatch({ type: "setSelectedIndex", selectedIndex: reconciled.selectedIndex });
    }
    if (visibleTaskRows.length === 0 && uiState.scrollOffset !== 0) {
      uiDispatch({ type: "setScrollOffset", scrollOffset: 0 });
    }
  }, [visibleTaskRows, state.selectedId, uiState.selectedIndex, uiState.scrollOffset]);

  useEffect(() => {
    const clamped = clampScrollOffset(
      uiState.scrollOffset,
      visibleRows,
      visibleTaskRows.length
    );
    const nextOffset = ensureSelectedVisible({
      selectedIndex: uiState.selectedIndex,
      scrollOffset: clamped,
      visibleRows,
      itemCount: visibleTaskRows.length
    });
    if (nextOffset !== uiState.scrollOffset) {
      uiDispatch({ type: "setScrollOffset", scrollOffset: nextOffset });
    }
  }, [uiState.scrollOffset, uiState.selectedIndex, visibleRows, visibleTaskRows.length]);

  useEffect(() => {
    if (selectedTaskLinks.length === 0) {
      if (selectedLinkId !== undefined) {
        setSelectedLinkId(undefined);
      }
      return;
    }

    if (selectedLinkId && selectedTaskLinks.some((link) => link.id === selectedLinkId)) {
      return;
    }

    setSelectedLinkId(selectedTaskLinks[0]?.id);
  }, [selectedLinkId, selectedTaskLinkIdsKey, selectedPersistedTask?.id]);

  useEffect(() => {
    if (dashboardTopTags.length === 0) {
      if (dashboardTagSelection !== 0) {
        setDashboardTagSelection(0);
      }
      return;
    }
    if (dashboardTagSelection > dashboardTopTags.length - 1) {
      setDashboardTagSelection(dashboardTopTags.length - 1);
    }
  }, [dashboardTagSelection, dashboardTopTags.length]);

  function getCurrentHelpScrollTop(): number {
    const current = Number.isFinite(helpScrollTopRef.current)
      ? helpScrollTopRef.current
      : helpScrollOffset;
    return clampScrollOffset(current, helpContentVisibleRows, helpRows.length);
  }

  function scrollHelpTo(offset: number): number {
    const clamped = clampScrollOffset(offset, helpContentVisibleRows, helpRows.length);
    helpScrollTopRef.current = clamped;
    setHelpScrollOffset((prev) => (prev === clamped ? prev : clamped));
    return clamped;
  }

  function ensureHelpSectionVisibleNow(sectionIndex: number): number {
    const clampedSectionIndex = Math.max(
      0,
      Math.min(sectionIndex, HELP_MENU_SECTIONS.length - 1)
    );
    const section = helpSections[clampedSectionIndex] ?? helpSections[0];
    const nextOffset = ensureHelpSectionVisible({
      section,
      scrollOffset: getCurrentHelpScrollTop(),
      visibleRows: helpContentVisibleRows,
      itemCount: helpRows.length,
      paddingRows: HELP_SECTION_SCROLL_PADDING
    });
    return scrollHelpTo(nextOffset);
  }

  useLayoutEffect(() => {
    if (uiState.mode !== Mode.HELP || activeHelpPage !== "help") return;
    const clampedIndex = Math.max(
      0,
      Math.min(helpFocusedSectionIndex, HELP_MENU_SECTIONS.length - 1)
    );
    if (clampedIndex !== helpFocusedSectionIndex) {
      helpFocusedSectionRef.current = clampedIndex;
      setHelpFocusedSectionIndex(clampedIndex);
    }
    ensureHelpSectionVisibleNow(clampedIndex);
  }, [
    uiState.mode,
    activeHelpPage,
    helpFocusedSectionIndex,
    helpRows.length,
    helpSections,
    helpContentVisibleRows,
    helpExpandedBySection,
    helpPanelWidth,
    helpPanelHeight,
    helpPanelInnerWidth,
    helpPanelInnerHeight
  ]);

  useEffect(() => {
    if (uiState.mode !== Mode.HELP) return;
    renderer.requestRender();
  }, [
    renderer,
    uiState.mode,
    activeHelpPage,
    helpPanelWidth,
    helpPanelHeight,
    helpPanelInnerWidth,
    helpPanelInnerHeight,
    helpBodyLineCount,
    helpRows.length,
    helpExpandedBySection,
    helpNavSelection,
    helpScrollOffset,
    helpFooterHintsLine,
    helpFooterDataPathLine,
    custom1Draft,
    builtInTextDraft,
    helpTextTuningThemeId
  ]);

  function applyEscUnwind(): boolean {
    if (uiState.mode === Mode.HELP) {
      closeHelp();
      return true;
    }
    const next = unwind(uiState);
    if (!next) return false;
    if (uiState.mode === Mode.BACKUP_CENTER) {
      backupDispatch({ type: "reset" });
    }
    if (next.clearEditorDraft) {
      setTimeSuggestion(null);
      dispatch({ type: "setEditor", editor: null });
    }
    uiDispatch({
      type: "replace",
      state: next.clearEditorDraft
        ? { ...next.state, editorScrollOffset: 0 }
        : next.state
    });
    return true;
  }

  function openBackupError(
    message: string,
    error?: unknown,
    returnScreen?: BackupCenterFlowScreen
  ) {
    backupDispatch({
      type: "setError",
      message,
      detail: error ? normalizeErrorDetail(error) : undefined,
      returnScreen
    });
  }

  function resolveConfiguredCalendarTimeZone(settings: unknown): string | undefined {
    if (typeof settings !== "object" || settings === null) return undefined;
    const record = settings as Record<string, unknown>;
    const timeZone = record.timeZone ?? record.timezone;
    if (typeof timeZone !== "string") return undefined;
    const trimmed = timeZone.trim();
    return trimmed.length > 0 ? trimmed : undefined;
  }

  async function refreshCalendarTimeZoneHint() {
    try {
      const settingsResult = await loadSettings();
      const fromSettings = resolveConfiguredCalendarTimeZone(settingsResult.settings);
      const fromSystem = Intl.DateTimeFormat().resolvedOptions().timeZone;
      backupDispatch({
        type: "setCalendarTimeZoneHint",
        value: fromSettings ?? fromSystem ?? undefined
      });
    } catch {
      const fromSystem = Intl.DateTimeFormat().resolvedOptions().timeZone;
      backupDispatch({
        type: "setCalendarTimeZoneHint",
        value: fromSystem ?? undefined
      });
    }
  }

  async function refreshRuntimeStateFromDisk() {
    const dataPath = getResolvedDataPath();
    const stateResult = await loadStateStrict({ filePath: dataPath });
    dispatch({ type: "load", data: stateResult.data });
    const settingsResult = await loadSettings();
    settingsDispatch({ type: "setTheme", themeId: settingsResult.settings.themeId });
    settingsDispatch({
      type: "setLogoMode",
      logoMode: settingsResult.settings.logoMode
    });
    settingsDispatch({
      type: "setFlashMode",
      flashMode: settingsResult.settings.flashMode
    });
    settingsDispatch({
      type: "setNotifications",
      notifications: settingsResult.settings.notifications
    });
    settingsDispatch({
      type: "setSecurity",
      security: settingsResult.settings.security
    });
    settingsDispatch({
      type: "setCustomThemes",
      customThemes: settingsResult.settings.customThemes
    });
  }

  function runBackupExportFlow() {
    if (backupState.screen === "exporting") return;
    backupDispatch({ type: "startExport" });
    void (async () => {
      try {
        const outputPath = await buildTimestampedBackupPath();
        const result = await exportBackup({
          outputPath,
          pretty: true
        });
        backupDispatch({ type: "exportSucceeded", outputPath: result.outputPath });
      } catch (error: unknown) {
        openBackupError("Export failed", error, "menu");
      }
    })();
  }

  function runBackupDryRunFlow(options: {
    inputPath?: string;
    mode?: "merge" | "replace";
    replaceConfirmed?: boolean;
  } = {}) {
    const inputPath = (options.inputPath ?? backupState.importPathInput).trim();
    const mode = options.mode ?? backupState.importMode;
    const replaceConfirmed = options.replaceConfirmed ?? backupState.replaceConfirmed;

    if (!inputPath) {
      openBackupError("Import path is required.");
      return;
    }

    if (mode === "replace" && !replaceConfirmed) {
      backupDispatch({ type: "openImportConfirm" });
      return;
    }

    void (async () => {
      try {
        const summary = await importBackup({
          inputPath,
          mode,
          dryRun: true
        });
        backupDispatch({ type: "dryRunSucceeded", summary, inputPath });
      } catch (error: unknown) {
        openBackupError("Dry-run failed", error, "import_mode");
      }
    })();
  }

  function runBackupImportCommitFlow() {
    if (!hasMatchingDryRun(backupState)) {
      openBackupError("Dry-run summary is required before commit.");
      return;
    }
    if (backupState.importMode === "replace" && !backupState.replaceConfirmed) {
      backupDispatch({ type: "openImportConfirm" });
      return;
    }

    backupDispatch({ type: "startImporting" });
    void (async () => {
      try {
        const summary = await importBackup({
          inputPath: backupState.importPathInput.trim(),
          mode: backupState.importMode,
          dryRun: false,
          backup: true
        });
        backupDispatch({ type: "importSucceeded", summary });
        await refreshRuntimeStateFromDisk();
      } catch (error: unknown) {
        if (error instanceof BackupImportPartialError) {
          try {
            await refreshRuntimeStateFromDisk();
          } catch {
            // Best effort refresh for partial success paths.
          }
        }
        openBackupError("Import failed", error, "import_dryrun");
      }
    })();
  }

  function resolveCalendarViewSelectionDigit(digit: number): string | undefined | null {
    if (digit <= 0) return null;
    if (digit === 1) return undefined;
    const view = state.savedViews[digit - 2];
    return view ? view.name : null;
  }

  function parseCalendarImportHorizonOrThrow(): number {
    const raw = backupState.calendarImportHorizonInput.trim();
    const parsed = Number.parseInt(raw, 10);
    if (!Number.isInteger(parsed) || parsed <= 0 || parsed > 3650) {
      throw new Error("Horizon days must be a positive integer <= 3650.");
    }
    return parsed;
  }

  function runCalendarExportFromBackupCenter() {
    if (backupState.screen === "calendar_exporting") return;
    backupDispatch({ type: "startCalendarExport" });
    void (async () => {
      try {
        const result = await runCalendarExportFlow({
          range: backupState.calendarExportRange,
          viewName: backupState.calendarExportViewName,
          privacy: backupState.calendarExportPrivacy,
          outputPathInput: backupState.calendarExportPathInput
        });
        backupDispatch({
          type: "calendarExportSucceeded",
          result,
          warnings: result.warnings
        });
      } catch (error: unknown) {
        openBackupError("Calendar export failed", error, "calendar_export_confirm");
      }
    })();
  }

  function runCalendarImportDryRunFromBackupCenter() {
    const inputPath = backupState.calendarImportPathInput.trim();
    if (!inputPath) {
      openBackupError("Calendar import path is required.", undefined, "calendar_import_path");
      return;
    }

    let horizonDays = 0;
    try {
      horizonDays = parseCalendarImportHorizonOrThrow();
    } catch (error: unknown) {
      openBackupError(
        "Invalid horizon days.",
        error,
        "calendar_import_horizon"
      );
      return;
    }

    backupDispatch({ type: "startCalendarImportDryRun" });
    void (async () => {
      try {
        const reportPath = await buildDefaultCalendarImportReportPath({});
        const dryRun = await runCalendarImportDryRunFlow({
          inputPath,
          range: backupState.calendarImportRange,
          viewName: backupState.calendarImportViewName,
          mode: backupState.calendarImportMode,
          horizonDays,
          importTag: backupState.calendarImportTagInput,
          reportPath
        });
        backupDispatch({
          type: "calendarImportDryRunSucceeded",
          summary: dryRun.result.summary,
          hasErrors: dryRun.result.hasErrors,
          errorReasons: dryRun.errorReasons,
          fingerprint: dryRun.fingerprint,
          reportPath: dryRun.result.outputReportPath,
          warnings: dryRun.result.warnings
        });
      } catch (error: unknown) {
        openBackupError("Calendar dry-run failed", error, "calendar_import_tag");
      }
    })();
  }

  function runCalendarImportCommitFromBackupCenter() {
    if (!hasMatchingCalendarImportDryRun(backupState)) {
      openBackupError(
        "A matching dry-run is required before commit.",
        undefined,
        "calendar_import_dryrun"
      );
      return;
    }
    if (backupState.calendarImportDryRunHasErrors) {
      openBackupError(
        "Dry-run reported errors. Resolve errors before commit.",
        undefined,
        "calendar_import_dryrun"
      );
      return;
    }
    if (
      shouldRequireCalendarImportConfirm(backupState) &&
      !isCalendarImportConfirmValid(backupState)
    ) {
      backupDispatch({ type: "setScreen", screen: "calendar_import_confirm" });
      return;
    }

    let horizonDays = 0;
    try {
      horizonDays = parseCalendarImportHorizonOrThrow();
    } catch (error: unknown) {
      openBackupError(
        "Invalid horizon days.",
        error,
        "calendar_import_horizon"
      );
      return;
    }

    backupDispatch({ type: "startCalendarImporting" });
    void (async () => {
      try {
        const reportPath =
          backupState.calendarImportDryRunReportPath ??
          (await buildDefaultCalendarImportReportPath({}));
        const commitResult = await runCalendarImportCommitFlow({
          inputPath: backupState.calendarImportPathInput.trim(),
          range: backupState.calendarImportRange,
          viewName: backupState.calendarImportViewName,
          mode: backupState.calendarImportMode,
          horizonDays,
          importTag: backupState.calendarImportTagInput,
          reportPath
        });
        backupDispatch({
          type: "calendarImportSucceeded",
          summary: commitResult.result.summary,
          reportPath: commitResult.result.outputReportPath,
          backupPath: commitResult.backupPath,
          warnings: commitResult.result.warnings
        });
        await refreshRuntimeStateFromDisk();
      } catch (error: unknown) {
        openBackupError(
          "Calendar import failed",
          error,
          "calendar_import_dryrun"
        );
      }
    })();
  }

  function handleCalendarMenuSelect(index: 0 | 1 | 2) {
    switch (index) {
      case 0:
        backupDispatch({ type: "setCalendarExportRange", range: "next7" });
        backupDispatch({ type: "setCalendarExportViewName", viewName: undefined });
        backupDispatch({ type: "setCalendarExportPrivacy", privacy: "minimal" });
        backupDispatch({ type: "setCalendarExportPath", value: "" });
        void refreshCalendarTimeZoneHint();
        backupDispatch({ type: "setScreen", screen: "calendar_export_intro" });
        return;
      case 1:
        backupDispatch({ type: "setCalendarImportPath", value: "" });
        backupDispatch({ type: "setCalendarImportRange", range: "next7" });
        backupDispatch({ type: "setCalendarImportViewName", viewName: undefined });
        backupDispatch({ type: "setCalendarImportMode", mode: "merge" });
        backupDispatch({ type: "setCalendarImportHorizonInput", value: "365" });
        backupDispatch({ type: "setCalendarImportTagInput", value: "" });
        backupDispatch({ type: "setCalendarImportConfirmInput", value: "" });
        backupDispatch({ type: "setScreen", screen: "calendar_import_intro" });
        return;
      case 2:
        backupDispatch({ type: "setScreen", screen: "menu" });
        return;
      default:
        return;
    }
  }

  function handleBackupMenuSelect(index: 0 | 1 | 2 | 3) {
    switch (index) {
      case 0:
        runBackupExportFlow();
        return;
      case 1:
        backupDispatch({ type: "openImportPath" });
        return;
      case 2:
        backupDispatch({ type: "showDataPath", path: getResolvedDataPath() });
        return;
      case 3:
        backupDispatch({ type: "setScreen", screen: "calendar_menu" });
        return;
      default:
        return;
    }
  }

  function handleBackupDigitSelection(digit: number) {
    switch (backupState.screen) {
      case "calendar_menu":
        if (digit >= 1 && digit <= 3) {
          const index = (digit - 1) as 0 | 1 | 2;
          backupDispatch({ type: "setCalendarMenuIndex", index });
          handleCalendarMenuSelect(index);
        }
        return;
      case "calendar_export_range":
        if (digit === 1) backupDispatch({ type: "setCalendarExportRange", range: "next7" });
        if (digit === 2) backupDispatch({ type: "setCalendarExportRange", range: "month" });
        if (digit === 3) backupDispatch({ type: "setCalendarExportRange", range: "all" });
        return;
      case "calendar_export_view": {
        const selected = resolveCalendarViewSelectionDigit(digit);
        if (selected !== null) {
          backupDispatch({ type: "setCalendarExportViewName", viewName: selected });
        }
        return;
      }
      case "calendar_export_privacy":
        if (digit === 1) backupDispatch({ type: "setCalendarExportPrivacy", privacy: "minimal" });
        if (digit === 2) backupDispatch({ type: "setCalendarExportPrivacy", privacy: "full" });
        return;
      case "calendar_import_range":
        if (digit === 1) backupDispatch({ type: "setCalendarImportRange", range: "next7" });
        if (digit === 2) backupDispatch({ type: "setCalendarImportRange", range: "month" });
        if (digit === 3) backupDispatch({ type: "setCalendarImportRange", range: "all" });
        return;
      case "calendar_import_view": {
        const selected = resolveCalendarViewSelectionDigit(digit);
        if (selected !== null) {
          backupDispatch({ type: "setCalendarImportViewName", viewName: selected });
        }
        return;
      }
      case "calendar_import_mode":
        if (digit === 1) backupDispatch({ type: "setCalendarImportMode", mode: "merge" });
        if (digit === 2) backupDispatch({ type: "setCalendarImportMode", mode: "update" });
        if (digit === 3) backupDispatch({ type: "setCalendarImportMode", mode: "create" });
        return;
      default:
        return;
    }
  }

  function handleBackupBackAction() {
    if (backupState.screen === "menu") {
      const { mode: returnMode, focus: returnFocus } = normalizeHelpReturnContext(
        uiState.previousMode,
        uiState.previousFocus
      );
      backupDispatch({ type: "reset" });
      uiDispatch({ type: "setMode", mode: returnMode });
      uiDispatch({ type: "setFocus", focus: returnFocus });
      return;
    }
    backupDispatch({ type: "back" });
  }

  function handleBackupPrimaryAction() {
    switch (backupState.screen) {
      case "menu":
        handleBackupMenuSelect(backupState.menuIndex);
        return;
      case "calendar_menu":
        handleCalendarMenuSelect(backupState.calendarMenuIndex);
        return;
      case "export_done":
      case "import_done":
      case "show_path":
        backupDispatch({ type: "openMenu" });
        return;
      case "calendar_export_done":
      case "calendar_import_done":
        backupDispatch({ type: "setScreen", screen: "calendar_menu" });
        return;
      case "error":
        backupDispatch({ type: "back" });
        return;
      case "import_path":
        if (!backupState.importPathInput.trim()) {
          openBackupError("Import path is required.", undefined, "import_path");
          return;
        }
        backupDispatch({ type: "openImportMode" });
        return;
      case "import_mode":
        runBackupDryRunFlow();
        return;
      case "import_confirm":
        if (!isReplaceConfirmationValid(backupState)) {
          backupDispatch({ type: "replaceConfirmRejected" });
          return;
        }
        backupDispatch({ type: "replaceConfirmAccepted" });
        runBackupDryRunFlow({
          replaceConfirmed: true
        });
        return;
      case "import_dryrun":
        runBackupImportCommitFlow();
        return;
      case "calendar_export_intro":
        backupDispatch({ type: "setScreen", screen: "calendar_export_range" });
        return;
      case "calendar_export_range":
        backupDispatch({ type: "setScreen", screen: "calendar_export_view" });
        return;
      case "calendar_export_view":
        backupDispatch({ type: "setScreen", screen: "calendar_export_privacy" });
        return;
      case "calendar_export_privacy":
        backupDispatch({ type: "setScreen", screen: "calendar_export_path" });
        return;
      case "calendar_export_path":
        backupDispatch({ type: "setScreen", screen: "calendar_export_confirm" });
        return;
      case "calendar_export_confirm":
        runCalendarExportFromBackupCenter();
        return;
      case "calendar_import_intro":
        backupDispatch({ type: "setScreen", screen: "calendar_import_path" });
        return;
      case "calendar_import_path":
        if (!backupState.calendarImportPathInput.trim()) {
          openBackupError(
            "Calendar import path is required.",
            undefined,
            "calendar_import_path"
          );
          return;
        }
        backupDispatch({ type: "setScreen", screen: "calendar_import_range" });
        return;
      case "calendar_import_range":
        backupDispatch({ type: "setScreen", screen: "calendar_import_view" });
        return;
      case "calendar_import_view":
        backupDispatch({ type: "setScreen", screen: "calendar_import_mode" });
        return;
      case "calendar_import_mode":
        backupDispatch({ type: "setScreen", screen: "calendar_import_horizon" });
        return;
      case "calendar_import_horizon":
        try {
          parseCalendarImportHorizonOrThrow();
        } catch (error: unknown) {
          openBackupError("Invalid horizon days.", error, "calendar_import_horizon");
          return;
        }
        backupDispatch({ type: "setScreen", screen: "calendar_import_tag" });
        return;
      case "calendar_import_tag":
        runCalendarImportDryRunFromBackupCenter();
        return;
      case "calendar_import_dryrun":
        if (
          !hasMatchingCalendarImportDryRun(backupState) ||
          backupState.calendarImportDryRunHasErrors
        ) {
          return;
        }
        if (
          shouldRequireCalendarImportConfirm(backupState) &&
          !isCalendarImportConfirmValid(backupState)
        ) {
          backupDispatch({ type: "setScreen", screen: "calendar_import_confirm" });
          return;
        }
        runCalendarImportCommitFromBackupCenter();
        return;
      case "calendar_import_confirm":
        if (!isCalendarImportConfirmValid(backupState)) {
          openBackupError(
            "Type IMPORT to confirm this high-impact import.",
            undefined,
            "calendar_import_confirm"
          );
          return;
        }
        runCalendarImportCommitFromBackupCenter();
        return;
      case "exporting":
      case "importing":
      case "calendar_exporting":
      case "calendar_import_dryrun_running":
      case "calendar_importing":
      default:
        return;
    }
  }

  function assertLinkActionInvariant(action: KeyRouterAction): void {
    if (process.env.NODE_ENV === "production") return;

    const detailsFocusOnly = new Set<KeyRouterAction["type"]>([
      "MOVE_LINK_SELECTION",
      "OPEN_SELECTED_LINK",
      "COPY_SELECTED_LINK",
      "OPEN_EDIT_TASK_LINK_MODAL",
      "OPEN_DELETE_TASK_LINK_MODAL"
    ]);
    const modalOnly = new Set<KeyRouterAction["type"]>([
      "MODAL_CONFIRM_TASK_LINK_DELETE",
      "MODAL_CONFIRM_TASK_LINK_OPEN_EXTERNAL",
      "MODAL_SUBMIT_TASK_LINK_FORM",
      "MODAL_MOVE_TASK_LINK_FORM_FOCUS",
      "MODAL_CYCLE_TASK_LINK_FORM_TYPE"
    ]);

    if (
      detailsFocusOnly.has(action.type) &&
      (uiState.mode !== Mode.LIST || uiState.focus !== FocusTarget.DETAILS_LINKS)
    ) {
      throw new Error(
        `Link action ${action.type} requires LIST + DETAILS_LINKS (got ${uiState.mode}/${uiState.focus})`
      );
    }

    if (
      action.type === "OPEN_ADD_TASK_LINK_MODAL" &&
      uiState.mode !== Mode.LIST &&
      uiState.mode !== Mode.ADD
    ) {
      throw new Error(
        `Link action ${action.type} requires LIST or ADD mode (got ${uiState.mode})`
      );
    }

    if (modalOnly.has(action.type) && uiState.mode !== Mode.MODAL_CONFIRM) {
      throw new Error(
        `Link modal action ${action.type} requires MODAL_CONFIRM mode (got ${uiState.mode})`
      );
    }
  }

  function runRoutedAction(action: KeyRouterAction) {
    assertLinkActionInvariant(action);
    switch (action.type) {
      case "UNWIND":
        applyEscUnwind();
        return;
      case "OPEN_EMPTY_NUX":
        openEmptyNuxModal({
          step: action.step,
          startedFromNux: action.startedFromNux,
          createdTaskId: action.createdTaskId
        });
        return;
      case "DISMISS_EMPTY_NUX":
        uiDispatch(dismissEmptyNux());
        return;
      case "CLEAR_EMPTY_NUX":
        uiDispatch(clearEmptyNux());
        return;
      case "SET_MODAL":
        uiDispatch({ type: "setModal", modal: action.modal });
        return;
      case "TOGGLE_DASHBOARD":
        toggleDashboard();
        return;
      case "OPEN_HELP":
        openHelp();
        return;
      case "OPEN_BACKUP_CENTER":
        openBackupCenter();
        return;
      case "OPEN_TAG_FILTER_PANEL":
        openTagFilterPanel();
        return;
      case "CLOSE_HELP":
        closeHelp();
        return;
      case "HELP_MOVE_SECTION_FOCUS":
        moveHelpSectionFocus(action.delta);
        return;
      case "HELP_TOGGLE_FOCUSED_SECTION":
        toggleFocusedHelpSection();
        return;
      case "HELP_NAV_FORWARD":
        handleHelpNavForward();
        return;
      case "HELP_NAV_BACK":
        handleHelpNavBack();
        return;
      case "HELP_SET_FOCUSED_SECTION_EXPANDED":
        setFocusedHelpSectionExpanded(action.expanded);
        return;
      case "HELP_SCROLL_PAGE":
        scrollHelpByPage(action.direction);
        return;
      case "BACKUP_PRIMARY":
        handleBackupPrimaryAction();
        return;
      case "BACKUP_BACK":
        handleBackupBackAction();
        return;
      case "BACKUP_MOVE_MENU_SELECTION":
        backupDispatch({ type: "moveMenuIndex", delta: action.delta });
        return;
      case "BACKUP_SELECT_MENU_OPTION":
        backupDispatch({ type: "setMenuIndex", index: action.index });
        handleBackupMenuSelect(action.index);
        return;
      case "BACKUP_SELECT_DIGIT":
        handleBackupDigitSelection(action.digit);
        return;
      case "BACKUP_SET_IMPORT_MODE":
        backupDispatch({ type: "setImportMode", mode: action.mode });
        return;
      case "OPEN_SEARCH":
        uiDispatch({ type: "setMode", mode: Mode.SEARCH });
        uiDispatch({ type: "setFocus", focus: FocusTarget.SEARCH_INPUT });
        return;
      case "CLOSE_SEARCH":
        closeSearch();
        return;
      case "MOVE_EDITOR_FOCUS":
        uiDispatch({
          type: "setFocus",
          focus: nextEditorFocusTarget(uiState.focus, action.direction, state.editor)
        });
        return;
      case "SET_LIST_FOCUS":
        clearPendingGPrefix();
        uiDispatch({ type: "setFocus", focus: action.focus });
        return;
      case "SET_G_PREFIX":
        if (action.active) {
          armPendingGPrefix();
        } else {
          clearPendingGPrefix();
        }
        return;
      case "TOGGLE_VIEWS_OVERLAY":
        toggleViewsOverlay();
        return;
      case "CLOSE_VIEWS_OVERLAY":
        closeViewsOverlay();
        return;
      case "MOVE_VIEW_SELECTION":
        moveViewSelection(action.delta);
        return;
      case "MOVE_DASHBOARD_TAG_SELECTION":
        moveDashboardTagSelection(action.delta);
        return;
      case "SCROLL_EDITOR_PAGE": {
        const nextOffset = Math.max(
          0,
          uiState.editorScrollOffset + action.direction * editorPageStep
        );
        uiDispatch({ type: "setEditorScrollOffset", scrollOffset: nextOffset });
        return;
      }
      case "OPEN_SAVE_VIEW_PROMPT":
        openSaveViewPrompt();
        return;
      case "CONFIRM_SAVE_VIEW_PROMPT":
        confirmSaveViewPrompt();
        return;
      case "CANCEL_SAVE_VIEW_PROMPT":
        cancelSaveViewPrompt();
        return;
      case "CYCLE_THEME":
        cycleThemeModeSetting();
        return;
      case "TOGGLE_FLASH_MODE":
        switchFlashModeSetting();
        return;
      case "TOGGLE_NOTIFICATIONS_ENABLED":
        switchNotificationsEnabledSetting();
        return;
      case "TOGGLE_INAPP_OVERDUE_BANNER":
        switchInAppOverduePopupSetting();
        return;
      case "TOGGLE_TERMINAL_BELL_ON_OVERDUE":
        switchTerminalBellSetting();
        return;
      case "EXIT_APP":
        void renderer.destroy();
        return;
      case "MOVE_SELECTION":
        moveSelection(action.delta);
        return;
      case "MOVE_SELECTION_PAGE":
        moveSelectionPage(action.direction);
        return;
      case "JUMP_TOP":
        jumpToTop();
        return;
      case "JUMP_BOTTOM":
        jumpToBottom();
        return;
      case "JUMP_TO_ATTENTION":
        jumpToAttention(action.kind, action.direction);
        return;
      case "APPLY_VIEW_SLOT":
        applyViewAtSlot(action.slot);
        return;
      case "APPLY_SELECTED_VIEW":
        applySelectedView();
        return;
      case "DELETE_SELECTED_VIEW":
        deleteSelectedView();
        return;
      case "TOGGLE_SELECTED":
        toggleSelected();
        return;
      case "OPEN_ADD":
        openAdd();
        return;
      case "OPEN_EDIT":
        openEdit();
        return;
      case "OPEN_EDIT_SERIES":
        openEditSeries();
        return;
      case "OPEN_DUPLICATE":
        openDuplicate();
        return;
      case "SKIP_SELECTED_OCCURRENCE":
        skipSelectedOccurrence();
        return;
      case "SNOOZE_SELECTED_OCCURRENCE":
        snoozeSelectedOccurrence();
        return;
      case "MOVE_LINK_SELECTION":
        moveLinkSelection(action.delta);
        return;
      case "OPEN_SELECTED_LINK":
        openSelectedTaskLink();
        return;
      case "COPY_SELECTED_LINK":
        copySelectedTaskLink();
        return;
      case "OPEN_ADD_TASK_LINK_MODAL":
        openAddTaskLinkModal();
        return;
      case "OPEN_EDIT_TASK_LINK_MODAL":
        openEditTaskLinkModal();
        return;
      case "OPEN_DELETE_TASK_LINK_MODAL":
        openDeleteTaskLinkModal();
        return;
      case "OPEN_DELETE_CONFIRM":
        openDeleteConfirm();
        return;
      case "MODAL_CONFIRM_DELETE":
        handleDeleteSelected();
        return;
      case "MODAL_CONFIRM_DELETE_FUTURE":
        handleDeleteSelectedAndFuture();
        return;
      case "MODAL_CONFIRM_TASK_LINK_DELETE":
        handleDeleteTaskLinkFromModal();
        return;
      case "MODAL_CONFIRM_TASK_LINK_OPEN_EXTERNAL":
        handleOpenExternalTaskLinkFromModal();
        return;
      case "MODAL_SUBMIT_TASK_LINK_FORM":
        submitTaskLinkFormModal();
        return;
      case "MODAL_MOVE_TASK_LINK_FORM_FOCUS":
        moveTaskLinkFormFocus(action.direction);
        return;
      case "MODAL_CYCLE_TASK_LINK_FORM_TYPE":
        cycleTaskLinkFormType(action.direction);
        return;
      case "MODAL_OVERDUE_SNOOZE":
        handleOverdueModalSnooze();
        return;
      case "MODAL_OVERDUE_DONE":
        handleOverdueModalDone();
        return;
      case "MODAL_OVERDUE_GO_TO_TASK":
        handleOverdueModalGoToTask();
        return;
      case "CYCLE_STATUS":
        cycleStatus();
        return;
      case "CYCLE_SORT":
        cycleSort();
        return;
      case "CYCLE_DUE":
        cycleDue();
        return;
      case "CYCLE_PRIORITY":
        cyclePriority();
        return;
      case "TOGGLE_TAG_FILTER":
        toggleTagFilter();
        return;
      case "APPLY_DASHBOARD_SELECTED_TAG":
        applyDashboardSelectedTag();
        return;
      case "SAVE_EDITOR":
        saveEditor();
        return;
      case "APPLY_TIME_AUTOCOMPLETE":
        if (
          uiState.mode === Mode.ADD &&
          uiState.focus === FocusTarget.EDITOR_DUE_TIME &&
          state.editor &&
          timeSuggestion
        ) {
          const step = getAutocompleteStep(state.editor.timeText, timeSuggestion);
          if (step === "hour" || step === "minute") {
            const nextValue = applyAutocomplete(
              state.editor.timeText,
              timeSuggestion,
              step
            );
            dispatch({ type: "updateEditor", patch: { timeText: nextValue } });
          }
        }
        return;
      case "ACCEPT_DUE_SUGGESTION":
        if (dueSuggestion) {
          dispatch({ type: "updateEditor", patch: { dueText: dueSuggestion } });
        }
        return;
      case "ACCEPT_TAG_INLINE":
        if (tagInlineSuggestion) {
          handlePickTag(tagInlineSuggestion.full);
        }
        return;
      default:
        return;
    }
  }

  useKeyboard((key) => {
    if (!terminalIsSupported) {
      if ((key.name ?? "") === "q") {
        void renderer.destroy();
      }
      return;
    }

    if (uiState.mode === Mode.HELP && activeHelpPage === "custom1Edit") {
      const handled = custom1EditorRef.current?.handleKey(key) ?? false;
      if (handled) {
        return;
      }
    }
    if (uiState.mode === Mode.HELP && activeHelpPage === "textTuningEdit") {
      const handled = builtInTextEditorRef.current?.handleKey(key) ?? false;
      if (handled) {
        return;
      }
    }

    const keyName = key.name ?? "";
    if (
      uiState.mode === Mode.HELP &&
      activeHelpPage === "settings" &&
      clampedHelpNavSelectionIndex === HELP_SETTINGS_LOGO_NAV_INDEX
    ) {
      if (keyName === "left") {
        cycleLogoModeSetting(-1, false);
        return;
      }
      if (keyName === "right") {
        cycleLogoModeSetting(1, false);
        return;
      }
      if (keyName === "return" || keyName === "enter") {
        commitLogoModeSetting();
        return;
      }
      if (keyName === "escape" || keyName === "backspace") {
        cancelLogoModeSetting();
        handleHelpNavBack();
        return;
      }
    }

    const actions = handleKey(
      {
        name: keyName,
        sequence: key.sequence ?? "",
        ctrl: key.ctrl === true,
        shift: key.shift === true
      },
      {
        uiState,
        hasTagInlineSuggestion: Boolean(tagInlineSuggestion),
        hasDueSuggestion: Boolean(dueSuggestion),
        timeAutocompleteStep,
        hasPendingGPrefix: pendingGPrefix,
        viewsOverlayOpen,
        saveViewPromptOpen,
        backupScreen: uiState.mode === Mode.BACKUP_CENTER ? backupState.screen : null,
        helpPage: activeHelpPage
      }
    );

    for (const action of actions) {
      try {
        runRoutedAction(action);
      } catch (error) {
        const detail = normalizeErrorDetail(error);
        showShortNavigationBanner(`Action failed: ${detail}`);
        console.error("[TADOI] routed action failed", action, error);
      }
    }
  });

  function openHelp() {
    clearPendingGPrefix();
    setHelpExpandedBySection(createDefaultHelpExpandedState());
    helpFocusedSectionRef.current = 0;
    setHelpFocusedSectionIndex(0);
    helpScrollTopRef.current = 0;
    setHelpScrollOffset(0);
    setHelpNavStack(["help"]);
    setHelpNavSelection({
      settings: 0,
      theme: 0,
      custom1: 0,
      textTuning: 0,
      textTuningTheme: 0
    });
    setHelpTextTuningThemeId(HELP_TEXT_TUNING_THEMES[0] ?? "default");
    setHelpPreviewThemeMode(null);
    setHelpDraftLogoMode(null);
    setBuiltInTextDraftGlobal({});
    setBuiltInTextDraftObjects({});
    helpPreviewRestoreThemeRef.current = null;
    helpReturnContextRef.current = {
      mode: uiState.mode,
      focus: uiState.focus
    };
    uiDispatch({
      type: "captureReturnContext",
      mode: uiState.mode,
      focus: uiState.focus
    });
    uiDispatch({ type: "setMode", mode: Mode.HELP });
  }

  function pushHelpPage(page: HelpPage) {
    setHelpNavStack((prev) => {
      if (prev[prev.length - 1] === page) return prev;
      return [...prev, page];
    });
    helpScrollTopRef.current = 0;
    setHelpScrollOffset(0);
  }

  function popHelpPage() {
    setHelpNavStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
    helpScrollTopRef.current = 0;
    setHelpScrollOffset(0);
  }

  function sanitizeDraftObjects(
    objects: Partial<Record<ThemeObjectId, Partial<ThemeTokens>>>
  ): Partial<Record<ThemeObjectId, Partial<ThemeTokens>>> | undefined {
    const next: Partial<Record<ThemeObjectId, Partial<ThemeTokens>>> = {};
    for (const [objectId, tokens] of Object.entries(objects) as Array<
      [ThemeObjectId, Partial<ThemeTokens>]
    >) {
      if (Object.keys(tokens).length > 0) {
        next[objectId] = { ...tokens };
      }
    }
    return Object.keys(next).length > 0 ? next : undefined;
  }

  function openCustom1Editor() {
    const persisted = resolveCustom1Config(settingsState.customThemes);
    setCustom1DraftGlobal(cloneThemeTokens(persisted.global));
    setCustom1DraftObjects(cloneThemeObjectOverrides(persisted.objects));
    helpPreviewRestoreThemeRef.current = settingsState.themeId;
    setHelpPreviewThemeMode("custom1");
    pushHelpPage("custom1Edit");
  }

  function closeCustom1EditorCancel() {
    const persisted = resolveCustom1Config(settingsState.customThemes);
    const restoreTheme = helpPreviewRestoreThemeRef.current;
    setCustom1DraftGlobal(cloneThemeTokens(persisted.global));
    setCustom1DraftObjects(cloneThemeObjectOverrides(persisted.objects));
    setHelpPreviewThemeMode(null);
    if (restoreTheme && settingsState.themeId !== restoreTheme) {
      settingsDispatch({ type: "setTheme", themeId: restoreTheme });
    }
    helpPreviewRestoreThemeRef.current = null;
    setHelpNavStack((prev) =>
      prev[prev.length - 1] === "custom1Edit" ? prev.slice(0, -1) : prev
    );
  }

  function saveCustom1Editor() {
    const objects = sanitizeDraftObjects(custom1DraftObjects);
    settingsDispatch({
      type: "setCustomThemes",
      customThemes: {
        ...(settingsState.customThemes ?? {}),
        custom1: objects
          ? { global: cloneThemeTokens(custom1DraftGlobal), objects }
          : { global: cloneThemeTokens(custom1DraftGlobal) }
      }
    });
    settingsDispatch({ type: "setTheme", themeId: "custom1" });
    setHelpPreviewThemeMode(null);
    helpPreviewRestoreThemeRef.current = null;
    setHelpNavStack((prev) =>
      prev[prev.length - 1] === "custom1Edit" ? prev.slice(0, -1) : prev
    );
    showShortNavigationBanner("Custom1 theme saved");
  }

  function openBuiltInTextEditor() {
    setBuiltInTextDraftGlobal(cloneThemeTextTokenOverrides(persistedBuiltInTextConfig.global));
    setBuiltInTextDraftObjects(cloneThemeTextObjectOverrides(persistedBuiltInTextConfig.objects));
    helpPreviewRestoreThemeRef.current = settingsState.themeId;
    setHelpPreviewThemeMode(helpTextTuningThemeId);
    pushHelpPage("textTuningEdit");
  }

  function closeBuiltInTextEditorCancel() {
    const restoreTheme = helpPreviewRestoreThemeRef.current;
    setBuiltInTextDraftGlobal(cloneThemeTextTokenOverrides(persistedBuiltInTextConfig.global));
    setBuiltInTextDraftObjects(cloneThemeTextObjectOverrides(persistedBuiltInTextConfig.objects));
    setHelpPreviewThemeMode(null);
    if (restoreTheme && settingsState.themeId !== restoreTheme) {
      settingsDispatch({ type: "setTheme", themeId: restoreTheme });
    }
    helpPreviewRestoreThemeRef.current = null;
    setHelpNavStack((prev) =>
      prev[prev.length - 1] === "textTuningEdit" ? prev.slice(0, -1) : prev
    );
  }

  function saveBuiltInTextEditor() {
    const sanitizedGlobal = sanitizeThemeTextTokenOverrides(builtInTextDraftGlobal);
    const sanitizedObjects = sanitizeThemeTextObjectOverrides(builtInTextDraftObjects);
    const existingTextByTheme = {
      ...(settingsState.customThemes?.textByTheme ?? {})
    };

    if (!sanitizedGlobal && !sanitizedObjects) {
      delete existingTextByTheme[helpTextTuningThemeId];
    } else {
      const nextConfig: BuiltInThemeTextOverrideConfig = {};
      if (sanitizedGlobal) {
        nextConfig.global = sanitizedGlobal;
      }
      if (sanitizedObjects) {
        nextConfig.objects = sanitizedObjects;
      }
      existingTextByTheme[helpTextTuningThemeId] = nextConfig;
    }

    const nextCustomThemes: CustomThemes = {
      ...(settingsState.customThemes ?? {})
    };
    if (Object.keys(existingTextByTheme).length > 0) {
      nextCustomThemes.textByTheme = existingTextByTheme;
    } else {
      delete nextCustomThemes.textByTheme;
    }

    settingsDispatch({
      type: "setCustomThemes",
      customThemes: nextCustomThemes
    });

    const restoreTheme = helpPreviewRestoreThemeRef.current;
    setHelpPreviewThemeMode(null);
    if (restoreTheme && settingsState.themeId !== restoreTheme) {
      settingsDispatch({ type: "setTheme", themeId: restoreTheme });
    }
    helpPreviewRestoreThemeRef.current = null;
    setHelpNavStack((prev) =>
      prev[prev.length - 1] === "textTuningEdit" ? prev.slice(0, -1) : prev
    );
    showShortNavigationBanner(`${formatThemeIdLabel(helpTextTuningThemeId)} text colors saved`);
  }

  function cycleLogoModeSetting(direction: 1 | -1, commit: boolean) {
    const baseMode = helpDraftLogoMode ?? settingsState.logoMode;
    const nextMode = cycleLogoMode(baseMode, direction);
    if (!commit) {
      setHelpDraftLogoMode(nextMode);
      return;
    }
    setHelpDraftLogoMode(null);
    if (nextMode === settingsState.logoMode) {
      return;
    }
    settingsDispatch({ type: "setLogoMode", logoMode: nextMode });
    showShortNavigationBanner(`Logo: ${formatLogoModeLabel(nextMode)}`);
  }

  function commitLogoModeSetting() {
    const nextMode = helpDraftLogoMode ?? settingsState.logoMode;
    setHelpDraftLogoMode(null);
    if (nextMode === settingsState.logoMode) {
      return;
    }
    settingsDispatch({ type: "setLogoMode", logoMode: nextMode });
    showShortNavigationBanner(`Logo: ${formatLogoModeLabel(nextMode)}`);
  }

  function cancelLogoModeSetting() {
    setHelpDraftLogoMode(null);
  }

  function cycleThemeModeSetting() {
    settingsDispatch({ type: "cycleTheme" });
  }

  function switchFlashModeSetting() {
    const nextMode: FlashMode = settingsState.flashMode === "slow" ? "static" : "slow";
    settingsDispatch({ type: "toggleFlashMode" });
    showShortNavigationBanner(
      nextMode === "static" ? "Flash mode: static (overdue = red)" : "Flash mode: slow"
    );
  }

  function switchNotificationsEnabledSetting() {
    const nextEnabled = !settingsState.notifications.enabled;
    settingsDispatch({ type: "toggleNotificationsEnabled" });
    showShortNavigationBanner(`Notifications: ${nextEnabled ? "on" : "off"}`);
  }

  function switchInAppOverduePopupSetting() {
    const nextEnabled = !settingsState.notifications.inAppOverdueBanner;
    settingsDispatch({ type: "toggleInAppOverdueBanner" });
    showShortNavigationBanner(`Overdue popup: ${nextEnabled ? "on" : "off"}`);
  }

  function switchTerminalBellSetting() {
    const nextEnabled = !settingsState.notifications.terminalBellOnOverdue;
    settingsDispatch({ type: "toggleTerminalBellOnOverdue" });
    showShortNavigationBanner(`Terminal bell: ${nextEnabled ? "on" : "off"}`);
  }

  function openBackupCenter() {
    clearPendingGPrefix();
    closeViewsOverlay();
    if (uiState.modal) {
      uiDispatch({ type: "setModal", modal: null });
    }
    if (isEditorMode(uiState.mode)) {
      setTimeSuggestion(null);
      dispatch({ type: "setEditor", editor: null });
      uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    }
    backupDispatch({ type: "reset" });
    uiDispatch({
      type: "captureReturnContext",
      mode: uiState.mode,
      focus: uiState.focus
    });
    uiDispatch({ type: "setMode", mode: Mode.BACKUP_CENTER });
    uiDispatch({ type: "setFocus", focus: FocusTarget.BACKUP_CENTER });
  }

  function toggleDashboard() {
    clearPendingGPrefix();
    closeViewsOverlay();

    if (uiState.mode === Mode.DASHBOARD) {
      uiDispatch({ type: "setMode", mode: Mode.LIST });
      uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
      return;
    }

    if (isEditorMode(uiState.mode)) {
      setTimeSuggestion(null);
      dispatch({ type: "setEditor", editor: null });
      uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    }

    setDashboardTagSelection(0);
    uiDispatch({ type: "setMode", mode: Mode.DASHBOARD });
    uiDispatch({ type: "setFocus", focus: FocusTarget.DASHBOARD });
  }

  function closeHelp() {
    if (helpNavStack[helpNavStack.length - 1] === "custom1Edit") {
      closeCustom1EditorCancel();
    }
    if (helpNavStack[helpNavStack.length - 1] === "textTuningEdit") {
      closeBuiltInTextEditorCancel();
    }
    cancelLogoModeSetting();
    const { mode: returnMode, focus: returnFocus } = normalizeHelpReturnContext(
      helpReturnContextRef.current.mode,
      helpReturnContextRef.current.focus
    );
    uiDispatch({ type: "setMode", mode: returnMode });
    uiDispatch({ type: "setFocus", focus: returnFocus });
  }

  function moveHelpSectionFocus(delta: 1 | -1) {
    if (activeHelpPage !== "help") {
      if (activeHelpPage === "settings") {
        setHelpNavSelection((prev) => ({
          ...prev,
          settings: Math.max(
            0,
            Math.min(prev.settings + delta, HELP_SETTINGS_NAV_ITEMS.length - 1)
          )
        }));
      } else if (activeHelpPage === "theme") {
        setHelpNavSelection((prev) => ({
          ...prev,
          theme: Math.max(
            0,
            Math.min(prev.theme + delta, HELP_THEME_NAV_ITEMS.length - 1)
          )
        }));
      } else if (activeHelpPage === "custom1") {
        setHelpNavSelection((prev) => ({
          ...prev,
          custom1: Math.max(
            0,
            Math.min(prev.custom1 + delta, HELP_CUSTOM1_NAV_ITEMS.length - 1)
          )
        }));
      } else if (activeHelpPage === "textTuning") {
        setHelpNavSelection((prev) => ({
          ...prev,
          textTuning: Math.max(
            0,
            Math.min(prev.textTuning + delta, HELP_TEXT_TUNING_NAV_ITEMS.length - 1)
          )
        }));
      } else if (activeHelpPage === "textTuningTheme") {
        setHelpNavSelection((prev) => ({
          ...prev,
          textTuningTheme: Math.max(
            0,
            Math.min(prev.textTuningTheme + delta, HELP_TEXT_TUNING_THEME_NAV_ITEMS.length - 1)
          )
        }));
      }
      return;
    }
    const nextIndex = Math.max(
      0,
      Math.min(helpFocusedSectionRef.current + delta, HELP_MENU_SECTIONS.length - 1)
    );
    helpFocusedSectionRef.current = nextIndex;
    setHelpFocusedSectionIndex(nextIndex);
    ensureHelpSectionVisibleNow(nextIndex);
  }

  function scrollHelpByPage(direction: 1 | -1) {
    if (activeHelpPage !== "help") return;
    const currentOffset = getCurrentHelpScrollTop();
    const nextOffset = clampScrollOffset(
      currentOffset + direction * helpPageStep,
      helpContentVisibleRows,
      helpRows.length
    );
    const appliedOffset = scrollHelpTo(nextOffset);
    // Page-scrolling in Help moves focus to the section nearest the top of the viewport.
    const nextFocusedSectionIndex = findHelpSectionIndexForViewportTop(
      helpSections,
      appliedOffset
    );
    helpFocusedSectionRef.current = nextFocusedSectionIndex;
    setHelpFocusedSectionIndex(nextFocusedSectionIndex);
  }

  function setHelpSectionExpanded(sectionIndex: number, expanded: boolean) {
    setHelpExpandedBySection((prev) => {
      if (sectionIndex < 0 || sectionIndex >= prev.length) return prev;
      if (prev[sectionIndex] === expanded) return prev;
      const next = [...prev];
      next[sectionIndex] = expanded;
      return next;
    });
  }

  function toggleHelpSection(sectionIndex: number) {
    setHelpExpandedBySection((prev) => {
      if (sectionIndex < 0 || sectionIndex >= prev.length) return prev;
      const next = [...prev];
      next[sectionIndex] = !next[sectionIndex];
      return next;
    });
  }

  function toggleFocusedHelpSection() {
    if (
      activeHelpPage === "help" &&
      HELP_SETTINGS_NAV_SECTION_INDEX >= 0 &&
      clampedHelpFocusedSectionIndex === HELP_SETTINGS_NAV_SECTION_INDEX
    ) {
      pushHelpPage("settings");
      return;
    }
    toggleHelpSection(clampedHelpFocusedSectionIndex);
  }

  function setFocusedHelpSectionExpanded(expanded: boolean) {
    if (
      activeHelpPage === "help" &&
      expanded &&
      HELP_SETTINGS_NAV_SECTION_INDEX >= 0 &&
      clampedHelpFocusedSectionIndex === HELP_SETTINGS_NAV_SECTION_INDEX
    ) {
      pushHelpPage("settings");
      return;
    }
    setHelpSectionExpanded(clampedHelpFocusedSectionIndex, expanded);
  }

  function handleHelpSectionHeaderClick(sectionIndex: number) {
    if (activeHelpPage !== "help") return;
    const nextIndex = Math.max(0, Math.min(sectionIndex, HELP_MENU_SECTIONS.length - 1));
    helpFocusedSectionRef.current = nextIndex;
    setHelpFocusedSectionIndex(nextIndex);
    ensureHelpSectionVisibleNow(nextIndex);
    if (HELP_SETTINGS_NAV_SECTION_INDEX >= 0 && sectionIndex === HELP_SETTINGS_NAV_SECTION_INDEX) {
      pushHelpPage("settings");
      return;
    }
    toggleHelpSection(sectionIndex);
  }

  function setHelpNavSelectionForActivePage(index: number) {
    if (activeHelpPage === "settings") {
      setHelpNavSelection((prev) => ({ ...prev, settings: index }));
      return;
    }
    if (activeHelpPage === "theme") {
      setHelpNavSelection((prev) => ({ ...prev, theme: index }));
      return;
    }
    if (activeHelpPage === "custom1") {
      setHelpNavSelection((prev) => ({ ...prev, custom1: index }));
      return;
    }
    if (activeHelpPage === "textTuning") {
      setHelpNavSelection((prev) => ({ ...prev, textTuning: index }));
      return;
    }
    if (activeHelpPage === "textTuningTheme") {
      setHelpNavSelection((prev) => ({ ...prev, textTuningTheme: index }));
    }
  }

  function handleHelpNavForward(targetIndex = clampedHelpNavSelectionIndex) {
    if (activeHelpPage === "settings") {
      if (targetIndex === 0) {
        cancelLogoModeSetting();
        pushHelpPage("theme");
      }
      if (targetIndex === HELP_SETTINGS_LOGO_NAV_INDEX) {
        cycleLogoModeSetting(1, true);
      }
      if (targetIndex === 2) switchFlashModeSetting();
      if (targetIndex === 3) switchNotificationsEnabledSetting();
      if (targetIndex === 4) switchInAppOverduePopupSetting();
      if (targetIndex === 5) switchTerminalBellSetting();
      return;
    }
    if (activeHelpPage === "theme") {
      if (targetIndex === 0) cycleThemeModeSetting();
      if (targetIndex === 1) pushHelpPage("custom1");
      if (targetIndex === 2) pushHelpPage("textTuning");
      return;
    }
    if (activeHelpPage === "custom1") {
      if (targetIndex === 0) {
        openCustom1Editor();
      }
      return;
    }
    if (activeHelpPage === "textTuning") {
      const targetThemeId = HELP_TEXT_TUNING_THEMES[targetIndex];
      if (!targetThemeId) return;
      setHelpTextTuningThemeId(targetThemeId);
      setHelpNavSelection((prev) => ({ ...prev, textTuningTheme: 0 }));
      pushHelpPage("textTuningTheme");
      return;
    }
    if (activeHelpPage === "textTuningTheme") {
      if (targetIndex === 0) {
        openBuiltInTextEditor();
      }
    }
  }

  function handleHelpNavBack() {
    if (activeHelpPage === "custom1Edit") {
      closeCustom1EditorCancel();
      return;
    }
    if (activeHelpPage === "textTuningEdit") {
      closeBuiltInTextEditorCancel();
      return;
    }
    if (activeHelpPage === "settings") {
      cancelLogoModeSetting();
    }
    popHelpPage();
  }

  function openListMode() {
    clearPendingGPrefix();
    closeViewsOverlay();
    if (uiState.modal) {
      uiDispatch({ type: "setModal", modal: null });
    }
    if (isEditorMode(uiState.mode)) {
      setTimeSuggestion(null);
      dispatch({ type: "setEditor", editor: null });
      uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    }
    uiDispatch({ type: "setMode", mode: Mode.LIST });
    uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
  }

  function openDashboardMode() {
    if (uiState.mode === Mode.DASHBOARD) return;
    clearPendingGPrefix();
    closeViewsOverlay();
    if (uiState.modal) {
      uiDispatch({ type: "setModal", modal: null });
    }
    if (isEditorMode(uiState.mode)) {
      setTimeSuggestion(null);
      dispatch({ type: "setEditor", editor: null });
      uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    }
    setDashboardTagSelection(0);
    uiDispatch({ type: "setMode", mode: Mode.DASHBOARD });
    uiDispatch({ type: "setFocus", focus: FocusTarget.DASHBOARD });
  }

  function openSearchMode() {
    clearPendingGPrefix();
    closeViewsOverlay();
    if (uiState.modal) {
      uiDispatch({ type: "setModal", modal: null });
    }
    if (isEditorMode(uiState.mode)) {
      setTimeSuggestion(null);
      dispatch({ type: "setEditor", editor: null });
      uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    }
    uiDispatch({ type: "setMode", mode: Mode.SEARCH });
    uiDispatch({ type: "setFocus", focus: FocusTarget.SEARCH_INPUT });
  }

  function openTagFilterPanel() {
    if (uiState.mode !== Mode.LIST && uiState.mode !== Mode.DASHBOARD) return;
    clearPendingGPrefix();
    closeViewsOverlay();
    const seedFilter = resolveEffectiveTagFilter(state.filters);
    setTagFilterDraft(normalizeTagFilter(seedFilter));
    setTagFilterInput("");
    setActiveTagFilterBucket("all");
    uiDispatch({
      type: "captureReturnContext",
      mode: uiState.mode,
      focus: uiState.focus
    });
    uiDispatch({ type: "setMode", mode: Mode.TAG_FILTER });
    uiDispatch({ type: "setFocus", focus: FocusTarget.TAG_FILTER_INPUT });
  }

  function closeTagFilterPanel() {
    setTagFilterInput("");
    setTagFilterDraft(undefined);
    setActiveTagFilterBucket("all");
    applyEscUnwind();
  }

  function clearTagFilterPanelDraft() {
    setTagFilterInput("");
    setTagFilterDraft(undefined);
  }

  function cycleTagFilterBucket(step: 1 | -1 = 1) {
    setActiveTagFilterBucket((current) => {
      const index = TAG_FILTER_BUCKET_ORDER.indexOf(current);
      const safeIndex = index >= 0 ? index : 0;
      return TAG_FILTER_BUCKET_ORDER[
        (safeIndex + step + TAG_FILTER_BUCKET_ORDER.length) % TAG_FILTER_BUCKET_ORDER.length
      ];
    });
  }

  function applyTagFilterPanel(includeInputCandidate = false) {
    const nextTagFilter = normalizeTagFilter(
      resolveTagFilterDraftForApply(includeInputCandidate)
    );
    if (nextTagFilter) {
      setTagFilter(nextTagFilter);
      showShortNavigationBanner(
        `Boolean tags: ${formatTagFilterBooleanSummary(nextTagFilter)}`
      );
    } else {
      clearTagFilters();
      showShortNavigationBanner("Tag filter cleared");
    }
    setTagFilterInput("");
    setTagFilterDraft(undefined);
    setActiveTagFilterBucket("all");
    applyEscUnwind();
  }

  function isEnterLikeKey(key: KeyEvent): boolean {
    return (
      key.name === "return" ||
      key.name === "enter" ||
      key.sequence === "\r" ||
      key.sequence === "\n"
    );
  }

  function resolveTagFilterInputCandidate(): string {
    return tagFilterInlineSuggestion?.full ?? tagFilterInput;
  }

  function resolveTagFilterDraftForApply(includeInputCandidate: boolean): TagFilter | undefined {
    if (!includeInputCandidate) return tagFilterDraft;
    return addTagToTagFilter(
      tagFilterDraft,
      resolveTagFilterInputCandidate(),
      activeTagFilterBucket
    );
  }

  function addTagFilterDraftCandidateFromInput(candidateOverride?: string): boolean {
    const candidate = candidateOverride ?? resolveTagFilterInputCandidate();
    const normalizedCandidate = normalizeTagToken(candidate);
    if (!normalizedCandidate) return false;

    setTagFilterDraft((current) =>
      addTagToTagFilter(current, normalizedCandidate, activeTagFilterBucket)
    );
    setTagFilterInput("");
    return true;
  }

  function handleTagFilterPanelInputKeyDown(key: KeyEvent) {
    const isEnter = isEnterLikeKey(key);
    const isCtrlEnter =
      (isEnter && key.ctrl) ||
      key.sequence === "\u001b[13;5u";

    if (key.name === "tab") {
      key.preventDefault();
      key.stopPropagation();
      cycleTagFilterBucket(key.shift ? -1 : 1);
      return;
    }

    if (key.name === "1" || key.sequence === "1") {
      key.preventDefault();
      key.stopPropagation();
      setActiveTagFilterBucket("all");
      return;
    }
    if (key.name === "2" || key.sequence === "2") {
      key.preventDefault();
      key.stopPropagation();
      setActiveTagFilterBucket("any");
      return;
    }
    if (key.name === "3" || key.sequence === "3") {
      key.preventDefault();
      key.stopPropagation();
      setActiveTagFilterBucket("none");
      return;
    }

    if (key.ctrl && key.name === "l") {
      key.preventDefault();
      key.stopPropagation();
      clearTagFilterPanelDraft();
      return;
    }

    if (key.name === "escape") {
      key.preventDefault();
      key.stopPropagation();
      closeTagFilterPanel();
      return;
    }

    if (isCtrlEnter) {
      key.preventDefault();
      key.stopPropagation();
      applyTagFilterPanel(true);
      return;
    }

    if (key.name === "right" && tagFilterInlineSuggestion) {
      key.preventDefault();
      key.stopPropagation();
      setTagFilterInput(formatTagForDisplay(tagFilterInlineSuggestion.full));
      return;
    }

    if (key.name === "backspace" && tagFilterInput.trim().length === 0) {
      key.preventDefault();
      key.stopPropagation();
      setTagFilterDraft((current) =>
        removeLastTagFromTagFilter(current, activeTagFilterBucket)
      );
      return;
    }

    if (isEnter) {
      key.preventDefault();
      key.stopPropagation();
      addTagFilterDraftCandidateFromInput();
    }
  }

  function handleLeftRailMenuSelect(item: LeftRailMenuItem) {
    switch (item) {
      case "LIST":
        openListMode();
        return;
      case "DASHBOARD":
        openDashboardMode();
        return;
      case "BACKUP":
        openBackupCenter();
        return;
      case "ADD":
        openAdd();
        return;
      case "EDIT":
        openEdit();
        return;
      case "SEARCH":
        openSearchMode();
        return;
      case "TAG_PANEL":
        openTagFilterPanel();
        return;
      case "HELP":
        if (uiState.mode === Mode.HELP) return;
        openHelp();
        return;
      case "DELETE":
        openDeleteConfirm();
        return;
      default:
        return;
    }
  }

  function closeSearch() {
    clearPendingGPrefix();
    uiDispatch({ type: "setMode", mode: Mode.LIST });
    uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
  }

  function openDeleteConfirm() {
    if (!selectedTask) return;
    let modal: UIDeleteModal | null = null;
    if (
      selectedTask.rowKind === "series_occurrence_virtual" ||
      selectedTask.rowKind === "series_occurrence_instance"
    ) {
      const occurrenceContext = resolveSelectedOccurrenceContext();
      if (!occurrenceContext) return;
      modal = {
        type: "delete",
        target: "recurring_occurrence",
        seriesTaskId: occurrenceContext.seriesTask.id,
        seriesId: occurrenceContext.seriesId,
        occurrenceIso: occurrenceContext.occurrenceIso,
        selectedRowId: occurrenceContext.row.id,
        taskTitle: occurrenceContext.seriesTask.title,
        previousMode: Mode.LIST,
        previousFocus: uiState.focus
      };
    } else {
      const persistedTask = resolvePersistedTaskForRow(selectedTask);
      if (!persistedTask) return;
      modal = {
        type: "delete",
        target: "regular_task",
        taskId: persistedTask.id,
        taskTitle: persistedTask.title,
        previousMode: Mode.LIST,
        previousFocus: uiState.focus
      };
    }

    closeViewsOverlay();
    uiDispatch({
      type: "setModal",
      modal
    });
    uiDispatch({ type: "setMode", mode: Mode.MODAL_CONFIRM });
    uiDispatch({ type: "setFocus", focus: FocusTarget.MODAL });
  }

  function openModalWithContext(modal: NonNullable<typeof uiState.modal>) {
    closeViewsOverlay();
    uiDispatch({ type: "setModal", modal });
    uiDispatch({ type: "setMode", mode: Mode.MODAL_CONFIRM });
    uiDispatch({ type: "setFocus", focus: FocusTarget.MODAL });
  }

  function closeModalWithPreviousContext(modal: {
    previousMode: Mode;
    previousFocus: FocusTarget;
  }) {
    uiDispatch({ type: "setModal", modal: null });
    uiDispatch({ type: "setMode", mode: modal.previousMode });
    uiDispatch({ type: "setFocus", focus: modal.previousFocus });
  }

  function applyTaskLinkMutation(
    taskId: string,
    mutate: (task: Task) => Task
  ): Task | undefined {
    const nowMs = Date.now();
    let updatedTask: Task | undefined;
    const nextTasks = state.tasks.map((task) => {
      if (task.id !== taskId) return task;
      updatedTask = {
        ...mutate(task),
        updatedAt: nowMs
      };
      return updatedTask;
    });
    if (!updatedTask) return undefined;
    dispatch({ type: "setTasks", tasks: nextTasks });
    return updatedTask;
  }

  function moveLinkSelection(delta: 1 | -1) {
    if (selectedTaskLinks.length === 0) return;
    const currentIndex = selectedTaskLinks.findIndex((link) => link.id === selectedLinkId);
    const safeIndex = currentIndex === -1 ? 0 : currentIndex;
    const nextIndex = (safeIndex + delta + selectedTaskLinks.length) % selectedTaskLinks.length;
    setSelectedLinkId(selectedTaskLinks[nextIndex]?.id);
  }

  function openAddTaskLinkModal() {
    if (uiState.mode === Mode.ADD) {
      if (!state.editor) {
        showShortNavigationBanner("No task draft open");
        return;
      }
      openModalWithContext({
        type: "task_link_form",
        mode: "add",
        source: {
          scope: "editor_draft"
        },
        labelValue: "",
        targetValue: "",
        kindValue: "auto",
        activeField: "target",
        previousMode: uiState.mode,
        previousFocus: uiState.focus
      });
      return;
    }

    if (!selectedPersistedTask) {
      showShortNavigationBanner("No task selected");
      return;
    }
    openModalWithContext({
      type: "task_link_form",
      mode: "add",
      source: {
        scope: "task",
        taskId: selectedPersistedTask.id
      },
      labelValue: "",
      targetValue: "",
      kindValue: "auto",
      activeField: "target",
      previousMode: Mode.LIST,
      previousFocus: uiState.focus
    });
  }

  function openEditTaskLinkModal() {
    if (!selectedPersistedTask || !selectedTaskLink) {
      showShortNavigationBanner("No link selected");
      return;
    }
    openModalWithContext({
      type: "task_link_form",
      mode: "edit",
      source: {
        scope: "task",
        taskId: selectedPersistedTask.id
      },
      linkId: selectedTaskLink.id,
      labelValue: selectedTaskLink.label ?? "",
      targetValue: selectedTaskLink.target,
      kindValue: selectedTaskLink.kind ?? "auto",
      activeField: "target",
      previousMode: Mode.LIST,
      previousFocus: uiState.focus
    });
  }

  function openDeleteTaskLinkModal() {
    if (!selectedPersistedTask || !selectedTaskLink) {
      showShortNavigationBanner("No link selected");
      return;
    }
    openModalWithContext({
      type: "task_link_delete",
      taskId: selectedPersistedTask.id,
      linkId: selectedTaskLink.id,
      label: selectedTaskLink.label,
      target: selectedTaskLink.target,
      previousMode: Mode.LIST,
      previousFocus: uiState.focus
    });
  }

  async function openTaskLinkTarget(target: string): Promise<void> {
    try {
      await openTarget(target);
    } catch {
      showShortNavigationBanner("Could not open link.");
    }
  }

  function openTaskLink(
    link: TaskLink,
    sourceTask: Task,
    previousFocus: FocusTarget = uiState.focus
  ) {
    const openDecision = decideTaskLinkOpen(link, {
      nonHttpLinkPolicy: settingsState.security.nonHttpLinkPolicy
    });
    if (openDecision.policy === "block") {
      showShortNavigationBanner("Blocked by security policy.");
      return;
    }
    if (openDecision.policy === "confirm") {
      openModalWithContext({
        type: "task_link_open_external",
        taskId: sourceTask.id,
        linkId: link.id,
        target: openDecision.target,
        scheme: openDecision.scheme,
        previousMode: Mode.LIST,
        previousFocus
      });
      return;
    }
    void openTaskLinkTarget(openDecision.target);
  }

  function selectDetailsLink(linkId: string) {
    if (uiState.mode !== Mode.LIST) return;
    if (!selectedTaskLinks.some((link) => link.id === linkId)) return;
    setSelectedLinkId(linkId);
    uiDispatch({ type: "setFocus", focus: FocusTarget.DETAILS_LINKS });
  }

  function openDetailsLink(linkId: string) {
    if (uiState.mode !== Mode.LIST || !selectedPersistedTask) return;
    const link = selectedTaskLinks.find((candidate) => candidate.id === linkId);
    if (!link) return;
    setSelectedLinkId(link.id);
    uiDispatch({ type: "setFocus", focus: FocusTarget.DETAILS_LINKS });
    openTaskLink(link, selectedPersistedTask, FocusTarget.DETAILS_LINKS);
  }

  function openSelectedTaskLink() {
    if (!selectedTaskLink || !selectedPersistedTask) {
      showShortNavigationBanner("No link selected");
      return;
    }
    openTaskLink(selectedTaskLink, selectedPersistedTask);
  }

  function copySelectedTaskLink() {
    if (!selectedTaskLink) {
      showShortNavigationBanner("No link selected");
      return;
    }
    void copyToClipboard(selectedTaskLink.target).catch(() => {
      showShortNavigationBanner("Copy failed.");
    });
  }

  function getTaskLinkFormModal(): UITaskLinkFormModal | null {
    return uiState.modal?.type === "task_link_form" ? uiState.modal : null;
  }

  function patchTaskLinkFormModal(patch: Partial<UITaskLinkFormModal>) {
    const modal = getTaskLinkFormModal();
    if (!modal) return;
    uiDispatch({
      type: "setModal",
      modal: {
        ...modal,
        ...patch
      }
    });
  }

  function moveTaskLinkFormFocus(direction: 1 | -1) {
    const modal = getTaskLinkFormModal();
    if (!modal) return;
    patchTaskLinkFormModal({
      activeField: cycleTaskLinkFormField(modal.activeField, direction)
    });
  }

  function cycleTaskLinkFormType(direction: 1 | -1) {
    const modal = getTaskLinkFormModal();
    if (!modal) return;
    patchTaskLinkFormModal({
      kindValue: cycleTaskLinkFormKind(modal.kindValue, direction)
    });
  }

  function submitTaskLinkFormModal() {
    const modal = getTaskLinkFormModal();
    if (!modal) return;

    const target = modal.targetValue.trim();
    const label = modal.labelValue.trim();
    if (!target) {
      patchTaskLinkFormModal({ error: "Target is required." });
      return;
    }

    if (modal.kindValue === "url" && !extractUrlScheme(target)) {
      patchTaskLinkFormModal({ error: "URL type requires a scheme (e.g. https://)." });
      return;
    }

    const kind = modal.kindValue === "auto" ? undefined : modal.kindValue;

    if (modal.source.scope === "editor_draft") {
      if (!state.editor) return;
      if (modal.mode !== "add") return;
      const link: TaskLink = {
        id: crypto.randomUUID(),
        target,
        ...(label ? { label } : {}),
        ...(kind ? { kind } : {}),
        source: "manual"
      };
      dispatch({
        type: "updateEditor",
        patch: {
          links: [...state.editor.links, link]
        }
      });
      showShortNavigationBanner(`Added link (${state.editor.links.length + 1})`);
      closeModalWithPreviousContext(modal);
      return;
    }

    if (modal.mode === "add") {
      const link: TaskLink = {
        id: crypto.randomUUID(),
        target,
        ...(label ? { label } : {}),
        ...(kind ? { kind } : {}),
        source: "manual"
      };
      const updatedTask = applyTaskLinkMutation(modal.source.taskId, (task) =>
        addTaskLink(task, link)
      );
      if (!updatedTask) return;
      setSelectedLinkId(link.id);
      closeModalWithPreviousContext(modal);
      return;
    }

    if (!modal.linkId) return;
    const updatedTask = applyTaskLinkMutation(modal.source.taskId, (task) =>
      updateTaskLink(task, modal.linkId, {
        target,
        label: label || undefined,
        kind
      })
    );
    if (!updatedTask) return;
    setSelectedLinkId(modal.linkId);
    closeModalWithPreviousContext(modal);
  }

  function handleDeleteTaskLinkFromModal() {
    const modal = uiState.modal;
    if (!modal || modal.type !== "task_link_delete") return;
    const updatedTask = applyTaskLinkMutation(modal.taskId, (task) =>
      deleteTaskLink(task, modal.linkId)
    );
    if (!updatedTask) return;
    const nextLinks = updatedTask.links ?? [];
    setSelectedLinkId((current) => {
      if (current && nextLinks.some((link) => link.id === current)) {
        return current;
      }
      return nextLinks[0]?.id;
    });
    closeModalWithPreviousContext(modal);
  }

  function handleOpenExternalTaskLinkFromModal() {
    const modal = uiState.modal;
    if (!modal || modal.type !== "task_link_open_external") return;
    closeModalWithPreviousContext(modal);
    void openTaskLinkTarget(modal.target);
  }

  function moveSelection(delta: number) {
    if (visibleTaskRows.length === 0) return;
    const currentIndex = visibleTaskRows.findIndex((task) => task.id === state.selectedId);
    const safeIndex = currentIndex === -1 ? 0 : currentIndex;
    const nextIndex = (safeIndex + delta + visibleTaskRows.length) % visibleTaskRows.length;
    dispatch({ type: "setSelected", id: visibleTaskRows[nextIndex].id });
  }

  function setSelectedByIndex(index: number) {
    if (visibleTaskRows.length === 0) return;
    const nextIndex = Math.max(0, Math.min(index, visibleTaskRows.length - 1));
    dispatch({ type: "setSelected", id: visibleTaskRows[nextIndex].id });
  }

  function selectTaskById(taskId: string) {
    const targetExists = visibleTaskRows.some((task) => task.id === taskId);
    if (!targetExists) return;
    clearPendingGPrefix();
    dispatch({ type: "setSelected", id: taskId });
  }

  function jumpToTop() {
    setSelectedByIndex(0);
  }

  function jumpToBottom() {
    setSelectedByIndex(visibleTaskRows.length - 1);
  }

  function moveSelectionPage(direction: 1 | -1) {
    if (visibleTaskRows.length === 0) return;
    const pageStep = Math.max(1, visibleRows - 1);
    const currentIndex = visibleTaskRows.findIndex((task) => task.id === state.selectedId);
    const safeIndex = currentIndex === -1 ? 0 : currentIndex;
    setSelectedByIndex(safeIndex + direction * pageStep);
  }

  function showShortNavigationBanner(message: string) {
    setNavigationBanner(message);
    if (navBannerTimerRef.current) {
      clearTimeout(navBannerTimerRef.current);
    }
    navBannerTimerRef.current = setTimeout(() => {
      setNavigationBanner(null);
      navBannerTimerRef.current = null;
    }, NAV_BANNER_TIMEOUT_MS);
  }

  function jumpToAttention(kind: "overdue" | "today", direction: 1 | -1) {
    if (visibleTaskRows.length === 0) {
      showShortNavigationBanner(
        kind === "overdue" ? "No overdue tasks" : "No due-today tasks"
      );
      return;
    }

    const currentIndex = visibleTaskRows.findIndex((task) => task.id === state.selectedId);
    const safeIndex = currentIndex === -1 ? 0 : currentIndex;
    const matcher =
      kind === "overdue"
        ? (task: Task) => isTaskOverdue(task, now)
        : (task: Task) => isTaskDueToday(task, now);
    const nextIndex = findNextMatchingIndex(
      visibleTaskRows,
      safeIndex,
      direction,
      matcher,
      true
    );

    if (nextIndex === null) {
      showShortNavigationBanner(
        kind === "overdue" ? "No overdue tasks" : "No due-today tasks"
      );
      return;
    }

    setSelectedByIndex(nextIndex);
  }

  function clearPendingGPrefix() {
    setPendingGPrefix(false);
    if (gPrefixTimerRef.current) {
      clearTimeout(gPrefixTimerRef.current);
      gPrefixTimerRef.current = null;
    }
  }

  function armPendingGPrefix() {
    clearPendingGPrefix();
    setPendingGPrefix(true);
    gPrefixTimerRef.current = setTimeout(() => {
      setPendingGPrefix(false);
      gPrefixTimerRef.current = null;
      cycleDue();
    }, G_PREFIX_TIMEOUT_MS);
  }

  function closeViewsOverlay() {
    setViewsOverlayOpen(false);
    setSaveViewPromptOpen(false);
    setSaveViewName("");
  }

  function toggleViewsOverlay() {
    clearPendingGPrefix();
    if (viewsOverlayOpen) {
      closeViewsOverlay();
      return;
    }
    setViewsOverlayOpen(true);
    setSaveViewPromptOpen(false);
    setSelectedViewIndex((prev) =>
      state.savedViews.length === 0
        ? 0
        : Math.max(0, Math.min(prev, state.savedViews.length - 1))
    );
  }

  function moveViewSelection(delta: 1 | -1) {
    if (state.savedViews.length === 0) return;
    setSelectedViewIndex((prev) => {
      const next = (prev + delta + state.savedViews.length) % state.savedViews.length;
      return next;
    });
  }

  function applyView(view: SavedView) {
    const nextFilters = applySavedView(view);
    dispatch({
      type: "setFilters",
      filters: {
        status: nextFilters.status,
        due: nextFilters.due,
        priority: nextFilters.priority,
        tag: nextFilters.tag,
        tagFilter: nextFilters.tagFilter,
        searchText: nextFilters.searchText
      }
    });
    closeViewsOverlay();
    showShortNavigationBanner(`Applied view: ${view.name}`);
  }

  function applyViewAtSlot(slot: number) {
    if (slot < 0 || slot >= state.savedViews.length) {
      showShortNavigationBanner(`No saved view in slot ${slot + 1}`);
      return;
    }
    const view = state.savedViews[slot];
    if (isSavedViewActive(state.filters, view)) {
      dispatch({
        type: "setFilters",
        filters: {
          ...DEFAULT_VIEW_FILTERS,
          priority: undefined,
          tag: undefined,
          tagFilter: undefined,
          searchText: undefined
        }
      });
      closeViewsOverlay();
      showShortNavigationBanner("Default view");
      return;
    }
    applyView(view);
  }

  function applySelectedView() {
    if (state.savedViews.length === 0) {
      showShortNavigationBanner("No saved views");
      return;
    }
    const index = Math.max(0, Math.min(selectedViewIndex, state.savedViews.length - 1));
    applyView(state.savedViews[index]);
  }

  function deleteSelectedView() {
    if (state.savedViews.length === 0) {
      showShortNavigationBanner("No saved views to delete");
      return;
    }
    const index = Math.max(0, Math.min(selectedViewIndex, state.savedViews.length - 1));
    const target = state.savedViews[index];
    const next = deleteViewAtIndex(state.savedViews, index);
    dispatch({ type: "setSavedViews", savedViews: next });
    setSelectedViewIndex(Math.max(0, Math.min(index, next.length - 1)));
    showShortNavigationBanner(`Deleted view: ${target.name}`);
  }

  function openSaveViewPrompt() {
    clearPendingGPrefix();
    setViewsOverlayOpen(true);
    setSaveViewPromptOpen(true);
    setSaveViewName("");
  }

  function cancelSaveViewPrompt() {
    setSaveViewPromptOpen(false);
    setSaveViewName("");
  }

  function confirmSaveViewPrompt() {
    const nowMs = Date.now();
    const result = saveViewByName(
      state.savedViews,
      saveViewName,
      state.filters,
      nowMs,
      MAX_SAVED_VIEWS
    );

    if (result.kind === "invalid_name") {
      showShortNavigationBanner("View name is required");
      return;
    }
    if (result.kind === "full") {
      showShortNavigationBanner(`Saved view limit reached (${MAX_SAVED_VIEWS})`);
      return;
    }

    dispatch({ type: "setSavedViews", savedViews: result.savedViews });
    const idx = result.savedViews.findIndex((view) => view.id === result.view.id);
    setSelectedViewIndex(idx >= 0 ? idx : 0);
    setSaveViewPromptOpen(false);
    setSaveViewName("");
    showShortNavigationBanner(
      result.kind === "created"
        ? `Saved view: ${result.view.name}`
        : `Updated view: ${result.view.name}`
    );
  }

  function normalizeOccurrenceIso(value: string | undefined): string | undefined {
    if (!value) return undefined;
    const occurrenceDate = parseLocalIsoToDate(value);
    if (!occurrenceDate) return undefined;
    return formatDateToLocalIso(occurrenceDate);
  }

  function withSeriesOccurrenceExcluded(
    tasks: Task[],
    seriesTaskId: string,
    occurrenceIso: string,
    nowMs: number
  ): Task[] {
    return tasks.map((task) => {
      if (task.id !== seriesTaskId || !task.recurrence) {
        return task;
      }
      const nextExdates = Array.from(
        new Set([...(task.recurrence.exdates ?? []), occurrenceIso])
      ).sort((left, right) => left.localeCompare(right));
      return {
        ...task,
        updatedAt: nowMs,
        recurrence: {
          ...task.recurrence,
          exdates: nextExdates
        }
      };
    });
  }

  function removeMaterializedOccurrenceInstance(
    tasks: Task[],
    seriesId: string,
    occurrenceIso: string
  ): Task[] {
    return tasks.filter(
      (task) =>
        !(
          task.instance_of?.series_id === seriesId &&
          task.instance_of?.occurrence === occurrenceIso
        )
    );
  }

  function resolveSelectedOccurrenceContext(): {
    row: VisibleTaskRow;
    seriesTask: Task;
    seriesId: string;
    occurrenceIso: string;
    instanceTask?: Task;
  } | null {
    if (!selectedTask) return null;
    if (
      selectedTask.rowKind !== "series_occurrence_virtual" &&
      selectedTask.rowKind !== "series_occurrence_instance"
    ) {
      return null;
    }

    const normalizedIso = normalizeOccurrenceIso(selectedTask.occurrenceIso);
    const seriesId = selectedTask.seriesId;
    const seriesTask = findSeriesTaskBySeriesId(seriesId);

    if (!normalizedIso || !seriesId || !seriesTask) {
      return null;
    }

    const instanceTask =
      selectedTask.rowKind === "series_occurrence_instance"
        ? findTaskById(selectedTask.id)
        : findMaterializedInstance(seriesId, normalizedIso);

    return {
      row: selectedTask,
      seriesTask,
      seriesId,
      occurrenceIso: normalizedIso,
      instanceTask
    };
  }

  /*
   * Engagement QA checklist:
   * - open -> done records exactly one completion event
   * - done -> open records no completion event
   * - recurring completion paths emit once per completed occurrence
   * - blocked overlays suppress active toast rendering; queue resumes after close
   */
  function triggerFirstRecurringTaskCreated(at: number, seriesId: string) {
    dispatch({
      type: "triggerEngagementMilestone",
      achievementKey: "FIRST_RECURRING_TASK_CREATED",
      achievementId: "FIRST_RECURRING_TASK_CREATED",
      at,
      meta: { seriesId },
      toast: {
        message: "Created your first recurring task.",
        priority: 3,
        durationMs: FIRST_RECURRING_TASK_TOAST_MS
      }
    });
  }

  function triggerFirstRecurringRepeatDone(at: number, seriesId: string, occurrenceIso: string) {
    dispatch({
      type: "triggerEngagementMilestone",
      achievementKey: "FIRST_RECURRING_REPEAT_DONE",
      achievementId: "FIRST_RECURRING_REPEAT_DONE",
      at,
      meta: { seriesId, occurrenceIso },
      toast: {
        message: "Completed your first recurring repeat occurrence.",
        priority: 2,
        durationMs: FIRST_RECURRING_REPEAT_DONE_TOAST_MS
      }
    });
  }

  function emitCompletionForTransition(params: {
    taskId: string;
    previousStatus: Task["status"] | undefined;
    nextStatus: Task["status"];
    tags: string[];
    at: number;
    recurringRepeat?: {
      seriesId: string;
      occurrenceIso: string;
    };
  }) {
    if (params.previousStatus !== "open" || params.nextStatus !== "done") {
      return;
    }
    dispatch({
      type: "recordCompletion",
      taskId: params.taskId,
      at: params.at,
      tags: params.tags
    });
    dispatch({ type: "evaluateEngagement", at: params.at });
    if (params.recurringRepeat) {
      triggerFirstRecurringRepeatDone(
        params.at,
        params.recurringRepeat.seriesId,
        params.recurringRepeat.occurrenceIso
      );
    }
  }

  function emitCompletionFromDiff(previousTasks: Task[], nextTasks: Task[], at: number) {
    const previousById = new Map(previousTasks.map((task) => [task.id, task]));
    const seriesById = new Map(
      nextTasks
        .filter((task) => task.recurrence?.series_id)
        .map((task) => [task.recurrence!.series_id, task])
    );
    for (const nextTask of nextTasks) {
      const previousTask = previousById.get(nextTask.id);
      const instance = nextTask.instance_of;
      const recurringRepeat =
        instance &&
        isRepeatOccurrenceAfterSeriesStart(
          seriesById.get(instance.series_id)?.recurrence?.dtstart,
          instance.occurrence
        )
          ? {
              seriesId: instance.series_id,
              occurrenceIso: instance.occurrence
            }
          : undefined;
      emitCompletionForTransition({
        taskId: nextTask.id,
        previousStatus: previousTask?.status ?? "open",
        nextStatus: nextTask.status,
        tags: nextTask.tags,
        at,
        recurringRepeat
      });
    }
  }

  function completeRecurringOccurrence() {
    const context = resolveSelectedOccurrenceContext();
    if (!context) {
      return;
    }

    const nowMs = Date.now();
    const occurrenceDate = parseLocalIsoToDate(context.occurrenceIso);
    if (!occurrenceDate) {
      showShortNavigationBanner("Invalid occurrence timestamp");
      return;
    }

    if (context.instanceTask) {
      const nextStatus = context.instanceTask.status === "done" ? "open" : "done";
      const updatedTasks = state.tasks.map((task) => {
        if (task.id !== context.instanceTask?.id) return task;
        return {
          ...task,
          status: nextStatus,
          updatedAt: nowMs,
          closedAt: nextStatus === "done" ? nowMs : undefined
        };
      });
      dispatch({ type: "setTasks", tasks: updatedTasks });
      dispatch({ type: "setSelected", id: context.instanceTask.id });
      const recurringRepeat = isRepeatOccurrenceAfterSeriesStart(
        context.seriesTask.recurrence?.dtstart,
        context.occurrenceIso
      )
        ? {
            seriesId: context.seriesId,
            occurrenceIso: context.occurrenceIso
          }
        : undefined;
      emitCompletionForTransition({
        taskId: context.instanceTask.id,
        previousStatus: context.instanceTask.status,
        nextStatus,
        tags: context.instanceTask.tags,
        at: nowMs,
        recurringRepeat
      });
      return;
    }

    const dueAt = occurrenceDate.getTime();
    const instanceId = crypto.randomUUID();
    const doneInstance: Task = {
      id: instanceId,
      title: context.seriesTask.title,
      status: "done",
      createdAt: nowMs,
      updatedAt: nowMs,
      closedAt: nowMs,
      dueAt,
      hasExplicitTime: context.seriesTask.hasExplicitTime,
      notes: context.seriesTask.notes,
      tags: context.seriesTask.tags,
      instance_of: {
        series_id: context.seriesId,
        occurrence: context.occurrenceIso
      }
    };

    const withExdate = withSeriesOccurrenceExcluded(
      state.tasks,
      context.seriesTask.id,
      context.occurrenceIso,
      nowMs
    );
    const updatedTasks = [...withExdate, doneInstance];
    dispatch({ type: "setTasks", tasks: updatedTasks });
    dispatch({
      type: "setTagIndex",
      tagIndex: updateTagIndex(state.tagIndex, doneInstance.tags, nowMs)
    });
    dispatch({ type: "setSelected", id: instanceId });
    const recurringRepeat = isRepeatOccurrenceAfterSeriesStart(
      context.seriesTask.recurrence?.dtstart,
      context.occurrenceIso
    )
      ? {
          seriesId: context.seriesId,
          occurrenceIso: context.occurrenceIso
        }
      : undefined;
    emitCompletionForTransition({
      taskId: instanceId,
      previousStatus: "open",
      nextStatus: "done",
      tags: doneInstance.tags,
      at: nowMs,
      recurringRepeat
    });
  }

  function skipSelectedOccurrence() {
    const context = resolveSelectedOccurrenceContext();
    if (!context) {
      showShortNavigationBanner("Skip applies to recurring occurrences");
      return;
    }

    const nowMs = Date.now();
    const withExdate = withSeriesOccurrenceExcluded(
      state.tasks,
      context.seriesTask.id,
      context.occurrenceIso,
      nowMs
    );
    const updatedTasks = removeMaterializedOccurrenceInstance(
      withExdate,
      context.seriesId,
      context.occurrenceIso
    );
    dispatch({ type: "setTasks", tasks: updatedTasks });
    showShortNavigationBanner("Skipped selected occurrence");
  }

  function snoozeSelectedOccurrence() {
    const context = resolveSelectedOccurrenceContext();
    if (!context) {
      showShortNavigationBanner("Snooze applies to recurring occurrences");
      return;
    }

    const nowMs = Date.now();
    const occurrenceDate = parseLocalIsoToDate(context.occurrenceIso);
    if (!occurrenceDate) {
      showShortNavigationBanner("Invalid occurrence timestamp");
      return;
    }

    const snoozedDate = new Date(
      occurrenceDate.getFullYear(),
      occurrenceDate.getMonth(),
      occurrenceDate.getDate() + 1,
      occurrenceDate.getHours(),
      occurrenceDate.getMinutes(),
      occurrenceDate.getSeconds()
    );

    const source = context.instanceTask ?? context.seriesTask;
    const instanceId = context.instanceTask?.id ?? crypto.randomUUID();
    const snoozedInstance: Task = {
      id: instanceId,
      title: source.title,
      status: "open",
      createdAt: context.instanceTask?.createdAt ?? nowMs,
      updatedAt: nowMs,
      dueAt: snoozedDate.getTime(),
      hasExplicitTime: source.hasExplicitTime,
      notes: source.notes,
      tags: source.tags,
      instance_of: {
        series_id: context.seriesId,
        occurrence: context.occurrenceIso
      }
    };

    const withExdate = withSeriesOccurrenceExcluded(
      state.tasks,
      context.seriesTask.id,
      context.occurrenceIso,
      nowMs
    );
    const withoutPreviousInstance = removeMaterializedOccurrenceInstance(
      withExdate,
      context.seriesId,
      context.occurrenceIso
    );
    const updatedTasks = [...withoutPreviousInstance, snoozedInstance];
    dispatch({ type: "setTasks", tasks: updatedTasks });
    dispatch({
      type: "setTagIndex",
      tagIndex: updateTagIndex(state.tagIndex, snoozedInstance.tags, nowMs)
    });
    dispatch({ type: "setSelected", id: instanceId });
    showShortNavigationBanner("Snoozed occurrence by +1 day");
  }

  function toggleSelected() {
    if (!selectedTask) return;

    if (
      selectedTask.rowKind === "series_occurrence_virtual" ||
      selectedTask.rowKind === "series_occurrence_instance"
    ) {
      completeRecurringOccurrence();
      return;
    }

    const persisted = resolvePersistedTaskForRow(selectedTask);
    if (!persisted) return;
    const nowMs = Date.now();
    const nextStatus = persisted.status === "done" ? "open" : "done";
    const updated: Task = {
      ...persisted,
      status: nextStatus,
      updatedAt: nowMs,
      closedAt: nextStatus === "done" ? nowMs : undefined
    };
    dispatch({
      type: "setTasks",
      tasks: state.tasks.map((task) => (task.id === updated.id ? updated : task))
    });
    emitCompletionForTransition({
      taskId: updated.id,
      previousStatus: persisted.status,
      nextStatus,
      tags: updated.tags,
      at: nowMs
    });
  }

  function openAdd() {
    closeViewsOverlay();
    setTimeSuggestion(getSuggestedTime(new Date()));
    uiDispatch({ type: "setMode", mode: Mode.ADD });
    uiDispatch({ type: "setFocus", focus: FocusTarget.EDITOR_TITLE });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({
      type: "setEditor",
      editor: createEmptyDraft()
    });
  }

  function openEditOccurrence() {
    const context = resolveSelectedOccurrenceContext();
    if (!context) {
      showShortNavigationBanner("No recurring occurrence selected");
      return;
    }

    const occurrenceDate = parseLocalIsoToDate(context.occurrenceIso);
    if (!occurrenceDate) {
      showShortNavigationBanner("Invalid occurrence timestamp");
      return;
    }

    const editSource: Task = context.instanceTask
      ? context.instanceTask
      : {
          ...context.seriesTask,
          id: `occurrence:${context.seriesId}:${context.occurrenceIso}`,
          dueAt: occurrenceDate.getTime(),
          recurrence: undefined
        };
    const baseDraft = createDraftFromTask(editSource);

    closeViewsOverlay();
    setTimeSuggestion(null);
    uiDispatch({ type: "setMode", mode: Mode.EDIT });
    uiDispatch({ type: "setFocus", focus: FocusTarget.EDITOR_TITLE });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({
      type: "setEditor",
      editor: {
        ...baseDraft,
        id: context.instanceTask?.id,
        repeatMode: "off",
        repeatIntervalText: "1",
        repeatWeekdays: [],
        repeatMonthdayText: "",
        repeatEndMode: "never",
        repeatUntilText: "",
        repeatCountText: "",
        repeatCustomRRuleText: "",
        editKind: "occurrence",
        sourceTaskId: context.seriesTask.id,
        sourceSeriesId: context.seriesId,
        occurrenceIso: context.occurrenceIso
      }
    });
  }

  function openEditSeries() {
    if (!selectedTask) return;

    const seriesTask =
      selectedTask.rowKind === "series_occurrence_virtual" ||
      selectedTask.rowKind === "series_occurrence_instance"
        ? findSeriesTaskBySeriesId(selectedTask.seriesId)
        : selectedTask.recurrence
          ? resolvePersistedTaskForRow(selectedTask)
          : undefined;

    if (!seriesTask) {
      showShortNavigationBanner("No recurring series selected");
      return;
    }

    closeViewsOverlay();
    setTimeSuggestion(null);
    uiDispatch({ type: "setMode", mode: Mode.EDIT });
    uiDispatch({ type: "setFocus", focus: FocusTarget.EDITOR_TITLE });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({
      type: "setEditor",
      editor: {
        ...createDraftFromTask(seriesTask),
        editKind: "series",
        sourceTaskId: seriesTask.id,
        sourceSeriesId: seriesTask.recurrence?.series_id
      }
    });
  }

  function openEdit() {
    if (!selectedTask) return;
    if (
      selectedTask.rowKind === "series_occurrence_virtual" ||
      selectedTask.rowKind === "series_occurrence_instance"
    ) {
      openEditOccurrence();
      return;
    }

    const persisted = resolvePersistedTaskForRow(selectedTask);
    if (!persisted) return;
    closeViewsOverlay();
    setTimeSuggestion(null);
    uiDispatch({ type: "setMode", mode: Mode.EDIT });
    uiDispatch({ type: "setFocus", focus: FocusTarget.EDITOR_TITLE });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({
      type: "setEditor",
      editor: {
        ...createDraftFromTask(persisted),
        editKind: "regular"
      }
    });
  }

  function openDuplicate() {
    if (!selectedTask) return;
    const persisted = resolvePersistedTaskForRow(selectedTask);
    if (!persisted) return;
    closeViewsOverlay();
    const baseDraft = createDraftFromTask(persisted);
    const dueText = persisted.status === "done" ? formatDate(now) : baseDraft.dueText;
    const timeText = persisted.status === "done" ? "" : baseDraft.timeText;
    setTimeSuggestion(getSuggestedTime(new Date()));
    uiDispatch({ type: "setMode", mode: Mode.ADD });
    uiDispatch({ type: "setFocus", focus: FocusTarget.EDITOR_TITLE });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({
      type: "setEditor",
      editor: {
        ...baseDraft,
        id: undefined,
        dueText,
        timeText,
        editKind: "regular",
        sourceTaskId: undefined,
        sourceSeriesId: undefined,
        occurrenceIso: undefined
      }
    });
  }

  function cancelEditor() {
    clearPendingGPrefix();
    setTimeSuggestion(null);
    uiDispatch({ type: "setMode", mode: Mode.LIST });
    uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({ type: "setEditor", editor: null });
  }

  function updateEditorDraft(patch: Partial<EditorDraft>) {
    if (!state.editor) return;
    const previousDraft = state.editor;
    const nextDraft: EditorDraft = {
      ...previousDraft,
      ...patch
    };
    const reconciledFocus = resolveEditorFocusAfterDraftChange(
      uiState.focus,
      previousDraft,
      nextDraft
    );
    if (reconciledFocus !== uiState.focus) {
      uiDispatch({ type: "setFocus", focus: reconciledFocus });
    }
    dispatch({ type: "updateEditor", patch });
  }

  function saveEditor() {
    if (!state.editor) return;
    const draft = state.editor;
    // Keep recurrence draft values in-memory; persistence is gated by repeatMode in buildRecurrenceFromDraft.
    const title = draft.title.trim();
    if (!title) return;

    const nowMs = Date.now();
    const timeText = draft.timeText.trim();
    const timeMinutes = timeText ? parseDueTime(timeText) : undefined;
    if (timeText && timeMinutes === undefined) {
      showShortNavigationBanner("Invalid time format (HH:mm)");
      return;
    }

    const { dueAt, hasExplicitTime } = combineDueDateTime(draft.dueText, timeText);
    const tags = parseTagsInput(draft.tagsText);
    const notes = draft.notes.trim() || undefined;
    const links = draft.links.map((link) => ({ ...link }));

    if (uiState.mode === Mode.ADD) {
      const taskId = crypto.randomUUID();
      const recurrenceBuild = buildRecurrenceFromDraft(
        draft,
        dueAt,
        `series:${taskId}`
      );
      if (recurrenceBuild.error) {
        showShortNavigationBanner(recurrenceBuild.error);
        return;
      }

      const newTask: Task = {
        id: taskId,
        title,
        status: "open",
        createdAt: nowMs,
        updatedAt: nowMs,
        dueAt,
        hasExplicitTime,
        notes,
        tags,
        ...(links.length > 0 ? { links } : {}),
        ...(recurrenceBuild.recurrence ? { recurrence: recurrenceBuild.recurrence } : {})
      };

      dispatch({ type: "setTasks", tasks: [...state.tasks, newTask] });
      dispatch({
        type: "setTagIndex",
        tagIndex: updateTagIndex(state.tagIndex, tags, nowMs)
      });
      if (recurrenceBuild.recurrence) {
        triggerFirstRecurringTaskCreated(nowMs, recurrenceBuild.recurrence.series_id);
      }
      dispatch({ type: "setSelected", id: newTask.id });
      uiDispatch({ type: "setMode", mode: Mode.LIST });
      uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
      uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
      dispatch({ type: "setEditor", editor: null });
      return;
    }

    if (uiState.mode === Mode.EDIT) {
      if (draft.editKind === "occurrence") {
        const seriesId = draft.sourceSeriesId;
        const occurrenceIso = normalizeOccurrenceIso(draft.occurrenceIso);
        const seriesTask =
          findTaskById(draft.sourceTaskId) ?? findSeriesTaskBySeriesId(seriesId);

        if (!seriesId || !occurrenceIso || !seriesTask?.recurrence) {
          showShortNavigationBanner("Unable to edit occurrence");
          return;
        }

        let tasksWithSeriesExdate = withSeriesOccurrenceExcluded(
          state.tasks,
          seriesTask.id,
          occurrenceIso,
          nowMs
        );
        const withoutPreviousInstance = removeMaterializedOccurrenceInstance(
          tasksWithSeriesExdate,
          seriesId,
          occurrenceIso
        );

        const instanceId = draft.id ?? crypto.randomUUID();
        const existingInstance = draft.id ? findTaskById(draft.id) : undefined;
        const instance: Task = {
          id: instanceId,
          title,
          status: existingInstance?.status ?? "open",
          createdAt: existingInstance?.createdAt ?? nowMs,
          updatedAt: nowMs,
          dueAt,
          hasExplicitTime,
          closedAt: existingInstance?.status === "done" ? existingInstance.closedAt : undefined,
          notes,
          tags,
          instance_of: {
            series_id: seriesId,
            occurrence: occurrenceIso
          }
        };

        tasksWithSeriesExdate = [...withoutPreviousInstance, instance];
        dispatch({ type: "setTasks", tasks: tasksWithSeriesExdate });
        dispatch({
          type: "setTagIndex",
          tagIndex: updateTagIndex(state.tagIndex, tags, nowMs)
        });
        dispatch({ type: "setSelected", id: instanceId });
      } else if (draft.editKind === "series") {
        const seriesTask =
          findTaskById(draft.sourceTaskId ?? draft.id) ??
          findSeriesTaskBySeriesId(draft.sourceSeriesId);
        if (!seriesTask) {
          showShortNavigationBanner("Unable to edit recurring series");
          return;
        }

        const recurrenceBuild = buildRecurrenceFromDraft(
          draft,
          dueAt,
          seriesTask.recurrence?.series_id ?? draft.sourceSeriesId ?? `series:${seriesTask.id}`
        );
        if (recurrenceBuild.error) {
          showShortNavigationBanner(recurrenceBuild.error);
          return;
        }

        const updatedTasks = state.tasks.map((task) => {
          if (task.id !== seriesTask.id) return task;
          return {
            ...task,
            title,
            dueAt,
            hasExplicitTime,
            notes,
            tags,
            updatedAt: nowMs,
            recurrence: recurrenceBuild.recurrence
          };
        });
        dispatch({ type: "setTasks", tasks: updatedTasks });
        dispatch({
          type: "setTagIndex",
          tagIndex: updateTagIndex(state.tagIndex, tags, nowMs)
        });
        dispatch({ type: "setSelected", id: seriesTask.id });
      } else {
        const targetTask = draft.id ? findTaskById(draft.id) : undefined;
        if (!targetTask) return;

        const recurrenceBuild = buildRecurrenceFromDraft(
          draft,
          dueAt,
          targetTask.recurrence?.series_id ?? `series:${targetTask.id}`
        );
        if (recurrenceBuild.error) {
          showShortNavigationBanner(recurrenceBuild.error);
          return;
        }

        const updatedTasks = state.tasks.map((task) => {
          if (task.id !== targetTask.id) return task;
          return {
            ...task,
            title,
            dueAt,
            hasExplicitTime,
            notes,
            tags,
            updatedAt: nowMs,
            recurrence: recurrenceBuild.recurrence
          };
        });
        dispatch({ type: "setTasks", tasks: updatedTasks });
        dispatch({
          type: "setTagIndex",
          tagIndex: updateTagIndex(state.tagIndex, tags, nowMs)
        });
        if (!targetTask.recurrence && recurrenceBuild.recurrence) {
          triggerFirstRecurringTaskCreated(nowMs, recurrenceBuild.recurrence.series_id);
        }
      }
    }

    uiDispatch({ type: "setMode", mode: Mode.LIST });
    uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
    uiDispatch({ type: "setEditorScrollOffset", scrollOffset: 0 });
    dispatch({ type: "setEditor", editor: null });
  }

  function finishDeleteModalAction(
    modal: UIDeleteModal,
    deletedRowId: string,
    nextTasks: Task[]
  ) {
    const visibleIds = visibleTaskRows.map((task) => task.id);
    const nextSelectedId = getNextSelectedIdAfterDelete(visibleIds, deletedRowId);
    dispatch({ type: "setTasks", tasks: nextTasks });
    dispatch({ type: "setSelected", id: nextSelectedId });
    uiDispatch({ type: "setModal", modal: null });
    uiDispatch({ type: "setMode", mode: modal.previousMode });
    uiDispatch({ type: "setFocus", focus: modal.previousFocus });
  }

  function handleDeleteSelected() {
    const modal = uiState.modal;
    if (!modal || modal.type !== "delete") return;
    if (modal.target === "regular_task") {
      finishDeleteModalAction(
        modal,
        modal.taskId,
        state.tasks.filter((task) => task.id !== modal.taskId)
      );
      return;
    }

    const nowMs = Date.now();
    const nextTasks = deleteRecurringOccurrence(state.tasks, {
      seriesTaskId: modal.seriesTaskId,
      seriesId: modal.seriesId,
      occurrenceIso: modal.occurrenceIso,
      nowMs
    });
    finishDeleteModalAction(modal, modal.selectedRowId, nextTasks);
  }

  function handleDeleteSelectedAndFuture() {
    const modal = uiState.modal;
    if (!modal || modal.type !== "delete" || modal.target !== "recurring_occurrence") return;
    const nowMs = Date.now();
    const nextTasks = deleteRecurringOccurrenceAndFuture(state.tasks, {
      seriesTaskId: modal.seriesTaskId,
      seriesId: modal.seriesId,
      occurrenceIso: modal.occurrenceIso,
      nowMs
    });
    finishDeleteModalAction(modal, modal.selectedRowId, nextTasks);
  }

  function confirmDeleteSelectedFromModal() {
    handleDeleteSelected();
  }

  function confirmDeleteSelectedAndFutureFromModal() {
    handleDeleteSelectedAndFuture();
  }

  function cancelDeleteSelectedFromModal() {
    applyEscUnwind();
  }

  function openEmptyNuxModal(options?: {
    step?: EmptyNuxStep;
    startedFromNux?: boolean;
    createdTaskId?: string;
  }) {
    if (uiState.modal && uiState.modal.type !== "emptyNux") return;
    uiDispatch(openEmptyNux(options));
    uiDispatch({ type: "setMode", mode: Mode.MODAL_CONFIRM });
    uiDispatch({ type: "setFocus", focus: FocusTarget.MODAL });
  }

  function startEmptyNuxAddFlow() {
    uiDispatch(
      openEmptyNux({
        step: "adding",
        startedFromNux: true
      })
    );
    uiDispatch({ type: "setModal", modal: null });
    openAdd();
  }

  function dismissEmptyNuxModal() {
    uiDispatch(dismissEmptyNux());
  }

  function showEmptyNuxShortcutsModal() {
    openEmptyNuxModal({ step: "shortcuts" });
  }

  function returnToEmptyNuxWelcomeModal() {
    openEmptyNuxModal({ step: "welcome" });
  }

  function clearEmptyNuxWalkthrough() {
    uiDispatch(clearEmptyNux());
  }

  function closeCelebrateToList() {
    const createdTaskId = uiState.emptyNux?.createdTaskId;
    uiDispatch(clearEmptyNux());
    clearPendingGPrefix();
    closeViewsOverlay();
    uiDispatch({ type: "setMode", mode: Mode.LIST });
    uiDispatch({ type: "setFocus", focus: FocusTarget.TASK_LIST });
    if (createdTaskId) {
      dispatch({ type: "setSelected", id: createdTaskId });
    }
  }

  function createTaskFromEmptyNuxModal() {
    startEmptyNuxAddFlow();
  }

  function getActiveOverdueModalEvent(): TaskOverdueEvent | null {
    if (uiState.mode !== Mode.MODAL_CONFIRM) return null;
    if (!uiState.modal || uiState.modal.type !== "overdue") return null;
    return uiState.modal.event;
  }

  function handleOverdueModalSnooze() {
    const event = getActiveOverdueModalEvent();
    if (!event) return;
    const updatedTasks = applyOverdueSnooze(state.tasks, event, Date.now(), 10);
    dispatch({ type: "setTasks", tasks: updatedTasks });
    applyEscUnwind();
  }

  function handleOverdueModalDone() {
    const event = getActiveOverdueModalEvent();
    if (!event) return;
    const nowMs = Date.now();
    const updatedTasks = applyOverdueMarkDone(state.tasks, event, nowMs);
    dispatch({ type: "setTasks", tasks: updatedTasks });
    emitCompletionFromDiff(state.tasks, updatedTasks, nowMs);
    applyEscUnwind();
  }

  function handleOverdueModalGoToTask() {
    const event = getActiveOverdueModalEvent();
    if (!event) return;

    openListMode();
    dispatch({
      type: "setFilters",
      filters: {
        status: "all",
        due: "any",
        priority: undefined,
        tag: undefined,
        tagFilter: undefined,
        searchText: undefined
      }
    });

    const goToTarget = resolveGoToTaskTarget(state.tasks, event);
    const revealRows = buildVisibleTaskRows(
      state.tasks,
      {
        status: "all",
        due: "any",
        priority: undefined,
        tag: undefined,
        tagFilter: undefined,
        searchText: undefined
      },
      state.sortMode,
      Date.now()
    );
    const selectedRow =
      revealRows.find((row) => row.id === goToTarget.preferredTaskId) ??
      (goToTarget.fallbackSourceTaskId
        ? revealRows.find((row) => row.sourceTaskId === goToTarget.fallbackSourceTaskId)
        : undefined) ??
      revealRows[0];
    if (selectedRow) {
      dispatch({ type: "setSelected", id: selectedRow.id });
    }
    showShortNavigationBanner(`Jumped to overdue task: ${event.title}`);
  }

  function setTagFilter(next?: TagFilter) {
    dispatch({
      type: "setFilters",
      filters: {
        tag: undefined,
        tagFilter: normalizeTagFilter(next)
      }
    });
  }

  function clearTagFilters() {
    dispatch({
      type: "setFilters",
      filters: {
        tag: undefined,
        tagFilter: undefined
      }
    });
  }

  function toggleTagInTagFilter(
    current: TagFilter | undefined,
    rawTag: string,
    bucket: TagFilterBucket
  ): TagFilter | undefined {
    const normalizedTag = normalizeTagToken(rawTag);
    if (!normalizedTag) return normalizeTagFilter(current);

    const next: TagFilter = {
      all: [...(current?.all ?? [])],
      any: [...(current?.any ?? [])],
      none: [...(current?.none ?? [])]
    };
    const bucketTags = next[bucket] ?? [];
    const alreadyPresent = bucketTags.includes(normalizedTag);
    const updatedBucketTags = alreadyPresent
      ? bucketTags.filter((tag) => tag !== normalizedTag)
      : [...bucketTags, normalizedTag];
    next[bucket] = updatedBucketTags;
    return normalizeTagFilter(next);
  }

  function addTagToTagFilter(
    current: TagFilter | undefined,
    rawTag: string,
    bucket: TagFilterBucket
  ): TagFilter | undefined {
    const normalizedTag = normalizeTagToken(rawTag);
    if (!normalizedTag) return normalizeTagFilter(current);

    const next: TagFilter = {
      all: [...(current?.all ?? [])],
      any: [...(current?.any ?? [])],
      none: [...(current?.none ?? [])]
    };
    const bucketTags = new Set(next[bucket] ?? []);
    bucketTags.add(normalizedTag);
    next[bucket] = Array.from(bucketTags);
    return normalizeTagFilter(next);
  }

  function removeLastTagFromTagFilter(
    current: TagFilter | undefined,
    bucket: TagFilterBucket
  ): TagFilter | undefined {
    const tags = current?.[bucket] ?? [];
    if (tags.length === 0) return normalizeTagFilter(current);
    const next: TagFilter = {
      all: [...(current?.all ?? [])],
      any: [...(current?.any ?? [])],
      none: [...(current?.none ?? [])]
    };
    next[bucket] = tags.slice(0, -1);
    return normalizeTagFilter(next);
  }

  function removeTagFromTagFilter(
    current: TagFilter | undefined,
    bucket: TagFilterBucket,
    rawTag: string
  ): TagFilter | undefined {
    const normalizedTag = normalizeTagToken(rawTag);
    if (!normalizedTag) return normalizeTagFilter(current);
    const next: TagFilter = {
      all: [...(current?.all ?? [])],
      any: [...(current?.any ?? [])],
      none: [...(current?.none ?? [])]
    };
    next[bucket] = (next[bucket] ?? []).filter((tag) => tag !== normalizedTag);
    return normalizeTagFilter(next);
  }

  function toggleTagInBucket(
    rawTag: string,
    bucket: TagFilterBucket
  ): TagFilter | undefined {
    const nextTagFilter = toggleTagInTagFilter(state.filters.tagFilter, rawTag, bucket);
    setTagFilter(nextTagFilter);
    return nextTagFilter;
  }

  function cycleStatus() {
    const order: Array<"all" | "open" | "done" | "archived"> = [
      "all",
      "open",
      "done",
      "archived"
    ];
    const current = order.indexOf(state.filters.status);
    const next = order[(current + 1) % order.length];
    dispatch({ type: "setFilters", filters: { status: next } });
  }

  function cycleSort() {
    const currentIndex = SORT_MODE_ORDER.indexOf(state.sortMode);
    const safeIndex = currentIndex === -1 ? 0 : currentIndex;
    const nextSortMode = SORT_MODE_ORDER[(safeIndex + 1) % SORT_MODE_ORDER.length];
    dispatch({ type: "setSortMode", sortMode: nextSortMode });
    showShortNavigationBanner(`Sort: ${getSortModeLabel(nextSortMode)}`);
  }

  function cycleDue() {
    const order: Array<"any" | "overdue" | "today" | "next7"> = [
      "any",
      "overdue",
      "today",
      "next7"
    ];
    const current = order.indexOf(state.filters.due);
    const next = order[(current + 1) % order.length];
    dispatch({ type: "setFilters", filters: { due: next } });
  }

  function cyclePriority() {
    const priorities = getSortedOpenTaskPriorities(state.tasks);
    if (priorities.length === 0) {
      dispatch({ type: "setFilters", filters: { priority: undefined } });
      showShortNavigationBanner("No priority tags on open tasks");
      return;
    }

    const current = normalizePriorityFilterValue(state.filters.priority);
    const currentIndex = current ? priorities.indexOf(current) : -1;
    if (currentIndex < 0) {
      dispatch({ type: "setFilters", filters: { priority: priorities[0] } });
      return;
    }

    const nextIndex = currentIndex + 1;
    if (nextIndex >= priorities.length) {
      dispatch({ type: "setFilters", filters: { priority: undefined } });
      return;
    }
    dispatch({ type: "setFilters", filters: { priority: priorities[nextIndex] } });
  }

  function moveDashboardTagSelection(delta: 1 | -1) {
    if (uiState.mode !== Mode.DASHBOARD || dashboardTopTags.length === 0) return;
    setDashboardTagSelection((prev) => {
      const next = (prev + delta + dashboardTopTags.length) % dashboardTopTags.length;
      return next;
    });
  }

  function applyDashboardTagAtIndex(selectionIndex: number) {
    if (state.filters.status === "done" || state.filters.status === "archived") {
      showShortNavigationBanner("Top tags available for OPEN tasks only");
      return;
    }
    if (dashboardTopTags.length === 0) {
      showShortNavigationBanner("No tagged open tasks");
      return;
    }

    const clampedIndex = Math.max(0, Math.min(selectionIndex, dashboardTopTags.length - 1));
    const selected = dashboardTopTags[clampedIndex];
    if (!selected) return;
    setDashboardTagSelection(clampedIndex);
    dispatch({
      type: "setFilters",
      filters: {
        tag: selected.tag,
        tagFilter: undefined
      }
    });
    showShortNavigationBanner(`Dashboard tag filter: ${formatTagForDisplay(selected.tag)}`);
  }

  function applyDashboardSelectedTag() {
    if (uiState.mode !== Mode.DASHBOARD) return;
    applyDashboardTagAtIndex(clampedDashboardTagSelection);
  }

  function handleDashboardTopTagClick(index: number) {
    if (uiState.mode !== Mode.DASHBOARD) return;
    applyDashboardTagAtIndex(index);
  }

  function toggleBottomDueQuickFilter(targetDue: "overdue" | "today" | "next7") {
    const alreadyActive =
      state.filters.status === "open" && state.filters.due === targetDue;
    if (alreadyActive) {
      dispatch({ type: "setFilters", filters: { status: "all", due: "any" } });
      showShortNavigationBanner("Quick filter cleared");
      return;
    }

    dispatch({
      type: "setFilters",
      filters: {
        status: "open",
        due: targetDue
      }
    });
    showShortNavigationBanner(`Quick filter: OPEN + ${targetDue.toUpperCase()}`);
  }

  function toggleBottomCompletedQuickFilter() {
    const alreadyActive =
      state.filters.status === "done" && state.filters.due === "any";
    if (alreadyActive) {
      dispatch({ type: "setFilters", filters: { status: "all" } });
      showShortNavigationBanner("Quick filter cleared");
      return;
    }

    dispatch({
      type: "setFilters",
      filters: {
        status: "done",
        due: "any"
      }
    });
    showShortNavigationBanner("Quick filter: DONE");
  }

  function isBottomTagQuickFilterActive(tag: string): boolean {
    if (!isEmptyTagFilter(state.filters.tagFilter)) {
      return (state.filters.tagFilter?.all ?? []).includes(tag);
    }
    return state.filters.tag === tag;
  }

  function toggleBottomTagQuickFilter(tag: string) {
    if (!isEmptyTagFilter(state.filters.tagFilter)) {
      const nextTagFilter = toggleTagInBucket(tag, "all");
      showShortNavigationBanner(
        nextTagFilter
          ? `Tag filter (ALL): ${formatTagForDisplay(tag)}`
          : "Boolean tag filter cleared"
      );
      return;
    }

    const alreadyActive = state.filters.tag === tag;
    dispatch({
      type: "setFilters",
      filters: {
        tag: alreadyActive ? undefined : tag,
        tagFilter: undefined
      }
    });
    showShortNavigationBanner(
      alreadyActive
        ? "Tag quick filter cleared"
        : `Tag quick filter: ${formatTagForDisplay(tag)}`
    );
  }

  function isBottomPriorityQuickFilterActive(priorityTag: string): boolean {
    const normalizedPriority = normalizePriorityFilterValue(priorityTag);
    if (!normalizedPriority) return false;
    return (
      state.filters.status === "open" &&
      state.filters.due === "any" &&
      normalizePriorityFilterValue(state.filters.priority) === normalizedPriority
    );
  }

  function toggleBottomPriorityQuickFilter(priorityTag: string) {
    const normalizedPriority = normalizePriorityFilterValue(priorityTag);
    if (!normalizedPriority) return;

    const alreadyActive = isBottomPriorityQuickFilterActive(normalizedPriority);
    if (alreadyActive) {
      dispatch({
        type: "setFilters",
        filters: {
          status: "all",
          due: "any",
          priority: undefined
        }
      });
      showShortNavigationBanner("Priority quick filter cleared");
      return;
    }

    dispatch({
      type: "setFilters",
      filters: {
        status: "open",
        due: "any",
        priority: normalizedPriority
      }
    });
    const displayPriority =
      formatPriorityForDisplay(normalizedPriority) ?? normalizedPriority;
    showShortNavigationBanner(`Quick filter: OPEN + ${displayPriority}`);
  }

  function toggleTagFilter() {
    const activeTags = Array.from(
      new Set(
        state.tasks
          .filter((task) => task.status === "open")
          .flatMap((task) => task.tags)
      )
    ).sort((left, right) => left.localeCompare(right));

    if (activeTags.length === 0) {
      dispatch({ type: "setFilters", filters: { tag: undefined, tagFilter: undefined } });
      return;
    }

    const currentTag = state.filters.tag;
    const currentIndex = currentTag ? activeTags.indexOf(currentTag) : -1;
    const nextIndex = currentIndex + 1;

    if (nextIndex >= activeTags.length || currentIndex === -1) {
      dispatch({
        type: "setFilters",
        filters: {
          tag: currentIndex === -1 ? activeTags[0] : undefined,
          tagFilter: undefined
        }
      });
      return;
    }

    dispatch({
      type: "setFilters",
      filters: {
        tag: activeTags[nextIndex],
        tagFilter: undefined
      }
    });
  }

  function updateSearch(value: string) {
    dispatch({ type: "setFilters", filters: { searchText: value } });
  }

  function handlePickTag(tag: string) {
    if (!state.editor) return;
    const nextValue = replaceLastTagToken(state.editor.tagsText, tag);
    dispatch({ type: "updateEditor", patch: { tagsText: nextValue } });
  }

  function updateSaveViewName(value: string) {
    setSaveViewName(value.slice(0, VIEW_NAME_MAX_LENGTH));
  }

  if (!terminalIsSupported) {
    return (
      <box
        style={{
          height: "100%",
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: theme.bg,
          color: theme.text
        }}
      >
        <box
          style={{
            border: true,
            borderStyle: "single",
            borderColor: theme.warn,
            backgroundColor: theme.panel,
            paddingLeft: 2,
            paddingRight: 2,
            paddingTop: 1,
            paddingBottom: 1,
            flexDirection: "column",
            alignItems: "center"
          }}
        >
          <text style={{ color: theme.warn, fontWeight: "bold" }}>{terminalSizeWarning}</text>
          <text style={{ color: theme.muted }}>Resize terminal to continue.</text>
          <text style={{ color: theme.muted }}>Press q to quit.</text>
        </box>
      </box>
    );
  }

  return (
    <box
      style={{
        flexDirection: "row",
        height: "100%",
        backgroundColor: theme.bg,
        color: theme.text
      }}
    >
      <box
        style={{
          width: layout.railWidth,
          backgroundColor: theme.accentPurple,
          padding: 1,
          border: true,
          borderStyle: "single",
          borderColor: theme.outline
        }}
      >
        <LeftRail
          mode={uiState.mode}
          focus={uiState.focus}
          filters={state.filters}
          sortMode={state.sortMode}
          fastPulseOn={fastPulseOn}
          flashMode={settingsState.flashMode}
          logoMode={settingsState.logoMode}
          onMenuSelect={handleLeftRailMenuSelect}
          terminalWidth={terminalWidth}
          showLogo={showLogo}
          activeThemeId={settingsState.themeId === "rotating" ? activeThemeId : undefined}
        />
      </box>

      <box style={{ flexDirection: "column", flexGrow: 1 }}>
        <box
          style={{
            height: 4,
            backgroundColor: isDashboardMode ? theme.accentBlue : selectedHeaderBackground,
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            border: true,
            borderStyle: "single",
            borderColor: theme.outline
          }}
        >
          <box style={{ width: "100%", justifyContent: "center", alignItems: "center" }}>
            <text
              style={{
                color: theme.bg,
                fontWeight: "bold"
              }}
            >
              {isDashboardMode
                ? "DASHBOARD MODE"
                : isBackupMode
                  ? "BACKUP CENTER"
                : selectedTask
                  ? selectedTask.title.toUpperCase()
                  : "NO TASK SELECTED"}
            </text>
          </box>
          <box style={{ width: "100%", justifyContent: "center", alignItems: "center" }}>
            <text
              style={{
                color: theme.bg,
                fontWeight: "bold"
              }}
            >
              {isDashboardMode
                ? `FILTERED TASKS: ${visibleTaskRows.length}`
                : isBackupMode
                  ? "SAFE IMPORT / EXPORT FLOW"
                : selectedTask
                  ? getDueInLabel(selectedTask, now)
                  : ""}
            </text>
          </box>
        </box>

        {isDashboardMode ? (
          <box
            key={`dashboard-pane-${terminalWidth}x${terminalHeight}`}
            style={{ flexDirection: "column", flexGrow: 1 }}
          >
            <box
              style={{
                backgroundColor: dashboardTheme.panel,
                paddingLeft: 3,
                paddingTop: 1
              }}
            >
              <text style={{ color: dashboardTheme.muted }}>DASHBOARD</text>
            </box>
            <box
              style={{
                flexGrow: 1,
                padding: 1,
                backgroundColor: dashboardTheme.panel,
                border: true,
                borderStyle: "single",
                borderColor: dashboardTheme.outline
              }}
            >
              <DashboardPane
                tasks={visibleTaskRows}
                filters={state.filters}
                topTags={dashboardTopTags}
                selectedTopTagIndex={clampedDashboardTagSelection}
                now={now}
                width={dashboardPaneWidth}
                height={dashboardPaneHeight}
                onTopTagClick={handleDashboardTopTagClick}
              />
            </box>
          </box>
        ) : (
          <box
            key={`list-pane-${terminalWidth}x${terminalHeight}`}
            style={{ flexDirection: "row", flexGrow: 1 }}
          >
            <box style={{ flexDirection: "column", flexGrow: 1 }}>
              <box
                style={{
                  backgroundColor: taskListTheme.panel,
                  paddingLeft: 3,
                  paddingTop: 1
                }}
              >
                <text style={{ color: taskListTheme.muted }}>TASK LIST</text>
              </box>
              <box
                style={{
                  flexGrow: 1,
                  padding: 1,
                  backgroundColor: taskListTheme.panel,
                  border: true,
                  borderStyle: "single",
                  borderColor: taskListTheme.outline
                }}
              >
                <box style={{ flexDirection: "column", flexGrow: 1 }}>
                  {uiState.mode === Mode.SEARCH ? (
                    <box style={{ flexDirection: "column", marginBottom: 1 }}>
                      <text style={{ color: taskListTheme.muted }}>SEARCH</text>
                      <input
                        value={state.filters.searchText ?? ""}
                        onChange={updateSearch}
                        focused={uiState.focus === FocusTarget.SEARCH_INPUT}
                        placeholder="Type to filter tasks and tags; Enter/Esc closes"
                        style={{ backgroundColor: inputTheme.bg, color: inputTheme.text }}
                      />
                    </box>
                  ) : null}
                  <TaskList
                    tasks={visibleTaskRows}
                    selectedId={state.selectedId}
                    now={now}
                    pulseOn={pulseOn}
                    fastPulseOn={fastPulseOn}
                    flashMode={settingsState.flashMode}
                    onSelectTask={selectTaskById}
                    scrollOffset={uiState.scrollOffset}
                    visibleRows={visibleRows}
                    visibleLines={visibleLines}
                  />
                </box>
              </box>
            </box>

            <box style={{ flexDirection: "column", width: layout.rightWidth }}>
              {isEditorMode(uiState.mode) ? (
                <box
                  style={{
                    backgroundColor: theme.panel,
                    paddingLeft: 3,
                    paddingTop: 1
                  }}
                >
                  <text style={{ color: theme.muted }}>
                    {uiState.mode === Mode.ADD ? "ADD TASK" : "EDIT TASK"}
                  </text>
                </box>
              ) : (
              <box
                style={{
                  backgroundColor: theme.panel,
                  paddingLeft: 3,
                  paddingTop: 1
                }}
              >
                <text style={{ color: theme.muted }}>DETAILS</text>
              </box>
              )}
              <box
                style={{
                  flexGrow: 1,
                  padding: 1,
                  backgroundColor: theme.panel,
                  border: true,
                  borderStyle: "single",
                  borderColor: theme.outline
                }}
              >
                {isEditorMode(uiState.mode) && state.editor ? (
                  <EditorPane
                    mode={uiState.mode}
                    draft={state.editor}
                    focus={toEditorFocus(uiState.focus)}
                    availableHeightLines={editorPaneHeightLines}
                    scrollOffset={uiState.editorScrollOffset}
                    tagInlineSuggestion={
                      uiState.focus === FocusTarget.EDITOR_TAGS ? tagInlineSuggestion : null
                    }
                    dueSuggestionHint={dueSuggestionHint}
                    timeSuggestionHint={timeSuggestionHint}
                    recurrencePreview={recurrencePreview}
                    onUpdate={updateEditorDraft}
                    onScrollOffsetChange={(scrollOffset) =>
                      uiDispatch({ type: "setEditorScrollOffset", scrollOffset })
                    }
                    onSave={saveEditor}
                    onCancel={cancelEditor}
                  />
                ) : (
                  <DetailsPane
                    task={selectedTask}
                    now={now}
                    pulseOn={pulseOn}
                    fastPulseOn={fastPulseOn}
                    flashMode={settingsState.flashMode}
                    selectedLinkId={selectedLinkId}
                    linksFocused={uiState.focus === FocusTarget.DETAILS_LINKS}
                    onSelectLink={selectDetailsLink}
                    onOpenLink={openDetailsLink}
                  />
                )}
              </box>
            </box>
          </box>
        )}

        {activeBanners.map((message, index) => {
          const isSaveFailure = message.startsWith("Save failed:");
          const isNavigationNotice = message.startsWith("No ");
          return (
            <box
              key={`${index}:${message}`}
              style={{
                height: 1,
                backgroundColor: isSaveFailure
                  ? notificationsTheme.danger
                  : isNavigationNotice
                    ? notificationsTheme.accentBlue
                    : notificationsTheme.warn,
                paddingLeft: 1,
                paddingRight: 1
              }}
            >
              <text style={{ color: notificationsTheme.bg }}>{message}</text>
            </box>
          );
        })}

        <box
          style={{
            height: 3,
            backgroundColor: theme.panel,
            border: true,
            borderStyle: "single",
            borderColor: theme.outline,
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          {bottomInfoView === "tags" ? (
            <box style={{ flexDirection: "row", gap: 0 }}>
              {tagTickerSegments.length === 0 ? (
                <text style={{ color: theme.muted }}>NO TAGS</text>
              ) : (
                tagTickerSegments.map((segment, index) => (
                  <box key={segment.tag} style={{ flexDirection: "row", gap: 0 }}>
                    {index > 0 ? (
                      <text style={{ color: theme.muted }}>  </text>
                    ) : null}
                    <box
                      style={{
                        backgroundColor: colorForTag(segment.tag),
                        paddingLeft: 1,
                        paddingRight: 1
                      }}
                      onMouseDown={(event) => {
                        if (event.button !== 0) return;
                        toggleBottomTagQuickFilter(segment.tag);
                      }}
                    >
                      <text
                        style={{
                          color: isBottomTagQuickFilterActive(segment.tag)
                            ? theme.text
                            : theme.bg,
                          fontWeight: isBottomTagQuickFilterActive(segment.tag)
                            ? "bold"
                            : "normal"
                        }}
                      >
                        {segment.total} {segment.displayTag}
                      </text>
                    </box>
                  </box>
                ))
              )}
            </box>
          ) : bottomInfoView === "priorities" ? (
            <box style={{ flexDirection: "row", gap: 0 }}>
              {priorityTickerSegments.length === 0 ? (
                <text style={{ color: theme.muted }}>
                  {priorityTickerNeedsWiderLayout
                    ? "WIDEN TO VIEW PRIORITIES"
                    : "NO OPEN PRIORITIES"}
                </text>
              ) : (
                priorityTickerSegments.map((segment, index) => (
                  <box key={segment.priorityTag} style={{ flexDirection: "row", gap: 0 }}>
                    {index > 0 ? (
                      <text style={{ color: theme.muted }}>  </text>
                    ) : null}
                    <box
                      style={{
                        backgroundColor: colorForTag(segment.priorityTag),
                        paddingLeft: 1,
                        paddingRight: 1
                      }}
                      onMouseDown={(event) => {
                        if (event.button !== 0) return;
                        toggleBottomPriorityQuickFilter(segment.priorityTag);
                      }}
                    >
                      <text
                        style={{
                          color: isBottomPriorityQuickFilterActive(segment.priorityTag)
                            ? theme.text
                            : theme.bg,
                          fontWeight: isBottomPriorityQuickFilterActive(segment.priorityTag)
                            ? "bold"
                            : "normal"
                        }}
                      >
                        {segment.total} {segment.displayPriority}
                      </text>
                    </box>
                  </box>
                ))
              )}
            </box>
          ) : (
            <box style={{ flexDirection: "row", gap: 2 }}>
              <box
                style={{
                  backgroundColor: theme.warn,
                  paddingLeft: 1,
                  paddingRight: 1
                }}
                onMouseDown={(event) => {
                  if (event.button !== 0) return;
                  toggleBottomDueQuickFilter("overdue");
                }}
              >
                <text
                  style={{
                    color: overdueQuickFilterActive ? theme.text : theme.bg,
                    fontWeight: overdueQuickFilterActive ? "bold" : "normal"
                  }}
                >
                  {summary.overdue} OVERDUE
                </text>
              </box>
              <box
                style={{
                  backgroundColor: theme.dueSoon,
                  paddingLeft: 1,
                  paddingRight: 1
                }}
                onMouseDown={(event) => {
                  if (event.button !== 0) return;
                  toggleBottomDueQuickFilter("today");
                }}
              >
                <text
                  style={{
                    color: todayQuickFilterActive ? theme.text : theme.bg,
                    fontWeight: todayQuickFilterActive ? "bold" : "normal"
                  }}
                >
                  {summary.today} DUE TODAY
                </text>
              </box>
              <box
                style={{
                  backgroundColor: theme.dueLater,
                  paddingLeft: 1,
                  paddingRight: 1
                }}
                onMouseDown={(event) => {
                  if (event.button !== 0) return;
                  toggleBottomDueQuickFilter("next7");
                }}
              >
                <text
                  style={{
                    color: next7QuickFilterActive ? theme.text : theme.bg,
                    fontWeight: next7QuickFilterActive ? "bold" : "normal"
                  }}
                >
                  {summary.next7} DUE THIS WEEK
                </text>
              </box>
              <box
                style={{
                  backgroundColor: theme.ok,
                  paddingLeft: 1,
                  paddingRight: 1
                }}
                onMouseDown={(event) => {
                  if (event.button !== 0) return;
                  toggleBottomCompletedQuickFilter();
                }}
              >
                <text
                  style={{
                    color: doneQuickFilterActive ? theme.text : theme.bg,
                    fontWeight: doneQuickFilterActive ? "bold" : "normal"
                  }}
                >
                  {summary.completed7} COMPLETED THIS WEEK
                </text>
              </box>
            </box>
          )}
        </box>
      </box>

      {activeEngagementToast ? (
        <box
          style={{
            position: "absolute",
            left: layout.railWidth + 1,
            right: 1,
            bottom: 1,
            paddingLeft: 1,
            paddingRight: 1,
            backgroundColor: theme.panel,
            border: true,
            borderStyle: "single",
            borderColor: theme.outline
          }}
        >
          <text style={{ color: theme.text }}>{engagementToastLine}</text>
        </box>
      ) : null}

      {uiState.mode === Mode.MODAL_CONFIRM && uiState.modal ? (
        <box
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          {uiState.modal.type === "delete" ? (
            uiState.modal.target === "regular_task" ? (
              <box
                style={{
                  padding: 2,
                  backgroundColor: modalTheme.warn,
                  color: modalTheme.bg,
                  minWidth: MODAL_STANDARD_WIDTH
                }}
              >
                <text>DELETE SELECTED TASK? [Y/N]</text>
                <text>{uiState.modal.taskTitle}</text>
                <text>ID: {uiState.modal.taskId.slice(0, 8)}</text>
                <box style={{ flexDirection: "row", gap: 1, marginTop: 1 }}>
                  <box
                    style={{
                      backgroundColor: modalTheme.bg,
                      paddingLeft: 2,
                      paddingRight: 2
                    }}
                    onMouseDown={(event) => {
                      if (event.button !== 0) return;
                      confirmDeleteSelectedFromModal();
                    }}
                  >
                    <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>YES [Y]</text>
                  </box>
                  <box
                    style={{
                      backgroundColor: modalTheme.bg,
                      paddingLeft: 2,
                      paddingRight: 2
                    }}
                    onMouseDown={(event) => {
                      if (event.button !== 0) return;
                      cancelDeleteSelectedFromModal();
                    }}
                  >
                    <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>NO [N]</text>
                  </box>
                </box>
              </box>
            ) : (
              <box
                style={{
                  padding: 2,
                  backgroundColor: modalTheme.warn,
                  color: modalTheme.bg,
                  minWidth: MODAL_STANDARD_WIDTH
                }}
              >
                <text>DELETE RECURRING OCCURRENCE? [Y/F/N]</text>
                <text>{uiState.modal.taskTitle}</text>
                <text>OCCURRENCE: {uiState.modal.occurrenceIso.slice(0, 16)}</text>
                <box style={{ flexDirection: "row", gap: 1, marginTop: 1 }}>
                  <box
                    style={{
                      backgroundColor: modalTheme.bg,
                      paddingLeft: 2,
                      paddingRight: 2
                    }}
                    onMouseDown={(event) => {
                      if (event.button !== 0) return;
                      confirmDeleteSelectedFromModal();
                    }}
                  >
                    <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>
                      THIS EVENT [Y]
                    </text>
                  </box>
                  <box
                    style={{
                      backgroundColor: modalTheme.bg,
                      paddingLeft: 2,
                      paddingRight: 2
                    }}
                    onMouseDown={(event) => {
                      if (event.button !== 0) return;
                      confirmDeleteSelectedAndFutureFromModal();
                    }}
                  >
                    <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>
                      THIS + FUTURE [F]
                    </text>
                  </box>
                  <box
                    style={{
                      backgroundColor: modalTheme.bg,
                      paddingLeft: 2,
                      paddingRight: 2
                    }}
                    onMouseDown={(event) => {
                      if (event.button !== 0) return;
                      cancelDeleteSelectedFromModal();
                    }}
                  >
                    <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>
                      CANCEL [N]
                    </text>
                  </box>
                </box>
              </box>
            )
          ) : uiState.modal.type === "task_link_form" ? (
            <box
              style={{
                padding: 2,
                backgroundColor: theme.panel,
                border: true,
                borderStyle: "single",
                borderColor: theme.outline,
                width: MODAL_STANDARD_WIDTH,
                flexDirection: "column",
                gap: 1
              }}
            >
              <text style={{ color: theme.text, fontWeight: "bold" }}>
                {uiState.modal.mode === "add"
                  ? "ADD LINK / ATTACHMENT"
                  : "EDIT LINK / ATTACHMENT"}
              </text>
              <text style={{ color: theme.muted }}>
                [TAB] NEXT  [UP/DOWN] MOVE  [LEFT/RIGHT] TYPE  [ENTER/CTRL+S] SAVE  [ESC] CANCEL
              </text>
              <box
                style={{ flexDirection: "column" }}
                onMouseDown={(event) => {
                  if (event.button !== 0) return;
                  patchTaskLinkFormModal({ activeField: "label" });
                }}
              >
                <text style={{ color: theme.muted }}>LABEL (OPTIONAL)</text>
                <input
                  value={uiState.modal.labelValue}
                  onChange={(value) =>
                    patchTaskLinkFormModal({
                      labelValue: value,
                      error: undefined
                    })
                  }
                  focused={uiState.modal.activeField === "label"}
                  placeholder="e.g. Design doc"
                  style={{ backgroundColor: inputTheme.bg, color: inputTheme.text }}
                />
              </box>
              <box
                style={{ flexDirection: "column" }}
                onMouseDown={(event) => {
                  if (event.button !== 0) return;
                  patchTaskLinkFormModal({ activeField: "target" });
                }}
              >
                <text style={{ color: theme.muted }}>TARGET *</text>
                <input
                  value={uiState.modal.targetValue}
                  onChange={(value) =>
                    patchTaskLinkFormModal({
                      targetValue: value,
                      error: undefined
                    })
                  }
                  focused={uiState.modal.activeField === "target"}
                  placeholder="https://... or /path/to/file"
                  style={{ backgroundColor: inputTheme.bg, color: inputTheme.text }}
                />
              </box>
              <box style={{ flexDirection: "column" }}>
                <text style={{ color: theme.muted }}>
                  TYPE ({uiState.modal.activeField === "type" ? "ACTIVE" : "AUTO/URL/PATH"})
                </text>
                <box style={{ flexDirection: "row", gap: 1 }}>
                  {TASK_LINK_FORM_KIND_ORDER.map((kind) => {
                    const selected = uiState.modal.kindValue === kind;
                    return (
                      <box
                        key={kind}
                        style={{
                          paddingLeft: 2,
                          paddingRight: 2,
                          backgroundColor: selected ? theme.accentBlue : theme.panel,
                          border: true,
                          borderStyle: "single",
                          borderColor:
                            uiState.modal.activeField === "type"
                              ? theme.accentBlue
                              : theme.outline
                        }}
                        onMouseDown={(event) => {
                          if (event.button !== 0) return;
                          patchTaskLinkFormModal({
                            kindValue: kind,
                            activeField: "type",
                            error: undefined
                          });
                        }}
                      >
                        <text style={{ color: selected ? theme.bg : theme.text }}>
                          {kind.toUpperCase()}
                        </text>
                      </box>
                    );
                  })}
                </box>
              </box>
              {uiState.modal.error ? (
                <text style={{ color: theme.warn }}>{uiState.modal.error}</text>
              ) : null}
              <box style={{ flexDirection: "row", gap: 1 }}>
                <box
                  style={{
                    backgroundColor:
                      uiState.modal.activeField === "save" ? theme.accentBlue : theme.panel,
                    border: true,
                    borderStyle: "single",
                    borderColor: theme.outline,
                    paddingLeft: 2,
                    paddingRight: 2
                  }}
                  onMouseDown={(event) => {
                    if (event.button !== 0) return;
                    submitTaskLinkFormModal();
                  }}
                >
                  <text
                    style={{
                      color: uiState.modal.activeField === "save" ? theme.bg : theme.text,
                      fontWeight: "bold"
                    }}
                  >
                    SAVE [ENTER/CTRL+S]
                  </text>
                </box>
                <box
                  style={{
                    backgroundColor:
                      uiState.modal.activeField === "cancel" ? theme.accentBlue : theme.panel,
                    border: true,
                    borderStyle: "single",
                    borderColor: theme.outline,
                    paddingLeft: 2,
                    paddingRight: 2
                  }}
                  onMouseDown={(event) => {
                    if (event.button !== 0) return;
                    applyEscUnwind();
                  }}
                >
                  <text
                    style={{
                      color: uiState.modal.activeField === "cancel" ? theme.bg : theme.text,
                      fontWeight: "bold"
                    }}
                  >
                    CANCEL [ESC]
                  </text>
                </box>
              </box>
            </box>
          ) : uiState.modal.type === "task_link_delete" ? (
            <box
              style={{
                padding: 2,
                backgroundColor: modalTheme.warn,
                color: modalTheme.bg,
                minWidth: MODAL_STANDARD_WIDTH
              }}
            >
              <text>REMOVE LINK? [Y/N]</text>
              <text>{formatLinkSnippet(uiState.modal.label, uiState.modal.target)}</text>
              <box style={{ flexDirection: "row", gap: 1, marginTop: 1 }}>
                <box
                  style={{ backgroundColor: modalTheme.bg, paddingLeft: 2, paddingRight: 2 }}
                  onMouseDown={(event) => {
                    if (event.button !== 0) return;
                    handleDeleteTaskLinkFromModal();
                  }}
                >
                  <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>YES [Y]</text>
                </box>
                <box
                  style={{ backgroundColor: modalTheme.bg, paddingLeft: 2, paddingRight: 2 }}
                  onMouseDown={(event) => {
                    if (event.button !== 0) return;
                    applyEscUnwind();
                  }}
                >
                  <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>NO [N]</text>
                </box>
              </box>
            </box>
          ) : uiState.modal.type === "task_link_open_external" ? (
            <box
              style={{
                padding: 2,
                backgroundColor: modalTheme.warn,
                color: modalTheme.bg,
                minWidth: MODAL_STANDARD_WIDTH
              }}
            >
              <text>{`OPEN EXTERNAL SCHEME \"${uiState.modal.scheme}\"? [Y/N]`}</text>
              <text>{formatLinkSnippet(undefined, uiState.modal.target)}</text>
              <box style={{ flexDirection: "row", gap: 1, marginTop: 1 }}>
                <box
                  style={{ backgroundColor: modalTheme.bg, paddingLeft: 2, paddingRight: 2 }}
                  onMouseDown={(event) => {
                    if (event.button !== 0) return;
                    handleOpenExternalTaskLinkFromModal();
                  }}
                >
                  <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>YES [Y]</text>
                </box>
                <box
                  style={{ backgroundColor: modalTheme.bg, paddingLeft: 2, paddingRight: 2 }}
                  onMouseDown={(event) => {
                    if (event.button !== 0) return;
                    applyEscUnwind();
                  }}
                >
                  <text style={{ color: modalTheme.warn, fontWeight: "bold" }}>NO [N]</text>
                </box>
              </box>
            </box>
          ) : uiState.modal.type === "emptyNux" ? (
            <EmptyNuxModal
              step={activeEmptyNuxStep}
              onDismissSession={dismissEmptyNuxModal}
              onClearWalkthrough={clearEmptyNuxWalkthrough}
              onCreateTask={createTaskFromEmptyNuxModal}
              onShowShortcuts={showEmptyNuxShortcutsModal}
              onBackToWelcome={returnToEmptyNuxWelcomeModal}
              onGoToList={closeCelebrateToList}
            />
          ) : activeOverdueModal ? (
            <OverdueNotificationModal
              event={activeOverdueModal.event}
              task={activeOverdueTask}
              nowMs={now}
              onSnooze={handleOverdueModalSnooze}
              onDone={handleOverdueModalDone}
              onGoToTask={handleOverdueModalGoToTask}
              onDismiss={() => {
                applyEscUnwind();
              }}
            />
          ) : null}
        </box>
      ) : null}

      {viewsOverlayOpen ? (
        <box
          style={{
            position: "absolute",
            top: 3,
            left: layout.railWidth + 3,
            padding: 1,
            backgroundColor: theme.panel,
            border: true,
            borderStyle: "single",
            borderColor: theme.outline,
            minWidth: 58
          }}
        >
          <box style={{ flexDirection: "column" }}>
            <text style={{ color: theme.text, fontWeight: "bold" }}>
              SAVED VIEWS ({state.savedViews.length}/{MAX_SAVED_VIEWS})
            </text>
            <text style={{ color: theme.muted }}>
              enter: apply  d: delete  ctrl+s: save current  v/esc: close
            </text>
            {state.savedViews.length === 0 ? (
              <text style={{ color: theme.muted, marginTop: 1 }}>No saved views yet.</text>
            ) : (
              <box style={{ flexDirection: "column", marginTop: 1 }}>
                {state.savedViews.map((view, index) => {
                  const selected = index === selectedViewIndex;
                  const slot = String(index + 1);
                  return (
                    <box
                      key={view.id}
                      style={{
                        paddingLeft: 1,
                        paddingRight: 1,
                        backgroundColor: selected ? theme.accentBlue : "transparent"
                      }}
                    >
                      <text style={{ color: selected ? theme.bg : theme.text }}>
                        [{slot}] {view.name} - {summarizeViewFilters(view.filters)}
                      </text>
                    </box>
                  );
                })}
              </box>
            )}

            {saveViewPromptOpen ? (
              <box style={{ flexDirection: "column", marginTop: 1 }}>
                <text style={{ color: theme.text }}>Save current filters as view name:</text>
                <input
                  value={saveViewName}
                  onChange={updateSaveViewName}
                  focused
                  placeholder="e.g. TODAY FOCUS"
                  style={{ backgroundColor: inputTheme.bg, color: inputTheme.text }}
                />
                <text style={{ color: theme.muted }}>
                  Enter: save, Esc: cancel ({saveViewName.length}/{VIEW_NAME_MAX_LENGTH})
                </text>
              </box>
            ) : null}
          </box>
        </box>
      ) : null}

      {uiState.mode === Mode.TAG_FILTER ? (
        <box
          style={{
            position: "absolute",
            top: 1,
            left: 2,
            right: 2,
            bottom: 1,
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          <TagFilterPanel
            draft={tagFilterDraft}
            inputValue={tagFilterInput}
            activeBucket={activeTagFilterBucket}
            inlineSuggestion={tagFilterInlineSuggestion}
            suggestions={tagFilterSuggestions}
            onInputChange={setTagFilterInput}
            onInputKeyDown={handleTagFilterPanelInputKeyDown}
            onInputSubmit={(value) => addTagFilterDraftCandidateFromInput(value)}
            onSetBucket={setActiveTagFilterBucket}
            onRemoveTag={(bucket, tag) =>
              setTagFilterDraft((current) =>
                removeTagFromTagFilter(current, bucket, tag)
              )
            }
            onApply={applyTagFilterPanel}
            onClear={clearTagFilterPanelDraft}
            onCancel={closeTagFilterPanel}
          />
        </box>
      ) : null}

      {uiState.mode === Mode.BACKUP_CENTER ? (
        <box
          style={{
            position: "absolute",
            top: 2,
            left: 8,
            right: 8,
            bottom: 2,
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          <BackupCenterScreen
            state={backupState}
            dataPath={getDataFilePath()}
            savedViewNames={state.savedViews.map((view) => view.name)}
            onImportPathChange={(value) =>
              backupDispatch({ type: "setImportPath", value })
            }
            onReplaceConfirmChange={(value) =>
              backupDispatch({ type: "setReplaceConfirmInput", value })
            }
            onCalendarExportPathChange={(value) =>
              backupDispatch({ type: "setCalendarExportPath", value })
            }
            onCalendarImportPathChange={(value) =>
              backupDispatch({ type: "setCalendarImportPath", value })
            }
            onCalendarImportHorizonChange={(value) =>
              backupDispatch({ type: "setCalendarImportHorizonInput", value })
            }
            onCalendarImportTagChange={(value) =>
              backupDispatch({ type: "setCalendarImportTagInput", value })
            }
            onCalendarImportConfirmChange={(value) =>
              backupDispatch({ type: "setCalendarImportConfirmInput", value })
            }
            onPrimaryAction={handleBackupPrimaryAction}
            onBackAction={handleBackupBackAction}
            onMenuSelect={handleBackupMenuSelect}
            onCalendarMenuSelect={handleCalendarMenuSelect}
            onImportModeSelect={(mode) =>
              backupDispatch({ type: "setImportMode", mode })
            }
            onCalendarExportRangeSelect={(range) =>
              backupDispatch({ type: "setCalendarExportRange", range })
            }
            onCalendarExportViewSelect={(viewName) =>
              backupDispatch({ type: "setCalendarExportViewName", viewName })
            }
            onCalendarExportPrivacySelect={(privacy) =>
              backupDispatch({ type: "setCalendarExportPrivacy", privacy })
            }
            onCalendarImportRangeSelect={(range) =>
              backupDispatch({ type: "setCalendarImportRange", range })
            }
            onCalendarImportViewSelect={(viewName) =>
              backupDispatch({ type: "setCalendarImportViewName", viewName })
            }
            onCalendarImportModeSelect={(mode) =>
              backupDispatch({ type: "setCalendarImportMode", mode })
            }
          />
        </box>
      ) : null}

      {uiState.mode === Mode.HELP ? (
        <box
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          <box
            style={{
              width: helpPanelWidth,
              height: helpPanelHeight,
              maxWidth: "100%",
              flexDirection: "column",
              backgroundColor: helpTheme.panel,
              overflow: "hidden",
              border: true,
              borderStyle: "single",
              borderColor: helpTheme.outline
            }}
          >
            <box
              style={{
                flexDirection: "column",
                height: HELP_HEADER_ROWS,
                minHeight: HELP_HEADER_ROWS,
                maxHeight: HELP_HEADER_ROWS,
                paddingLeft: 1,
                paddingRight: 1,
                backgroundColor: helpTheme.panel
              }}
            >
              <text style={{ color: helpTheme.text, fontWeight: "bold" }}>{helpHeaderTitle}</text>
              <text style={{ color: helpTheme.muted }}>
                {PRODUCT_NAME_TM} {APP_VERSION} · {APP_TAGLINE}
              </text>
            </box>
            <box
              style={{
                height: HELP_DIVIDER_ROWS,
                minHeight: HELP_DIVIDER_ROWS,
                maxHeight: HELP_DIVIDER_ROWS,
                paddingLeft: 1,
                paddingRight: 1,
                backgroundColor: helpTheme.panel
              }}
            >
              <text style={{ color: helpTheme.outline }}>
                {"─".repeat(helpFooterWidth)}
              </text>
            </box>
            <box
              style={{
                height: helpContentVisibleRows,
                minHeight: helpContentVisibleRows,
                maxHeight: helpContentVisibleRows,
                paddingLeft: 1,
                paddingRight: 1,
                backgroundColor: helpTheme.panel,
                overflow: "hidden"
              }}
            >
              {activeHelpPage === "custom1Edit" ? (
                <Custom1ThemeEditor
                  ref={custom1EditorRef}
                  draftGlobal={custom1DraftGlobal}
                  draftObjects={custom1DraftObjects}
                  persistedGlobal={persistedCustom1.global}
                  onChangeGlobal={setCustom1DraftGlobal}
                  onChangeObjects={setCustom1DraftObjects}
                  onSave={saveCustom1Editor}
                  onCancel={closeCustom1EditorCancel}
                />
              ) : activeHelpPage === "textTuningEdit" ? (
                <BuiltInThemeTextEditor
                  ref={builtInTextEditorRef}
                  themeId={helpTextTuningThemeId}
                  baseTokens={builtInTextBaseTokens}
                  draftGlobal={builtInTextDraftGlobal}
                  draftObjects={builtInTextDraftObjects}
                  onChangeGlobal={setBuiltInTextDraftGlobal}
                  onChangeObjects={setBuiltInTextDraftObjects}
                  onSave={saveBuiltInTextEditor}
                  onCancel={closeBuiltInTextEditorCancel}
                />
              ) : activeHelpPage === "help" ? (
                <box
                  style={{
                    height: "100%",
                    minHeight: 0,
                    maxHeight: "100%",
                    flexDirection: "column",
                    overflow: "hidden"
                  }}
                  onMouseScroll={(event) => {
                    const direction = event.scroll?.direction;
                    if (direction === "up") {
                      scrollHelpTo(clampedHelpScrollOffset - 1);
                    } else if (direction === "down") {
                      scrollHelpTo(clampedHelpScrollOffset + 1);
                    }
                  }}
                >
                  <box
                    style={{
                      flexDirection: "column"
                    }}
                  >
                    {helpVisibleRows.map((row, visibleRowIndex) => {
                      const rowIndex = clampedHelpScrollOffset + visibleRowIndex;
                      const scrollbarIsThumb =
                        helpScrollbarThumb !== null &&
                        visibleRowIndex >= helpScrollbarThumb.startRow &&
                        visibleRowIndex <= helpScrollbarThumb.endRow;
                      const scrollbarGlyph =
                        helpHasOverflow && scrollbarIsThumb ? "█" : helpHasOverflow ? "│" : "";
                      if (row.kind === "section_header") {
                        const section = HELP_MENU_SECTIONS[row.sectionIndex];
                        const expanded = helpExpandedBySection[row.sectionIndex] === true;
                        const focused = row.sectionIndex === clampedHelpFocusedSectionIndex;
                        const sectionLine = fitLineToWidth(
                          `${expanded ? "▾" : "▸"} ${section.title}`,
                          helpContentLineWidth
                        );
                        return (
                          <box
                            key={`help-row-${rowIndex}`}
                            style={{
                              flexDirection: "row",
                              backgroundColor: focused ? helpTheme.accentBlue : "transparent",
                              width: "100%"
                            }}
                            onMouseDown={(event) => {
                              if (event.button !== 0) return;
                              handleHelpSectionHeaderClick(row.sectionIndex);
                            }}
                          >
                            <text
                              style={{
                                color: focused ? helpTheme.bg : helpTheme.text,
                                fontWeight: focused ? "bold" : "normal"
                              }}
                            >
                              {sectionLine}
                            </text>
                            {helpHasOverflow ? (
                              <text
                                style={{
                                  color: scrollbarIsThumb
                                    ? focused
                                      ? helpTheme.bg
                                      : helpTheme.accentBlue
                                    : focused
                                      ? helpTheme.bg
                                      : helpTheme.outline
                                }}
                              >
                                {scrollbarGlyph}
                              </text>
                            ) : null}
                          </box>
                        );
                      }

                      const section = HELP_MENU_SECTIONS[row.sectionIndex];
                      const item = section.items[row.itemIndex];
                      if (row.kind === "item_title") {
                        return (
                          <box
                            key={`help-row-${rowIndex}`}
                            style={{ flexDirection: "row", width: "100%" }}
                          >
                            <text style={{ color: helpTheme.text }}>
                              {fitLineToWidth(`  • ${item.title}`, helpContentLineWidth)}
                            </text>
                            {helpHasOverflow ? (
                              <text
                                style={{
                                  color: scrollbarIsThumb
                                    ? helpTheme.accentBlue
                                    : helpTheme.outline
                                }}
                              >
                                {scrollbarGlyph}
                              </text>
                            ) : null}
                          </box>
                        );
                      }
                      const descriptionLines = getHelpItemDescriptionLines(item);
                      const descriptionLine = fitLineToWidth(
                        `    ${descriptionLines[row.descriptionLineIndex] ?? ""}`,
                        helpContentLineWidth
                      );
                      return (
                        <box
                          key={`help-row-${rowIndex}`}
                          style={{ flexDirection: "row", width: "100%" }}
                        >
                          <text style={{ color: helpTheme.muted }}>{descriptionLine}</text>
                          {helpHasOverflow ? (
                            <text
                              style={{
                                color: scrollbarIsThumb
                                  ? helpTheme.accentBlue
                                  : helpTheme.outline
                              }}
                            >
                              {scrollbarGlyph}
                            </text>
                          ) : null}
                        </box>
                      );
                    })}
                  </box>
                </box>
              ) : (
                <scrollbox
                  scrollY
                  style={{
                    height: "100%",
                    minHeight: 0,
                    rootOptions: { backgroundColor: helpTheme.panel },
                    wrapperOptions: { backgroundColor: helpTheme.panel },
                    viewportOptions: { backgroundColor: helpTheme.panel },
                    contentOptions: { backgroundColor: helpTheme.panel }
                  }}
                >
                  <box style={{ flexDirection: "column", paddingRight: helpHasOverflow ? 1 : 0 }}>
                    {activeHelpPage === "settings" ? (
                      <>
                        <text style={{ color: helpTheme.muted }}>{helpThemeStatusLine.trim()}</text>
                        <text style={{ color: helpTheme.muted }}>{helpLogoStatusLine.trim()}</text>
                        <text style={{ color: helpTheme.muted }}>{helpFlashStatusLine.trim()}</text>
                        <text style={{ color: helpTheme.muted }}>
                          {helpNotificationsEnabledStatusLine.trim()}
                        </text>
                        <text style={{ color: helpTheme.muted }}>
                          {helpInAppBannerStatusLine.trim()}
                        </text>
                        <text style={{ color: helpTheme.muted }}>
                          {helpTerminalBellStatusLine.trim()}
                        </text>
                      </>
                    ) : null}
                    {helpNavItems.map((item, index) => {
                      const focused = index === clampedHelpNavSelectionIndex;
                      const itemTitle =
                        activeHelpPage === "theme" && index === 0
                          ? helpThemeStatusLineRaw
                          : activeHelpPage === "settings" &&
                              index === HELP_SETTINGS_LOGO_NAV_INDEX
                            ? `Logo: ${formatLogoModeLabel(effectiveLogoModeForHelp)}`
                          : item.title;
                      return (
                        <box key={`${activeHelpPage}-${item.title}`}>
                          <box
                            style={{
                              flexDirection: "row",
                              backgroundColor: focused ? helpTheme.accentBlue : "transparent",
                              paddingLeft: 1,
                              paddingRight: 1
                            }}
                            onMouseDown={(event) => {
                              if (event.button !== 0) return;
                              setHelpNavSelectionForActivePage(index);
                              handleHelpNavForward(index);
                            }}
                          >
                            <text
                              style={{
                                color: focused ? helpTheme.bg : helpTheme.text,
                                fontWeight: focused ? "bold" : "normal"
                              }}
                            >
                              {fitLineToWidth(
                                `${focused ? "▶" : " "} ${itemTitle}`,
                                helpContentLineWidth
                              )}
                            </text>
                          </box>
                          <text style={{ color: helpTheme.muted }}>
                            {fitLineToWidth(`    ${item.description}`, helpContentLineWidth)}
                          </text>
                        </box>
                      );
                    })}
                  </box>
                </scrollbox>
              )}
            </box>
            {/*
             * Keep footer fixed to exactly 2 rows with full-width background fill.
             * Border-aware sizing + clipping keeps footer rows inside the panel interior and
             * avoids stale glyph overprint/spillage from content redraws.
             */}
            <box
              style={{
                flexDirection: "column",
                height: HELP_FOOTER_ROWS,
                minHeight: HELP_FOOTER_ROWS,
                maxHeight: HELP_FOOTER_ROWS,
                backgroundColor: helpTheme.panel,
                overflow: "hidden"
              }}
            >
              <box
                style={{
                  height: 1,
                  minHeight: 1,
                  maxHeight: 1,
                  width: "100%",
                  flexDirection: "row",
                  alignItems: "center",
                  paddingLeft: 1,
                  paddingRight: 1,
                  backgroundColor: helpTheme.panel
                }}
              >
                <text style={{ color: helpTheme.muted }}>{helpFooterHintsLine}</text>
                {helpCloseButtonLabel ? (
                  <box
                    style={{
                      marginLeft: 1,
                      backgroundColor: helpTheme.accentBlue,
                      paddingLeft: 1,
                      paddingRight: 1
                    }}
                    onMouseDown={(event) => {
                      if (event.button !== 0) return;
                      closeHelp();
                    }}
                  >
                    <text style={{ color: helpTheme.bg, fontWeight: "bold" }}>
                      {helpCloseButtonLabel}
                    </text>
                  </box>
                ) : null}
              </box>
              <box
                style={{
                  height: 1,
                  minHeight: 1,
                  maxHeight: 1,
                  width: "100%",
                  paddingLeft: 1,
                  paddingRight: 1,
                  backgroundColor: helpTheme.panel
                }}
              >
                <text style={{ color: helpTheme.muted }}>{helpFooterDataPathLine}</text>
              </box>
            </box>
          </box>
        </box>
      ) : null}
    </box>
  );
}
